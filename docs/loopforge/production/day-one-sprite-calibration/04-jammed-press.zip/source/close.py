from build import *
import subprocess
from functools import lru_cache
def state(t,rows):return [v for s,v in rows if s<=t+1e-6][-1]
face=ImageFont.truetype('/usr/share/fonts/liberation-sans-fonts/LiberationSans-Regular.ttf',18)
bold=ImageFont.truetype('/usr/share/fonts/liberation-sans-fonts/LiberationSans-Bold.ttf',18)
@lru_cache(maxsize=64)
def close_frame(idx,k,blind):
 b,r,c,g=fixture(); im=z(FS);floor=Image.open(SRC/'selected-B-floor.png').convert('RGBA')
 for xx in (-147,109):
  for yy in (-130,126,382):im.alpha_composite(floor,(xx,yy))
 im.alpha_composite(b);im.alpha_composite(r);im.alpha_composite(door(k));im.alpha_composite(c);im.alpha_composite(Image.open(SRC/'selected-B-shadow.png').convert('RGBA'),AO)
 planes=actor(idx,False)
 for a in planes[:2 if blind else 3]:im.alpha_composite(a,AO)
 im.alpha_composite(g)
 return im.crop((25,34,274,215))
def enc(file,size,fps=20):
 return subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-y','-f','rawvideo','-vcodec','rawvideo','-pixel_format','rgb24','-video_size',f'{size[0]}x{size[1]}','-framerate',str(fps),'-i','-','-an','-c:v','libx264','-threads','2','-crf','16','-preset','veryfast','-pix_fmt','yuv420p','-movflags','+faststart',str(file)],stdin=subprocess.PIPE)
def earlytime():
 size=(830,540); encod=enc(PROOF/'contact-r02-timed-1x.mp4',size)
 for i in range(60):
  t=107.7+i/20; idx=state(t,TIMES);k=state(t,DOORS)
  im=Image.new('RGB',size,'#101d1d');d=ImageDraw.Draw(im)
  d.text((35,14),'C4  /  Working-face inspection lens  ·  normal speed',font=bold,fill='#eddfb8')
  im.paste(close_frame(idx,k,False).resize((624,452),Image.Resampling.NEAREST),(103,50))
  d.text((35,514),'Edited %.2f s   ·   actor and door on independent tracks'%t,font=face,fill='#c0cfbc')
  encod.stdin.write(im.tobytes())
 encod.stdin.close();assert encod.wait()==0
if __name__=='__main__':earlytime()

"""Two sole contacts in world space as recoil blends into the approved 1.2 m/s westbound route."""
from build import *
T0=109.1
speed=76.8
def xpos(t):return -speed*max(0,t-T0)
def foot(t,side):
 base=125 if side=='r' else 136;y0=211 if side=='r' else 206
 # Contact x is in the world plane expressed in native source px relative to t0 actor frame.
 intervals=([(.23,.45),(.80,1.02),(1.37,1.59)] if side=='r' else [(0,.23),(.45,.80),(1.02,1.37),(1.59,1.94)])
 startpos=base
 for a,b in intervals:
  a+=T0;b+=T0
  nextpos=base+xpos(b)-7
  if t<a-1e-8:break
  if t<=b+1e-8:
   u=max(0,min(1,(t-a)/(b-a)));e=u*u*(3-2*u)
   wx=startpos+(nextpos-startpos)*e
   return (round(wx-xpos(t)),round(y0-(5 if side=='r' else 3)*math.sin(math.pi*u)),u<.001 or u>.999,wx)
  startpos=nextpos
 return (round(startpos-xpos(t)),y0,True,startpos)
def legs(t,lit=False):
 # Reuse the two existing shoes, pivots and pelvis, with a bent underloaded left knee.
 if t<=T0:return None
 im=z();d=ImageDraw.Draw(im)
 m=Image.open(SRC/'selected-B-body.png').convert('RGBA') if lit else parts[1]
 for side in ('l','r'):
  x,y,planted,_=foot(t,side);hip=(132,180) if side=='l' else (125,180)
  k=(round((hip[0]+x)/2)+(-4 if side=='l' else 2),192 if side=='l' else 194)
  ank=(x-2,y-5)
  for a,b,w in ((hip,k,5),(k,ank,4)):
   d.line((a,b),fill='#172630',width=w+2);d.line((a,b),fill='#284d6a' if lit else p['h'],width=w)
   d.line((a[0]-1,a[1]+1,b[0]-1,b[1]-1),fill='#6386a2' if lit else p['a'],width=1)
  d.ellipse((k[0]-2,k[1]-2,k[0]+2,k[1]+2),fill='#303e43');d.point((k[0],k[1]-1),fill='#a98c65')
  srcbox=(129,201,140,207) if side=='l' else (120,203,131,212)
  shoe=m.crop(srcbox)
  footbase=(136,206) if side=='l' else (125,211)
  im.alpha_composite(shoe,(srcbox[0]+x-footbase[0],srcbox[1]+y-footbase[1]))
 # Pelvis reused directly so the waist stays nested in the leg yokes.
 hip=m.crop((123,176,136,185));im.alpha_composite(hip,(121,176))
 return im
def tail_layers(t,idx):
 base=legs(t,False);light=legs(t,True)
 if base is None:return None
 rawparts=[Image.open(A/f'char-bob-palm-unjam-SE-{idx:02d}-{n}.png').convert('RGBA') for n in ['lower-body','torso-head','free-arm','striking-arm']]
 rawtop=composite(rawparts[1:]);fbase=composite([base,rawtop])
 raw=actor(idx,False);litold=Image.alpha_composite(raw[0],raw[1]);litold.putalpha(rawtop.getchannel('A'))
 clight=composite([light,litold]);return fbase,clight,raw[2]

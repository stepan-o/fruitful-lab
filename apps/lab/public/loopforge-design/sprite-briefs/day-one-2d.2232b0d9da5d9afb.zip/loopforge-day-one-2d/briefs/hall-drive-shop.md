# Drive overhaul bay — hall-drive-shop

Preserve the proposed Forge hall arrangement and industrial function. This kit establishes the working factory around the active five-station line.

## Group

Hall dressing

## Delivery priority

P1

## Quantity

1 assembly: H4

## Parts and source layers

Two workbenches, drive component, toolboard, covered inspection pit and parked trolley; clear central lane.

## States and variants

Static parked state for Day 1. Crane/hoist parts are separable for future movement, but no crane operation or vehicles are required by the approved sequence.

## Assembly and sockets

Use the measured Forge hall build marker in scene-bindings.json. Ground geometry remains exact; elevated elements use occlusion masks and may fade above active workers. H9 transfer-road striping belongs to env-floor-kit. Contacts are parking/attachment anchors, not new gameplay slots. H4 at (79.250, 177.750) m, 19.75 × 11.25 m.

## Acceptance

The hall overview matches its build marker; dressing does not occupy roads, staff walk or reserved spare bay. No active animation competes with the current story beat.

## Delivery contract

Read HANDOFF.md and manifest.template.json in the complete pack. Status: briefed; this document does not contain finished sprite art.

from paint import *
import hashlib,shutil
from PIL import ImageChops,ImageCms
from collections import defaultdict
S=Path(__file__).parent
MAX=D/'source/max-r2';X=D/'exports';MASTER=D/'source/editable';MASTER.mkdir(exist_ok=True,parents=True)
if not MAX.exists():
 orig=D.parent/'lane02/max-master'
 assert hashlib.sha256((orig/'SE/body.png').read_bytes()).hexdigest()=='e0dc33b98a4076336a569e639776e1ec727804430cacd7879d1af5cadebd1796'
 assert hashlib.sha256((orig/'SE/head.png').read_bytes()).hexdigest()=='ab01d04412835e49c2aa15ab480eed8402b9e309472c46d5b38cfd5676675442'
 for facing in ('S','SE'):
  dest=MAX/facing;dest.mkdir(parents=True)
  for name in ['arm-l','leg-l','leg-r','arm-r','torso','head','body','security-light','emissive']:
   shutil.copyfile(orig/facing/(name+'.png'),dest/(name+'.png'))
 shutil.copyfile(orig/'manifest.json',MAX/'manifest.json')
def rgba(p):return Image.open(p).convert('RGBA')
@lru_cache(None)
def max_layer(face,n):return rgba(MAX/face/(n+'.png'))
def composite_at(im,part,x=0,y=0):im.alpha_composite(part,(round(x),round(y)))
def xform(part,anchor,shift,yscale=1.0,xscale=1.0,shear=0):
 ax,ay=anchor;ox,oy=shift
 return part.transform(part.size,Image.Transform.AFFINE,(1/xscale,-shear,ax-(ax+ox)/xscale+shear*(ay+oy),0,1/yscale,ay-(ay+oy)/yscale),resample=Image.Resampling.NEAREST)
def limb_warp(im,a,b,c,d):
 # Native coordinates of two joint markers define an affine from the original
 # plate limb to the authored target pose, keeping transverse thickness fixed.
 ax,ay=a;bx,by=b;cx,cy=c;dx,dy=d
 vx,vy=bx-ax,by-ay;wx,wy=dx-cx,dy-cy;al=math.hypot(vx,vy);bl=max(.5,math.hypot(wx,wy))
 ux,uy=vx/al,vy/al;tx,ty=wx/bl,wy/bl;r=al/bl
 aa=r*ux*tx+uy*ty;bb=r*ux*ty-uy*tx;dd=r*uy*tx-ux*ty;ee=r*uy*ty+ux*tx
 return im.transform(im.size,Image.Transform.AFFINE,(aa,bb,ax-aa*cx-bb*cy,dd,ee,ay-dd*cx-ee*cy),Image.Resampling.NEAREST)
def max_pose(t,duck,feet,receiving):
 t=round(t*5)/5;duck=round(duck*8)/8
 face='SE' if t<.40 else 'S';dy=15*duck;dx=-4*t+4*duck
 p=[layer() for _ in range(4)]
 for i,side in enumerate(['leg-l','leg-r']):
  part=max_layer('SE',side);hip=[(131,177),(125,177)][i];foot=[(133,207),(123,209)][i]
  posed=limb_warp(part,hip,foot,(hip[0]+dx*.45,hip[1]+dy*.65),feet[i]);p[1].alpha_composite(posed)
 for idx,n in [(0,'arm-l'),(2,'torso'),(3,'arm-r')]:
  part=max_layer('SE',n)
  if n=='arm-r' and receiving is not None:
   part=limb_warp(part,(121,153),(116,181),(121+dx*.45,153+dy),receiving)
  else:part=xform(part,(128,170),(dx*.45,dy),1-.06*duck,1, -.04*duck)
  p[idx].alpha_composite(part)
 h=xform(max_layer(face,'head'),(128,149),(dx,dy),1-.14*duck,1-.14*t,shear=.11*t)
 p[3].alpha_composite(h)
 em=xform(max_layer(face,'emissive'),(128,149),(dx,dy),1-.14*duck,1-.14*t,shear=.11*t)
 jaw=(128+dx,145+dy);soc={'look':px((129+dx,134+dy)),'jaw':px(jaw),'neck':px((128+dx,149+dy)),'foot_l':px(feet[0]),'foot_r':px(feet[1]),'hand_l':px((140+dx*.45,181+dy)),'hand_r':px(receiving if receiving is not None else (116+dx*.45,181+dy))}
 return p,em,soc
def max_steps(frames,distances,i):
 from bisect import bisect_left
 cur=frames[i]['actors']['max']['p'];dist=distances[i];baseline=[(133,207),(123,209)]
 if not dist:return baseline,[True,True]
 cycle=1.40
 def pos(q):
  j=min(len(frames)-1,max(0,bisect_left(distances,max(0,q))))
  if not j:return frames[0]['actors']['max']['p']
  f=max(0,min(1,(q-distances[j-1])/max(.00001,distances[j]-distances[j-1])))
  return mix(frames[j-1]['actors']['max']['p'],frames[j]['actors']['max']['p'],f)
 feet=[];contact=[]
 for side,b in enumerate(baseline):
  phase=(dist/cycle+side*.5)%1;start=dist-phase*cycle;grounded=phase<.5
  if grounded:mark=start+.25*cycle;lift=0
  else:
   a=(phase-.5)*2;mark=start+cycle*(.25+a*a*(3-2*a));lift=5*math.sin(a*math.pi)
  target=pos(mark)
  # Anchor the first sampled stance to the actual neutral sole; do not teleport at launch.
  if start<.02 and grounded:target=pos(0)
  feet.append((b[0]+(target[0]-cur[0])*64,b[1]+(target[1]-cur[1])*64-lift));contact.append(grounded)
 return feet,contact
def card_art():
 card=Image.new('RGBA',(15,19));d=ImageDraw.Draw(card);d.polygon([(1,0),(14,0),(14,16),(12,18),(0,18),(0,2)],fill=k('ivory'),outline=k('rust'));d.rectangle((2,2,11,14),fill='#43515a')
 h=max_layer('SE','head');h=h.crop(h.getbbox());thumb=h.resize((9,11),Image.Resampling.NEAREST);card.alpha_composite(thumb,(2,2));d.line((12,2,12,5),fill=k('cyan'));d.line((3,16,10,16),fill=k('rust'));d.point((12,15),fill=k('rust'))
 return card
def correct_desk():
 floor=D/'source/reference';dst=X/'fixtures';dst.mkdir(parents=True,exist_ok=True)
 b=rgba(floor/'sec-desks-s5-proof-back-r02.png');f=rgba(floor/'sec-desks-s5-proof-front-r02.png');draw=ImageDraw.Draw(f)
 # The reader retains the original sloped top and south lip. Recess a portrait-sized
 # illuminated field and a neighboring paper tray without changing its silhouette.
 draw.polygon([(101,114),(132,114),(136,126),(105,126)],fill='#243e40',outline='#839b91')
 draw.polygon([(104,116),(130,116),(132,123),(106,123)],fill='#406560')
 draw.line((106,117,127,117),fill='#87a9a0');draw.rectangle((147,125,161,133),fill='#a3aaa0',outline='#4d625f');draw.line((148,126,160,126),fill='#d3d6b7')
 for xx,yy in [(81,157),(110,162),(159,159)]:draw.line((xx,yy,xx+3,yy),fill='#adb1a2')
 for fn,im in [('sec-desks-S5-back',b),('sec-desks-S5-front',f),('prop-credential-max',card_art())]:im.save(dst/(fn+'.png'))
 # Gripping pad remains above the bottom left of the separate card.
 tip=Image.new('RGBA',(5,5));dr=ImageDraw.Draw(tip);dr.line((0,3,3,2),fill=k('ink'),width=3);dr.line((0,2,3,1),fill=k('pale'));dr.point((4,1),fill=k('steel'));tip.save(dst/'char-limen-pinch-pad.png')
def feet_for(frames,i):
 meta=frames[i];actor=meta['actors']['STILETTO'];pos=actor['p'];dist=meta['dist']
 if dist<.001 or 129.53<=meta['edit']<138.50:return [(-9,0),(8,1)],0
 # Fixed world-ground marks for every stance half of the gait. Reverse look-up by
 # travelled metres includes the bend under the same authored route.
 lengths=[r['dist'] for r in frames]
 import bisect
 def point_at(distance):
  j=min(len(frames)-1,max(0,bisect.bisect_left(lengths,distance)))
  if j==0:return frames[0]['actors']['STILETTO']['p']
  f=max(0,min(1,(distance-lengths[j-1])/max(.00001,lengths[j]-lengths[j-1])))
  return mix(frames[j-1]['actors']['STILETTO']['p'],frames[j]['actors']['STILETTO']['p'],f)
 result=[]
 cycle=1.12
 for side in [0,1]:
  phase=((dist/cycle)+side*.5)%1;phaseStart=dist-phase*cycle
  if phase<.5:plant=phaseStart+.25*cycle;lift=0
  else:
   a=(phase-.5)*2;plant=phaseStart+cycle*(.25+(a*a*(3-2*a)));lift=5*math.sin(a*math.pi)
  xy=point_at(plant);off=(-6 if side==0 else 7);offy=0
  if phaseStart<.01:
   off=(-9 if side==0 else 8);offy=(0 if side==0 else 1)
   if phase<.5:xy=frames[0]['actors']['STILETTO']['p']
  result.append(((xy[0]-pos[0])*64+off,(xy[1]-pos[1])*64-lift+offy))
 blend=min(1,max(0,(meta['edit']-129.13)/.38))
 if 129.13<=meta['edit']<129.54:result=[mix(a,b,blend) for a,b in zip(result,[(-9,0),(8,1)])]
 return result,math.sin(dist/cycle*math.tau)
def key(s,t):
 if t<=s[0][0]:return s[0][1]
 for (a,v),(b,w) in zip(s,s[1:]):
  if t<b:return v+(w-v)*(t-a)/(b-a)
 return s[-1][1]
def export():
 X.mkdir(exist_ok=True);correct_desk();score=json.loads((D/'work/score.json').read_text());frames=score['frames']
 bank=defaultdict(list);ids=defaultdict(dict);index=[];source_master={};travel=0;prev=None
 distances=[0]
 for i in range(1,len(frames)):distances.append(distances[-1]+math.dist(frames[i-1]['actors']['max']['p'],frames[i]['actors']['max']['p']))
 for i,fr in enumerate(frames):
  t=fr['edit'];feet,walk=feet_for(frames,i)
  aim=key([(125.1,0),(129.17,0),(129.5,.12),(130.2,.16),(130.45,.43),(130.7,1),(137.35,1),(137.6,.96),(137.9,1),(139.14,1),(139.20,.93),(139.8,0)],t)
  reach=key([(125.1,0),(128.9,0),(129.3,.15),(130.1,.24),(130.38,.49),(130.7,1),(137.44,1),(137.65,.86),(137.95,.1),(138.08,0)],t)
  turn=key([(125.1,0),(129.9,0),(130.24,.2),(130.6,.65),(130.9,1),(137.6,1),(138.1,.10)],t)
  dip=key([(125.1,0),(137.6,0),(137.65,.2),(137.90,1),(138.32,.94),(138.7,.66),(139.45,.35),(139.9,.12),(140.1,0)],t)
  cur=fr['actors']['max']['p']
  if prev:travel+=math.dist(cur,prev)
  prev=cur
  receive=key([(125.1,0),(128.99,0),(129.22,1),(129.50,1),(130.5,0)],t)
  lim=build_limen(round(reach*10)/10,round(key([(125,0),(130,0),(131,0),(131.6,1),(132.8,1),(133.1,0),(134.8,0),(135.12,1),(136.3,1),(136.7,0)],t)),round(reach*2),round(receive*8)/8)
  maxFeet,maxContact=max_steps(frames,distances,i)
  lp=fr['actors']['LIMEN']['p'];mp=fr['actors']['max']['p'];pin=lim[2]['prop']
  # Old and new holders touch the same paper corner at transfer. max draws it
  # back to his chest, visibly lowering it out of the comparison as he ducks.
  target=(pin[0]+(lp[0]-mp[0])*64,pin[1]+(lp[1]-mp[1])*64)
  blend=key([(125.1,0),(129.05,0),(129.33,1),(129.48,1),(129.90,0),(137.34,0),(137.60,1),(137.65,1),(137.88,0)],t)
  # Before return keep the issuing hand against max's half of the gap, within
  # natural reach; contact with LIMEN is exact at the later authored return.
  neutral=(116-1.8*turn,181+15*dip)
  if t<130:target=(max(76,target[0]),max(141,target[1]))
  if t>137.65:
   transfer_frame=frames[251];ret=transfer_frame['actors']['max']['p']
   transferpin=build_limen(.9,0,2)[2]['prop'];target=(transferpin[0]+(lp[0]-ret[0])*64,transferpin[1]+(lp[1]-ret[1])*64)
  receiving=mix(neutral,target,blend) if blend else None
  pose={'char-limen':lim,'char-stiletto':build_stil(round(aim*16)/16,walk*4,round(walk*1.8),feet,round(walk*.7)),'char-max':max_pose(turn,dip,maxFeet,receiving)}
  row={'frame':i,'edit':round(t,3),'world':round(fr['world'],4),'durationMs':50,'actors':{},'credential':None}
  for id,(parts,em,sk) in pose.items():
   base=flatten(parts);keyhash=hashlib.sha256(base.tobytes()+em.tobytes()).hexdigest()
   if keyhash not in ids[id]:ids[id][keyhash]=len(bank[id]);bank[id].append((base,em))
   j=ids[id][keyhash]
   row['actors'][id]={'pose':j,'sockets':sk}
   if id=='char-max':row['actors'][id]['feetGrounded']=maxContact
   if i==150:
    a=MASTER/id;a.mkdir(exist_ok=True,parents=True)
    for nm,l in zip(['arm-far','legs','torso-head','arm-near'],parts):l.save(a/(nm+'.png'))
    em.save(a/'emissive.png')
  cardState=('receive' if t<130.7 else 'compare' if t<137.65 else 'return' if t<138.05 else 'returned')
  # The shared state exposes photo compare; custody never transfers to bob. The card
  # is mounted to LIMEN’s pinch for the receival/comparison/return depiction only.
  if 129.15<=t<=138.05:
   holder='max' if t<129.35 or t>=137.65 else 'LIMEN'
   skey=('char-max','hand_r') if holder=='max' else ('char-limen','prop')
   s=row['actors'][skey[0]]['sockets'][skey[1]]
   row['credential']={'entity':'max','visualHolder':holder,'phase':cardState,'pivotNativePx':s,'assetPivotPx':[2,17],'corners':[[s[0]-2,s[1]-17],[s[0]+12,s[1]-17],[s[0]+12,s[1]+1],[s[0]-2,s[1]+1]],'photo_compare':s,'pinchOverlayOffsetPx':[-1,-2]}
  index.append(row)
 atlas={};cache=[]
 for id,pairs in bank.items():
  ad=X/'actors'/id;ad.mkdir(exist_ok=True,parents=True)
  batch=32;atlas[id]=[]
  for start in range(0,len(pairs),batch):
   sub=pairs[start:start+batch];w=min(8,len(sub));h=math.ceil(len(sub)/w)
   image=Image.new('RGBA',(w*256,h*256));glow=Image.new('RGBA',image.size)
   for n,(body,em) in enumerate(sub):
    x=(n%w)*256;y=(n//w)*256;image.paste(body,(x,y));glow.paste(em,(x,y))
    atlas[id].append({'body':f'actors/{id}/base-{start//batch:02}.png','emissive':f'actors/{id}/emissive-{start//batch:02}.png','atlasRect':[x,y,256,256]})
   image.save(ad/f'base-{start//batch:02}.png');glow.save(ad/f'emissive-{start//batch:02}.png')
 names=['char-max','char-limen','char-stiletto']
 out={'schemaVersion':1,'assetIds':names+['sec-desks','prop-credential','sec-rails','sec-boom'],'classification':'composited motion proof; renderer consumes actual PR153 state','acceptedStyle':'B','sharedMaxBodySha256':'e0dc33b98a4076336a569e639776e1ec727804430cacd7879d1af5cadebd1796','portraitSourceSEHeadSHA256':'ab01d04412835e49c2aa15ab480eed8402b9e309472c46d5b38cfd5676675442','sourceSize':[256,256],'pivotPx':[128,208],'sortAnchorPx':[128,208],'groundPixelsPerMetre':64,'fps':20,'firstEditedSecond':125.1,'lastExclusiveEditedSecond':139.9,'additionalExitFrames':{'firstFrame':296,'lastFrameInclusive':300,'lastEditedSecond':140.1,'purpose':'complete the authored duck beyond the source clip; excluded from all review movies'},'frames':index,'poses':atlas,'fixture':{'id':'S5','rectMetres':[130.8,130.9,1.6,1.0],'groundPivot':[131.6,131.9],'pivotPx':[128,208],'back':'fixtures/sec-desks-S5-back.png','front':'fixtures/sec-desks-S5-front.png','contactsPx':{'card_in':[108,120],'card_out':[153,129],'photo_compare':'char-limen.prop track'}},'credential':{'id':'prop-credential','owner':'max','file':'fixtures/prop-credential-max.png','sizePx':[15,19],'pivotPx':[2,17],'portraitSource':'source/max-r2/SE/head.png','pinchPad':'fixtures/char-limen-pinch-pad.png'},'sourceGeometry':'approved-factory/day-one-3','sourceEditDuration':score['duration'],'markers':{'STILETTO_aim_edit':130.7,'comparison_end_edit':137.65,'max_duck_onset_edit':137.65,'reach_return_edit':138.05,'STILETTO_release_edit':139.2}}
 (X/'lane03-pose-manifest.json').write_text(json.dumps(out,separators=(',',':')))
 print('Distinct poses', {k:len(v) for k,v in bank.items()})
if __name__=='__main__':export()

from pathlib import Path
import hashlib,json,zipfile
from PIL import Image
D=Path(__file__).resolve().parents[1];M=D/'exports/lane03-pose-manifest.json'
m=json.loads(M.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files():
 candidates=[D/'README.md',D/'work/score.json',*(D/'exports').rglob('*'),*(D/'source').rglob('*'),*(D/'review').rglob('*')]
 return sorted(p for p in candidates if p.is_file() and '__pycache__' not in p.parts)
a=[]
for p in files():
 r={'path':str(p.relative_to(D)),'sha256':digest(p),'bytes':p.stat().st_size}
 if p.suffix=='.png':
  with Image.open(p) as im:r['width'],r['height']=im.size
 a.append(r)
meta=D/'file-manifest.json';meta.write_text(json.dumps({'revision':'lane03-r3','frames':296,'files':a},indent=2))
dest=D/'Loopforge-Lane03-Fourth-ID-Check.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in [*files(),meta]:z.write(p,'lane03/'+str(p.relative_to(D)))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 for item in a:assert hashlib.sha256(z.read('lane03/'+item['path'])).hexdigest()==item['sha256']
print(len(a),dest.stat().st_size,digest(dest))

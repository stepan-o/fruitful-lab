/* Export camera events and existing proxy draw calls. Art remains downstream of approved state. */
const fs = require('node:fs'), vm=require('node:vm'), crypto=require('node:crypto'), path=require('node:path');
const input=process.argv[2]||'/tmp/loopforge-art-tab-daem591W/apps/lab/public/loopforge-design/day-one-rehearsal.html';
const source=fs.readFileSync(input,'utf8');
const hash=crypto.createHash('sha1').update('blob '+Buffer.byteLength(source)+'\0').update(source).digest('hex');
if(hash!=='a41039c08c873e6496a420ba2f599bb9bd3183b0')throw Error('Wrong rehearsal source');
const scoreData=source.match(/<script id="score-data" type="application\/json">([\s\S]*?)<\/script>/)[1];
const moduleCode=source.match(/<script type="module">([\s\S]*?)<\/script>/)[1];
let setup=moduleCode.slice(0,moduleCode.indexOf('function selectObject(')).replaceAll('export function','function');
setup=setup.replace('for(const q of floor.fixtures){',"for(const q of floor.fixtures){if(q.id==='forge')continue;")
 .replace('if(whole)continue;', "if(whole||id==='bob')continue;")
 .replace('  drawNames(names);','');
const elem={append(){},setAttribute(){},add(){},querySelector(){return this},insertRow(){return this},insertCell(){return this}};
const dictionary={};const framesets=[];
for(const [vw,vh] of [[1280,720],[390,844],[320,844]]){
 const mobile=vw<=620;
 const width=Math.min(vw,1100)-2*(mobile?8:24)-2;
 const height=Math.floor((mobile?Math.min(440,Math.max(270,.43*vh)):Math.min(535,Math.max(310,.5*vh)))*64)/64;
 const frame=[];let commands=[];
 const ctx=new Proxy({}, {set(o,k,v){o[k]=v;commands.push(['set',k,v]);return true},get(o,k){if(k==='measureText')return txt=>({width:txt.length*6});return (...args)=>commands.push([k,...args])}});
 function end(){
  const buf=JSON.stringify(commands),key=crypto.createHash('sha1').update(buf).digest('hex').slice(0,14);
  if(!dictionary[key])dictionary[key]=commands;commands=[];return key;
 }
 const script=setup+`
 width=stageWidth;height=stageHeight;
 for(let n=0;n<184;n++){
  time=101.3+n/20;const w=score.worldTime(time),voices=score.speech.filter(s=>s.start<=w&&w<s.end);
  const v='line';chooseCamera(v,w);
  drawBuilding(w,v);const ground=saveOps();
  equipment(w,v);const scenery=saveOps();
  brains(w);drawCast(w,voices);const other=saveOps();
  const world=samplePath(score.tracks.bob,w).p;
  const jam=w>101.6&&w<109.3-1e-8;
  send({n,edited:time,world:w,voices:voices.map(v=>({speaker:v.speaker,text:v.text})),scale,center,bob:world,
    actorPx:project(world),fixturePx:project([130,145]),stage:[width,height],ground,scenery,other,jam,
    products:score.products.map(q=>({id:q.id,p:samplePath(q.keys,w).p})),cast:actors.map(id=>({id,p:samplePath(score.tracks[id],w).p})),
    action:score.cues.filter(q=>q.actor==='bob'&&q.start<=w&&w<q.end).map(q=>q.label)});
 }`;
 vm.runInNewContext(script,{document:{querySelector:q=>q==='#score-data'?{textContent:scoreData}:{getContext:()=>ctx},getElementById:()=>elem,createElementNS:()=>elem},Option:class{},stageWidth:width,stageHeight:height,saveOps:end,send:o=>frame.push(o)});
 framesets.push({viewport:[vw,vh],frames:frame});
}
fs.writeFileSync(path.join(__dirname,'pinned-score.json'),JSON.stringify({htmlGitBlob:hash,geometry:'approved-factory/day-one-3',start:101.3,end:110.5,framesets}));
fs.writeFileSync(path.join(__dirname,'draw-cache.json'),JSON.stringify(dictionary));
console.log(Object.keys(dictionary).length,'unique scene planes',framesets.map(s=>[s.viewport,s.frames[0].scale,[...new Set(s.frames.map(x=>x.bob.join(',')))].slice(0,5)]));

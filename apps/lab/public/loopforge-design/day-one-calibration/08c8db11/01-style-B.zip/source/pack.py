"""Verify the two approved-for-selection materials and preserve provenance."""
import json,hashlib,zipfile,shutil
from pathlib import Path
from PIL import Image,ImageChops,ImageDraw
from revise import CFG
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'png'
REF=ROOT.parent/'01-two-room-exemplar'/'refs'
def digest(b):return hashlib.sha256(b).hexdigest()
def record(path,base=ROOT):
    item={'path':path.relative_to(base).as_posix(),'sha256':digest(path.read_bytes()),'bytes':path.stat().st_size}
    if path.suffix=='.png':
        with Image.open(path) as i:item.update(width=i.width,height=i.height,mode=i.mode,sRGB=('srgb' in i.info))
    return item
def write(path,data):
    (ROOT/path).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def open_png(name):return Image.open(OUT/(name+'-r02.png')).convert('RGBA')
def roles(room):
    pfx='png/env-floor-kit-'+room+'-'
    return {'editableMaterialBottomToTop':[pfx+x+'-r02.png' for x in ('base','joints','wear')],
            'flatMaterial':pfx+'flat-r02.png','lightPass':'png/env-light-shadow-'+room+'-practical-r02.png',
            'alphaMask':'png/env-light-shadow-'+room+'-mask-r02.png','litConvenienceComposite':pfx+'lit-r02.png',
            'blend':'straight sRGB alpha-over at 100%, no premultiplication',
            'roomExtentMetres':[4,4],'nativePixels':[256,256],'floorPixelsPerMetre':64,
            'pivotPx':[0,0],'sortAnchorPx':[0,0],'trimRect':[0,0,256,256],
            'layer':'floor','sockets':{},'frameCount':1,'durationMs':None}
checks={}
tproof=Image.new('RGB',(768,512))
for ri,r in enumerate(('security','forge')):
    parts=[open_png('env-floor-kit-'+r+'-'+x) for x in ('base','joints','wear','flat','lit')]
    mat=Image.alpha_composite(Image.alpha_composite(parts[0],parts[1]),parts[2])
    light=open_png('env-light-shadow-'+r+'-practical')
    assert mat.tobytes()==parts[3].tobytes()
    assert Image.alpha_composite(mat,light).tobytes()==parts[4].tobytes()
    assert light.getchannel('A').tobytes()==open_png('env-light-shadow-'+r+'-mask').getchannel('A').tobytes()
    assert all(Image.open(p).info.get('srgb')==0 for p in OUT.glob('*-r02.png'))
    tile=Image.new('RGBA',(512,512))
    for xx in (0,256):
        for yy in (0,256):tile.paste(mat,(xx,yy))
    tproof.paste(tile.crop((128,128,512,384)),(384*ri,0))
    tproof.paste(tile.resize((256,256),Image.Resampling.NEAREST),(384*ri,256))
    checks[r]={'materialReassemblyByteEqualRGBA':True,'litReassemblyByteEqualRGBA':True,'practicalAlphaMatchesMask':True,'testedRepeatRates':[1,.5]}
tproof.save(ROOT/'tile-proof-r02.png')
desk={'assetId':'sec-desks','buildMarker':'S5','use':'Depth-test silhouette of the ID checking desk. Calibration proof only.','sourceSize':[256,256],
      'groundTopLeftPx':[77,144],'groundBottomRightExclusivePx':[179,208],'pivotPx':[128,208],'sortAnchorPx':[128,208],'trimRect':[0,0,256,256],
      'groundFootprintMetres':[1.6,1.0],'worldTopLeftMetres':[130.8,130.9],'worldPivotMetres':[131.6,131.9],
      'groundPixelsPerMetre':64,'metricHeight':1.02,'proofVerticalPixelsPerMetre':40,'risePx':41,
      'back':'png/sec-desks-s5-proof-back-r02.png','front':'png/sec-desks-s5-proof-front-r02.png',
      'sockets':{},'clips':[],'registrationNotes':'Untrimmed origins match. Physical ground footprint and projected top are independent. A final fixture will need named prop/hand contact sockets.'}
write('floor-fixture-manifest-r02.json',{'schemaVersion':1,'status':'art-director-selected-for-owner-review','revision':'r02',
    'geometry':'approved-factory/day-one-3','sourceCommit':'d0e85b3a8d29b39da320d342fdff40847c478c8c','projection':'Ground x east, y south, height rises to screen north.',
    'assets':{'env-floor-kit':{r:roles(r) for r in CFG},'env-light-shadow':{'calibrationScope':'Ground practical color overlays and straight-alpha white masks only. Actor lighting, shadow and emissives are provided by character/integration.',
        'colorOverlays':[roles(r)['lightPass'] for r in CFG],'whiteAlphaMasks':[roles(r)['alphaMask'] for r in CFG]},'sec-desks':desk},
    'clips':[],'markers':[],'verification':checks,'dependencies':['owner style selection','runtime sort and world-to-pixel validation'],
    'files':[record(p) for p in sorted(OUT.glob('*-r02.png'))]})
pal={'sharedReference':{'Security enamel starting reference':'#A7B2D3','Lobby-Conveyor enamel starting reference':'#666860','ground occlusion ink':'#14292B','dull steel contact edge':'#59706B'},
     'security':{'dry main plate':'#203C3D','raised plane':'#273F42','shadow':'#193335','open joint':'#12292B','touched edge':'#546560','practical field':'#82C9C5','stepped tube return':'#85C7BB'},
     'forge':{'dry main plate':'#3F3830','oxide':'#583E2D','open joint':'#23211E','ragged edge':'#715941','patinated seam':'#453A36','field':'#ED872F','louver core':'#FFBE5E'},
     'desk':{'ink':'#14292B','under-frame':'#1C3234','case':'#32494A','reader hood':'#61736A','reader glass':'#1A3234','slot':'#152B2D','polished lip':'#ABB09A','card tray':'#98A18C'}}
write('floor-palette-roles-r02.json',pal)
with (ROOT/'floor-palette-r02.gpl').open('w') as fh:
    fh.write('GIMP Palette\nName: Loopforge Day One environment calibration r02\nColumns: 4\n#\n')
    for g,cols in pal.items():
        for name,h in cols.items():
            vals=bytes.fromhex(h[1:]);fh.write('%3d %3d %3d  %s / %s\n'%(*vals,g,name))
with zipfile.ZipFile(next((REF/'production').glob('*.zip'))) as z:
    embedded={name:digest(z.read('loopforge-day-one-2d/'+name)) for name in ('HANDOFF.md','briefs/sec-desks.md','scene-bindings.json','reference/approved-factory.json','reference/factory-floor-plan.svg')}
write('floor-provenance-r02.json',{'parentPack':'01-two-room-exemplar.zip','geometry':'approved-factory/day-one-3','referenceFiles':[record(REF/p,REF) for p in ('rooms/security.webp','rooms/forge.webp','rehearsal/fourth-check.png','rehearsal/press.png','maps/checkpoint.svg','maps/press.svg','asset-notes/env-floor-kit.md','asset-notes/env-light-shadow.md','production/day-one-2d.27ccffdd47398e1f.zip')],'embeddedFilesSHA256':embedded,
    'sourceArt':{'study':record(ROOT/'source/material-concept.png'),'method':'ImageGen, original text-prompted two-panel industrial floor material study. Retained as source and low-frequency grayscale grain input. Both plate layouts, geometry, damage, practicals, S5 and occluders are originally authored as native-coordinate raster artwork. Concept pixels were not used as a flattened floor.',
    'originalRoomArtUse':'Visual reference only. Room paintings and rehearsal stills are supplied by the project owner and are not embedded in the exported art.',
    'sourceScripts':[record(ROOT/'source'/p) for p in ('draw.py','revise.py','pack.py')],'software':'Python 3, Pillow 12.3.0; deterministic geometry and fixed random seeds.'},
    'revisions':[{'id':'r01','disposition':'rejected as submitted','reason':'Plate families looked similar; amber lacked a source and the desk top resembled a cabinet.'},{'id':'r02','disposition':'selected by Art Direction for initial owner style review','changes':'Separated practicals and material response, added flush queue grip, warm heat louver and soot joint, rebuilt sloped photo-reader housing, slot and worn south lip.'}]})

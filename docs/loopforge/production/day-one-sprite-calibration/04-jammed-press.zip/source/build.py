"""Register the painted SE bob master to the measured C4 press; hand-keyed performance."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,PngImagePlugin,ImageChops
import math,json,hashlib
R=Path(__file__).resolve().parents[1]; SRC=R/'source';A=R/'exports/actor';F=R/'exports/fixture'; PROOF=R/'proofs'
AS=(256,256);FS=(320,440);FP=(32,164); AP=(141,126); AO=(13,-82); HIT=(166,178); FXH=(179,96)
p=json.loads(next((SRC/'master').glob('*palette.json')).read_text())['base']
def z(size=AS):return Image.new('RGBA',size)
def put(i,n):
 meta=PngImagePlugin.PngInfo();meta.add(b'sRGB',b'\0');i.save(n,pnginfo=meta)
def src(n):return Image.open(next((SRC/'master').glob('*-'+n+'.png'))).convert('RGBA')
def scatter(im,dx,dy):
 o=z(im.size);o.alpha_composite(im,(dx,dy));return o
def whitealpha(n,alpha):
 a=n.copy();a.putalpha(alpha);return a
neutral=src('base');light=Image.open(SRC/'selected-B-actor-light.png').convert('RGBA');em=Image.open(SRC/'selected-B-emissive.png').convert('RGBA')
parts=[src(t) for t in ('01-arm-far','02-lower-body','03-torso-head','04-arm-near')]
# Frame order, durations and specific landmarks within the authored knock.
# torso lateral offset and sagittal slouch, elbow, palm heel and free arm swing
POSES=[
 ('injured-hold',-3,2,(141,177),(148,186),-1),
 ('listen',-3,1,(140,177),(148,185),-1),
 ('look-door',0,2,(143,176),(151,183),0),
 ('brace',-5,4,(132,171),(142,166),-1),
 ('wind',-11,5,(123,165),(124,153),-3),
 ('swing',-3,5,(137,174),(145,165),-2),
 ('drive',7,5,(146,174),(159,173),1),
 ('contact',13,4,(151,173),HIT,4),
 ('release',6,2,(145,171),(156,164),2),
 ('recoil',-12,-2,(119,161),(127,148),-4),
 ('backcatch',-9,5,(118,173),(130,164),-4),
 ('recover',-3,3,(141,175),(149,181),-2)]
# Time is edited score time. The numeric jam transition comes from the pinned player.
TIMES=[(101.3,0),(101.6,1),(103.6,0),(103.7,2),(106.5,0),(106.6,1),(108.5,3),(108.60,4),(108.72,5),(108.82,6),(108.90,7),(109.02,8),(109.12,9),(109.32,10),(109.56,11),(109.80,0)]
DOORS=[(101.3,0),(108.9,0),(108.96,1),(109.02,2),(109.08,3),(109.15,4),(109.24,5),(109.35,6)]
def draw_arm(sh,el,hand,style,contact,lit=False):
 im=z();d=ImageDraw.Draw(im)
 col={'x':'#17252e','d':'#51433c','b':'#977558','t':'#cba57d','q':'#112f42','n':'#1a3c59','h':'#245883','a':'#457fa5','j':'#749bb1','e':'#c9aa87'} if lit else p
 def rod(a,b,th):
  d.line((a,b),fill=col['x'],width=th+2);d.line((a,b),fill=col['n'],width=th)
  aa,bb=tuple(round(a[k]+(b[k]-a[k])*.18) for k in (0,1)),tuple(round(a[k]+(b[k]-a[k])*.72) for k in (0,1))
  d.line((aa,bb),fill=col['h'],width=max(2,th-1));d.line((aa[0],aa[1]-1,bb[0],bb[1]-1),fill=col['a'],width=1)
 def hub(point):
  x,y=point;d.ellipse((x-2,y-2,x+2,y+2),fill=col['x']);d.ellipse((x-1,y-1,x+1,y+1),fill=col['b']);d.point((x,y),fill=col['d']);d.point((x-1,y-1),fill=col['t'])
 x,y=hand
 wrist=(x-4,y+1 if contact else y+2)
 rod(sh,el,4);rod(el,wrist,4);hub(sh);hub(el)
 if contact:
  # Palm heel is the outermost lower edge. Fingers stay visibly raised and back.
  d.polygon([(x-5,y+2),(x-6,y-4),(x-5,y-9),(x-4,y-9),(x-4,y-5),(x-2,y-8),(x-1,y-7),(x-2,y-4),(x-1,y-1),(x,y),(x,y+1),(x-3,y+2)],fill=col['x'])
  d.polygon([(x-4,y),(x-5,y-4),(x-4,y-6),(x-3,y-3),(x-2,y-2),(x,y),(x-2,y+1)],fill=col['t']);d.point((x,y),fill=col['e'])
  d.line((x-5,y-3,x-3,y-4,x-2,y-1,x-1,y),fill=col['b'],width=2)
  d.line((x-5,y-7,x-5,y-4),fill=col['t'])
  d.line((x-3,y-8,x-3,y-6),fill=col['e'])
  d.line((x-5,y+1,x-2,y+1),fill=col['t'])
  d.line((x-8,y-1,x-6,y-1),fill=col['f'] if 'f' in col else col['a'])
  d.point((x,y),fill=col['e'])
 else:
  d.polygon([(x-5,y+2),(x-5,y-2),(x-4,y-6),(x-3,y-7),(x-2,y-6),(x-3,y-3),(x,y-5),(x+1,y-4),(x-1,y-1),(x,y),(x,y+2),(x-3,y+3)],fill=col['x'])
  d.line((x-4,y-4,x-4,y,x-2,y+1),fill=col['b'],width=2);d.point((x-2,y),fill=col['t'])
 return im
def deform(layer,idx,part):
 name,dx,dy,el,hand,swing=POSES[idx]
 if part=='torso':
  # Tilt around the intact pelvis; the glass and chest stripe remain the painted master.
  o=z()
  last=None
  for y in range(142,183):
   w=min(1,max(0,(182-y)/20))
   new_y=y+round(dy*w);xx=round(dx*(.18+.82*w))
   strip=layer.crop((0,y,256,y+1))
   if last is not None and new_y>last+1:o.alpha_composite(strip,(xx,new_y-1))
   o.alpha_composite(strip,(xx,new_y));last=new_y
  return o
 if part=='legs':
  # Loaded right sole is fixed. Disabled left knee folds inward, toe remains just planted.
  o=z()
  for y in range(176,212):
   for x in range(119,141):
    val=layer.getpixel((x,y))
    if not val[3]:continue
    left=(x>129 if y<200 else x>=130)
    fac=max(0,1-abs(y-192)/13)
    ox=round(-3*fac) if left else 0
    oy=-1 if left and 187<y<202 else 0
    # Pelvis shifts onto anatomical right regardless of recoil.
    if y<187:ox+=round(-2*(187-y)/10)
    o.putpixel((x+ox,y+oy),val)
  # The telescoping lumbar connection sits behind the master pelvis during the tilt.
  if layer.getpixel((126,181))[3]:
   ld=ImageDraw.Draw(o)
   ld.line((126,183,128+round(dx*.18),177+round(dy*.18)),fill='#293b42',width=4)
   ld.line((125,182,127+round(dx*.18),177),fill='#8d795e',width=1)
  return o
 if part=='near':
  o=z()
  for y in range(161,194):
   f=max(0,min(1,(y-164)/24));ox=round(dx*(1-f)*.6+swing*f);oy=round(dy*.7-abs(swing)*f)
   o.alpha_composite(layer.crop((0,y,256,y+1)),(ox,y+oy))
  return o
def composite(seq):
 im=z(seq[0].size)
 for v in seq:im.alpha_composite(v)
 return im
def actor(idx,write=True):
 name,dx,dy,el,hand,swing=POSES[idx];shoulder=(124+round(dx*.9),166+dy)
 raw=[deform(parts[1],idx,'legs'),deform(parts[2],idx,'torso'),deform(parts[0],idx,'near'),draw_arm(shoulder,el,hand,0,idx==7)]
 # Glass emission and selected light follow the same authored spline as their underlying material.
 lit=[]
 for source,kind in ((parts[1],'legs'),(parts[2],'torso'),(parts[0],'near')):
  a=source.getchannel('A')
  mod=source.copy()
  l=whitealpha(light,ImageChops.multiply(light.getchannel('A'),a));mod.alpha_composite(l)
  lit.append(deform(mod,idx,kind))
 lit.append(draw_arm(shoulder,el,hand,0,idx==7,True))
 body=composite(raw);full=composite(lit);emiss=deform(em,idx,'torso')
 mask=ImageChops.difference(body.convert('RGB'),full.convert('RGB'));rr,gg,bb=mask.split()
 al=ImageChops.lighter(ImageChops.lighter(rr,gg),bb).point(lambda x:255 if x else 0)
 overlay=whitealpha(full,ImageChops.multiply(al,full.getchannel('A')))
 assert Image.alpha_composite(body,overlay).tobytes()==full.tobytes()
 if write:
  for suffix,im in zip(('lower-body','torso-head','free-arm','striking-arm','base','forge-light','emission'),[*raw,body,overlay,emiss]):
   put(im,A/f'char-bob-palm-unjam-SE-{idx:02d}-{suffix}.png')
 return (body,overlay,emiss)
def fixture():
 base=z(FS);rear=z(FS);front=z(FS);control=z(FS);d=ImageDraw.Draw(base)
 def plate(d,pts,fill,line=None):
  d.polygon(pts,fill=fill)
  if line:d.line(pts+[pts[0]],fill=line,width=2)
 def bolt(d,x,y):
  d.ellipse((x-3,y-3,x+3,y+3),fill='#242a2b');d.ellipse((x-2,y-2,x+2,y+2),fill='#7e735f');d.line((x-1,y-1,x+1,y),fill='#443f39')
 # The full 256x256 load bed sits on the 4m footprint; a cutaway exposes the north work face.
 plate(d,[(41,164),(277,164),(287,177),(287,407),(277,419),(42,419),(32,410),(32,177)],'#34383a','#22282b')
 plate(d,[(45,171),(273,171),(280,180),(280,397),(272,405),(45,405),(38,397),(38,180)],'#534c43','#787361')
 for y in (188,229,273,315,358,395):
  d.line((45,y,269,y),fill='#353635',width=2);d.line((61,y+2,250,y+2),fill='#77664d')
 for x in (64,253):
  d.rectangle((x-9,180,x+10,406),fill='#333b3b');d.rectangle((x-5,181,x+6,401),fill='#615e50');d.line((x-4,183,x-4,400),fill='#aa946d',width=2)
  for y in (197,239,277,320,361,395):bolt(d,x,y)
 # Belt cradle in/out runs across east/west through the rear of the machine.
 d.rectangle((41,255,278,292),fill='#242c2c')
 for x in range(47,277,15):
  d.rectangle((x,260,x+9,288),fill='#53534c');d.line((x+2,261,x+2,284),fill='#786a55')
 d.rectangle((40,252,278,258),fill='#897456');d.rectangle((40,288,278,294),fill='#675946')
 # Servo cylinders, broad dark painted carriage and bright worn rings.
 d=ImageDraw.Draw(rear)
 for x,w,ystart in [(58,28,92),(239,29,78)]:
  plate(d,[(x,ystart+12),(x+6,ystart),(x+w-4,ystart),(x+w,ystart+5),(x+w,243),(x+w-5,253),(x,251)],'#3a4543','#222b2c')
  d.rectangle((x+7,ystart+16,x+w-7,232),fill='#63706a');d.rectangle((x+10,ystart+18,x+13,233),fill='#899084');d.rectangle((x+15,ystart+18,x+18,232),fill='#4f5149')
  for y in (ystart+18,175,219):
   d.rectangle((x-2,y,x+w+2,y+8),fill='#343c3c');d.line((x,y+1,x+w,y+1),fill='#a08d68',width=2)
  for y in (ystart+9,245):bolt(d,x+5,y)
 plate(d,[(49,125),(65,115),(92,115),(106,127),(106,202),(98,212),(48,212)],'#4d5551','#293234')
 # A localized recess behind the animated right jaw, light enough to see release width.
 plate(d,[(168,69),(225,69),(239,77),(239,152),(233,163),(165,163),(160,152),(160,83)],'#222b2c','#645b4a')
 d.rectangle((167,85,232,147),fill='#151d21')
 d.line((164,147,164,88,169,81,217,81),fill='#a18359',width=2)
 d.line((165,144,165,122),fill='#c3975e')
 d.line((171,82,187,82),fill='#c39b67',width=2)
 for y in (92,106,120,134):d.line((166,y,228,y),fill='#413c35',width=2)
 d.rectangle((169,148,226,154),fill='#946940');d.line((178,148,221,148),fill='#c08b51')
 # South drawbar, removable die, vertical edge shade and top bolts.
 plate(d,[(96,170),(216,170),(236,184),(235,209),(225,217),(86,217),(78,207),(78,185)],'#49504b','#252f30')
 plate(d,[(100,174),(213,174),(227,184),(218,191),(95,191),(85,185)],'#666657')
 d.line((93,192,220,192),fill='#9a8968',width=2);d.rectangle((106,198,207,206),fill='#353d3c')
 for x in (92,219):bolt(d,x,201)
 # Foreground guard rails are split, leaving the working hand and the bright door edge exposed.
 d=ImageDraw.Draw(front)
 for pts in [[(41,136),(47,129),(76,129),(80,133),(80,152),(72,152),(72,137),(49,137),(49,183),(42,183)],
             [(210,116),(217,110),(273,110),(279,116),(279,197),(270,197),(270,120),(218,120),(218,168),(210,168)]]:
  plate(d,pts,'#4c554e','#263236')
 d.line((216,112,272,112,276,117),fill='#a39a78',width=2);d.line((44,138,44,171),fill='#8d8b71',width=2)
 d.line((212,129,212,155),fill='#a79165',width=2)
 for x,y in [(45,176),(213,158),(274,188)]:bolt(d,x,y)
 # North operator control to the side of the running door.
 d=ImageDraw.Draw(control);plate(d,[(219,83),(236,83),(242,88),(241,104),(235,109),(217,106),(216,90)],'#434b47','#1f292b')
 d.line((220,85,235,85),fill='#ad9978');d.ellipse((222,91,230,99),fill='#1e292a')
 d.line((226,94,233,83),fill='#121d21',width=5);d.line((226,94,233,83),fill='#8c7856',width=3);d.rounded_rectangle((231,79,239,85),radius=2,fill='#d0ac75')
 # The tip of a shroud sits ahead of the wrist plane, below the strike edge.
 d=ImageDraw.Draw(front)
 d.polygon([(189,108),(201,104),(214,104),(216,108),(203,108),(192,112)],fill='#3b4542')
 d.line((191,107,201,103,214,103),fill='#9f8e6b')
 d.polygon([(163,93),(166,93),(178,100),(196,102),(204,100),(209,104),(202,106),(177,104),(165,97),(163,96)],fill='#374443')
 d.line((164,93,166,93,177,100,189,101),fill='#9c906e')
 # A worker on the north aisle moves behind the western column on departure.
 # This slice is the same painted housing sampled from the locked rear drawing.
 western=rear.crop((46,91,107,214));front.alpha_composite(western,(46,91))
 # Keep the north-facing entrance rail in front of that column.
 d=ImageDraw.Draw(front)
 d.polygon([(41,136),(47,129),(76,129),(80,133),(80,152),(72,152),(72,137),(49,137),(49,183),(42,183)],fill='#4c554e',outline='#263236')
 d.line((45,136,48,131,75,131),fill='#8d8b71',width=2)
 return base,rear,control,front
def door(k):
 # Actual rehearsal right jaw spans .86m, open at x132.62 rather than 132.30.
 # Calibrated native travel 20px. State 0 remains half-open until confirmation.
 shifts=[0,2,7,15,22,20,20];x=179+shifts[k];im=z(FS);d=ImageDraw.Draw(im)
 d.polygon([(x,83),(x+7,78),(x+46,78),(x+54,86),(x+54,145),(x+47,152),(x+2,152),(x,149)],fill='#2b3031')
 d.polygon([(x+1,84),(x+7,80),(x+44,80),(x+51,87),(x+51,139),(x+45,146),(x+2,146)],fill='#60584b')
 d.line((x,86,x,144),fill='#d4ad72',width=2);d.line((x+3,89,x+3,140),fill='#9d794e',width=2)
 d.rectangle((x+8,89,x+45,132),fill='#54554b')
 d.polygon([(x+5,89),(x+12,84),(x+42,84),(x+45,86),(x+42,91),(x+24,91),(x+20,94),(x+6,95)],fill='#86745a')
 d.line((x+7,87,x+13,84,x+28,84),fill='#c29869',width=2)
 d.polygon([(x+6,134),(x+35,134),(x+32,139),(x+9,139)],fill='#75664f');d.line((x+9,90,x+41,90),fill='#797769',width=2)
 for y in (99,109,119):
  d.line((x+13,y,x+35,y),fill='#343c3a',width=3);d.line((x+15,y+2,x+34,y+2),fill='#74705e')
 for xx,yy in [(x+7,85),(x+44,139)]:d.ellipse((xx-2,yy-2,xx+2,yy+2),fill='#79735e')
 d.line((x+5,146,x+25,146),fill='#b09872',width=2)
 return im
def display_panel(idx,k,marked=False):
 room=Image.open(SRC/'selected-B-floor.png').convert('RGBA')
 pic=z(FS)
 for x in (-147,109):
  for y in (-130,126,382):pic.alpha_composite(room,(x,y))
 b,r,c,g=fixture()
 for v in (b,r,door(k),c):pic.alpha_composite(v)
 sh=Image.open(SRC/'selected-B-shadow.png').convert('RGBA');pic.alpha_composite(sh,AO)
 for v in actor(idx,False):pic.alpha_composite(v,AO)
 pic.alpha_composite(g)
 if marked:
  d=ImageDraw.Draw(pic);x,y=FXH;d.line((x-2,y-3,x-11,y-12,x-34,y-12),fill='#f6dca0');d.line((x+2,y+3,x+15,y+15,x+34,y+15),fill='#f6dca0')
 return pic
def print_early():
 for idx in range(len(POSES)):actor(idx)
 for label,im in zip(('base','rear-guard','control','front-guard'),fixture()):put(im,F/f'mach-forge-C4-{label}.png')
 for k in range(7):put(door(k),F/f'mach-forge-C4-door-{k}.png')
 for marked in (False,True):
  out=Image.new('RGB',(900,242),'#142222');d=ImageDraw.Draw(out)
  for i,(idx,k,cap) in enumerate([(4,0,'01   Brace'),(7,0,'02   Heel meets door'),(9,4,'03   Recoil and release')]):
   pic=display_panel(idx,k,marked and idx==7)
   crop=pic.crop((26,41,276,218)).resize((250,177),Image.Resampling.NEAREST)
   out.paste(crop,(i*300+25,33));d.text((i*300+25,216),cap,fill='#efdfbd')
   if marked and idx==7:
    x=i*300+25+(179-26);y=33+(96-41);d.line((x,y-4,x+2,y-4),fill='#ffca57')
  d.text((25,9),'C4  /  NATIVE WORKING FACE     ' + ('CONTACT MARKERS' if marked else 'CLEAN PIXELS'),fill='#dfbe83')
  out.save(PROOF/('early-marked.png' if marked else 'early-clean.png'))
if __name__=='__main__':print_early()

"""Editable, native-pixel plate rig. All actor bodies use the same 256px frame/pivot."""
from pathlib import Path
from functools import lru_cache
from PIL import Image,ImageDraw,ImageOps
import math,colorsys,json

D=Path(__file__).resolve().parents[1]
REF=D.parent/'03-fourth-id-check/refs'
PIV=(128,208)
PAL={
 'ink':'#14242b','shadow':'#23343a','joint':'#35484c','deep':'#445654','smoke':'#677a76',
 'steel':'#8b9b91','pale':'#afbcaa','crest':'#d5ddc5','teal':'#1d5c65','cyan':'#38a6b2','ice':'#88eee3',
 'gun':'#2b383e','black':'#182329','carbon':'#36434c','edge':'#64737a','sliver':'#94a8a4',
 'red':'#ad4c49','shadeRed':'#723f3e','fire':'#ee8665','ochre':'#9f8262','ivory':'#e2d8b6',
 'paper':'#c9be9d','rust':'#785f50','white':'#e3ebd5'}
def layer():return Image.new('RGBA',(256,256))
def k(a):return PAL.get(a,a)
def px(p):return tuple(round(v) for v in p)
def T(x,y):return (128+x,208+y)
def poly(im,points,c):
 if len(points)>2:ImageDraw.Draw(im).polygon([px(T(*q)) for q in points],fill=k(c))
def ln(im,p,q,c,w=1):ImageDraw.Draw(im).line([px(T(*p)),px(T(*q))],fill=k(c),width=w)
def oval(im,x,y,rx,ry,c):
 a,b=px(T(x-rx,y-ry));h,j=px(T(x+rx,y+ry));ImageDraw.Draw(im).ellipse((a,b,h,j),fill=k(c))
def box(im,x,y,w,h,c):
 a,b=px(T(x,y));ImageDraw.Draw(im).rectangle((a,b,a+w-1,b+h-1),fill=k(c))
def shifted(pts,x,y):return [(x+u,y+v) for u,v in pts]
def mix(a,b,v):return tuple(x+(y-x)*v for x,y in zip(a,b))
def dense_plate(im,a,b,r,s,col,shine,deep='joint',cut=0):
 dx,dy=b[0]-a[0],b[1]-a[1];length=max(.1,math.hypot(dx,dy));u,v=-dy/length,dx/length
 def ob(p,r):return (p[0]+u*r,p[1]+v*r)
 pp=[ob(mix(a,b,.03),-.7*r),ob(mix(a,b,.14),-r),ob(mix(a,b,.85),-s),ob(b,-.65*s),ob(b,.55*s),ob(mix(a,b,.82),s),ob(mix(a,b,.10),r),ob(a,.55*r)]
 poly(im,pp,'ink')
 poly(im,[ob(mix(a,b,.07),-.66*r),ob(mix(a,b,.18),-.84*r),ob(mix(a,b,.8),-.76*s),ob(mix(a,b,.95),-.43*s),ob(mix(a,b,.92),.5*s),ob(mix(a,b,.14),.69*r)],col)
 poly(im,[ob(mix(a,b,.12),-.71*r),ob(mix(a,b,.19),-.83*r),ob(mix(a,b,.63),-.6*s),ob(mix(a,b,.53),-.24*s),ob(mix(a,b,.20),-.21*r)],shine)
 poly(im,[ob(mix(a,b,.2),.42*r),ob(mix(a,b,.15),.68*r),ob(mix(a,b,.84),.75*s),ob(mix(a,b,.9),.32*s)],deep)
 if cut:ln(im,ob(mix(a,b,.68),-.6*s),ob(mix(a,b,.74),.48*s),deep)
def joint(im,p,r,c='joint',shine='smoke'):
 x,y=p;oval(im,x,y,r,r,'ink');oval(im,x,y,max(r-1,1),max(r-1,1),c)
 if r>=3:ln(im,(x-r+1,y-1),(x-1,y-r+1),shine);box(im,x,y,1,1,'ink')
def foot(im,p,kind,side):
 x,y=p;flip=-1 if kind=='STILETTO' else 1
 coords=[(-4,-6),(3,-6),(5,-3),(7,0),(6,2),(-4,2),(-5,0)]
 poly(im,[(x+xx*flip,y+yy) for xx,yy in coords],'ink')
 poly(im,[(x+xx*flip,y+yy) for xx,yy in [(-3,-5),(2,-5),(4,-2),(5,0),(-3,0)]], 'carbon' if flip<0 else 'steel')
 ln(im,(x-2,y-3),(x+2,y-4),'edge' if flip<0 else 'pale')
def leg(im,hip,knee,toe,kind,near):
 armored=kind=='LIMEN'
 pal=('steel','pale','deep') if armored else ('carbon','edge','gun')
 if not near:pal=('smoke','steel','deep') if armored else ('gun','carbon','black')
 dense_plate(im,hip,knee,6 if armored else 4.5,4,*pal,1);joint(im,knee,4 if armored else 3,'deep' if armored else 'gun',pal[1])
 ankle=(toe[0],toe[1]-4)
 dense_plate(im,(knee[0],knee[1]+2),ankle,4.7 if armored else 3.1,3,*pal,1);joint(im,ankle,2);foot(im,toe,kind,near)
def head_limen(im,x,y,look):
 # Cast-plate features: broad seamed dome, long cheekbone, inset optics and metal teeth.
 def P(pts,c):poly(im,shifted(pts,x,y),c)
 P([(-10,-4),(-9,-10),(-6,-14),(0,-16),(6,-15),(10,-11),(12,-6),(12,-3),(10,-1),(11,2),(9,6),(5,8),(-3,7),(-7,2)],'ink')
 P([(-9,-6),(-8,-11),(-4,-14),(2,-15),(7,-13),(10,-9),(11,-5),(8,-4),(5,-6),(1,-4),(-3,-3)],'steel')
 P([(-7,-10),(-4,-13),(2,-14),(6,-12),(5,-10),(1,-10),(-1,-7),(-5,-6)],'pale')
 P([(-6,-12),(-3,-14),(1,-14),(-2,-12)],'crest')
 ln(im,(x+2,y-14),(x+5,y-10),'smoke');ln(im,(x+5,y-10),(x+4,y-8),'deep')
 P([(-3,-5),(2,-7),(6,-6),(6,-4),(2,-2),(-2,-2)],'joint')
 ln(im,(x,y-4),(x+4,y-5),'cyan',2);ln(im,(x+7,y-5),(x+9,y-5),'cyan');box(im,x+5,y-3,2,2,'ink')
 joint(im,(x-6,y-3),3,'deep','steel')
 P([(-3,0),(1,-2),(6,-1),(8,-2),(10,-1),(9,1),(4,1),(1,2)],'steel')
 P([(-1,1),(1,3),(7,3),(9,2),(8,5),(4,6),(1,5)],'pale')
 ln(im,(x,y+3),(x+8,y+2),'ink');
 for xx in [1,4,7]:ln(im,(x+xx,y+2),(x+xx,y+4),'deep')
 P([(-5,0),(-4,3),(0,6),(5,7),(1,8),(-5,5)],'smoke')
def head_stil(im,x,y,front):
 # Near-side cut of the T visor remains visible against a turned black chrome head.
 def P(pts,c):poly(im,shifted(pts,x,y),c)
 P([(-8,-6),(-7,-13),(-3,-16),(3,-16),(8,-12),(10,-6),(9,0),(6,4),(1,7),(-4,7),(-6,3)],'ink')
 P([(-7,-7),(-6,-12),(-2,-15),(3,-15),(7,-11),(8,-6),(5,-4),(-1,-4)],'carbon')
 P([(-6,-10),(-3,-14),(1,-15),(4,-13),(2,-12),(-2,-11)],'edge')
 ln(im,(x+2,y-14),(x+5,y-11),'sliver')
 P([(-7,-5),(-3,-5),(3,-6),(3,-3),(-2,-1),(-6,-2)],'shadeRed')
 ln(im,(x-8,y-4),(x-4,y-3),'fire',2);ln(im,(x-4,y-3),(x+3,y-5),'red',2);ln(im,(x-4,y-3),(x-3,y+3),'fire',2)
 ln(im,(x-6,y-3),(x-5,y+2),'red');ln(im,(x-6,y-3),(x-6,y),'fire')
 P([(-4,-1),(1,-2),(4,-4),(5,0),(1,4),(-3,6)],'gun')
 ln(im,(x-3,y+4),(x+2,y+1),'edge')
 joint(im,(x+6,y-3),3,'gun','edge')
def limb_arm(im,sh,el,wr,kind):
 armor=kind=='LIMEN';dense_plate(im,sh,el,4.7 if armor else 3.1,3,'steel' if armor else 'carbon','pale' if armor else 'edge');joint(im,el,3)
 dense_plate(im,el,wr,4.6 if armor else 3.5,2.8,'steel' if armor else 'carbon','pale' if armor else 'sliver','deep' if armor else 'gun',1)
def blade(im,root,tip,kind,bow):
 x,y=root;u,v=tip; dx=u-x;dy=v-y;n=max(1,math.hypot(dx,dy));ox=-dy/n*bow;oy=dx/n*bow
 p1=(x+dx*.28+ox,y+dy*.28+oy);p2=(x+dx*.62+ox*.7,y+dy*.62+oy*.7)
 p3=(x+dx*.36-ox*.28,y+dy*.36-oy*.28)
 poly(im,[(x,y),p1,p2,tip,p3,(x-ox*.5,y-oy*.5)],'ink')
 poly(im,[(x,y),p1,p2,tip,p3], 'cyan' if kind=='LIMEN' else 'sliver')
 ln(im,p2,tip,'ice' if kind=='LIMEN' else 'crest')
 ln(im,(x,y),p3,'teal' if kind=='LIMEN' else 'edge')
def torso(im,x,y,kind):
 def P(pts,c):poly(im,shifted(pts,x,y),c)
 if kind=='LIMEN':
  P([(-17,-13),(-11,-19),(2,-20),(13,-17),(17,-10),(15,7),(10,15),(-9,16),(-15,10)],'ink')
  P([(-14,-12),(-9,-17),(3,-18),(13,-15),(15,-9),(11,-5),(-2,-4),(-12,-6)],'steel')
  P([(-12,-13),(-7,-16),(2,-17),(4,-15),(-4,-13),(-9,-8)],'pale')
  P([(-12,-6),(-3,-3),(11,-4),(10,7),(7,12),(-7,12),(-11,8)],'smoke')
  P([(-6,-9),(7,-11),(11,-8),(10,0),(-4,2),(-7,-1)],'deep')
  P([(-4,-8),(7,-9),(8,-7),(7,-3),(-3,-2)],'joint');ln(im,(x-1,y-5),(x+5,y-6),'steel')
  for xx,yy in [(-9,2),(-3,3),(4,2)]:box(im,x+xx,y+yy,5,7,'steel');ln(im,(x+xx,y+yy),(x+xx+3,y+yy),'pale')
  P([(-11,12),(8,10),(11,13),(8,17),(-9,18),(-13,16)],'joint')
  for xx in [-10,-4,3]:box(im,x+xx,y+12,4,4,'steel')
 else:
  P([(-12,-13),(-6,-20),(3,-20),(12,-15),(15,-8),(12,0),(6,4),(5,13),(-1,18),(-9,12),(-7,2),(-12,-4)],'ink')
  P([(-10,-12),(-5,-18),(4,-18),(10,-15),(12,-10),(8,-5),(2,-2),(-2,-1),(-7,-2)],'carbon')
  P([(-7,-14),(-4,-18),(3,-17),(6,-15),(2,-15),(-1,-9)],'edge')
  P([(-4,0),(5,-4),(9,-6),(7,-1),(3,3),(2,13),(-4,15),(-6,11)],'gun')
  for i in range(4):ln(im,(x-5,y+4+i*2),(x+1,y+2+i*2),'edge' if i==1 else 'carbon')
  P([(-8,13),(-1,10),(6,11),(9,14),(6,19),(0,20),(-9,18)],'carbon')
  ln(im,(x-7,y+14),(x-1,y+12),'edge')
def shoulder(im,x,y,kind):
 if kind=='LIMEN':
  poly(im,shifted([(-6,0),(-5,-6),(-2,-9),(4,-8),(7,-5),(8,1),(5,3),(-5,4)],x,y),'ink')
  poly(im,shifted([(-5,0),(-4,-5),(-1,-8),(3,-7),(6,-4),(7,0),(4,0),(-4,2)],x,y),'steel')
  ln(im,(x-4,y-4),(x-1,y-7),'crest');ln(im,(x+3,y-6),(x+5,y-2),'smoke')
 else:
  oval(im,x,y,6,5,'ink');oval(im,x,y-1,5,4,'carbon')
  poly(im,shifted([(-5,-2),(-3,-5),(1,-6),(4,-3),(4,-1),(1,0),(-3,0)],x,y),'red');ln(im,(x-3,y-4),(x,y-5),'fire')

def build_limen(reach=0,tilt=0,lean=0,receive=0):
 far=layer();lower=layer();trunk=layer();front=layer();glow=layer()
 h=(lean,-70);should=(lean+11,-60)
 leg(lower,(-7,-36),(-7,-20),(-9,0),'LIMEN',False);leg(lower,(5,-35),(7,-19),(9,1),'LIMEN',True)
 elbow=mix((17,-42),(35,-50),reach);wr=mix((25,-47),(54,-76),reach)
 elbow=(elbow[0]+9*receive,elbow[1]+receive);wr=(wr[0]+18*receive,wr[1]+4*receive)
 blade_root=(-20,-37);tip=(-34,-62+tilt)
 limb_arm(far,(-13+lean,-59),(-20,-43),blade_root,'LIMEN');blade(far,blade_root,tip,'LIMEN',3.5)
 torso(trunk,lean,-52,'LIMEN');head_limen(trunk,h[0]+2,h[1]-2+tilt,0)
 shoulder(trunk,lean-13,-62,'LIMEN');limb_arm(front,should,elbow,wr,'LIMEN');shoulder(front,*should,'LIMEN')
 joint(front,wr,2,'deep','pale')
 # Pinch pads lie on opposite faces of the lower card edge.
 poly(front,shifted([(-2,-3),(1,-3),(4,-2),(4,0),(1,1),(-2,0)],*wr),'steel')
 ln(front,(wr[0]+1,wr[1]-3),(wr[0]+3,wr[1]-3),'pale')
 ln(glow,(h[0]+2,h[1]-6+tilt),(h[0]+5,h[1]-7+tilt),'ice')
 ln(glow,mix(blade_root,tip,.58),tip,'ice')
 return [far,lower,trunk,front],glow,{'prop':px(T(wr[0]+2,wr[1]-2)),'hand_l':px(T(*wr)),'hand_r':px(T(*blade_root)),'blade_tip_r':px(T(*tip)),'look':px(T(h[0]+8,h[1]-6+tilt)),'foot_l':px(T(-9,0)),'foot_r':px(T(9,1))}
def build_stil(aim,walk,sway,feet,head=0):
 far=layer();lower=layer();trunk=layer();front=layer();glow=layer()
 # Local feet are solved from the source track and fixed stance positions.
 for idx,(fx,fy) in enumerate(feet):
  hx=(-5 if idx==0 else 5)+sway;knee=(mix((hx,-35),(fx,fy),.47)[0]+(-2 if idx==0 else 3),-21+min(0,fy*.43))
  leg(lower,(hx,-36),knee,(fx,fy),'STILETTO',idx)
 lean=-2*aim+sway
 torso(trunk,lean,-52,'STILETTO');head_stil(trunk,lean-2,-71+head,0)
 sockets={}
 for idx,target in enumerate([far,front]):
  side=(-1,1)[idx];sh=(lean+side*10,-62)
  # In the hold, both diagonals converge on LIMEN's upper torso, left of the card and max.
  elbow=mix((side*13,-49+side*walk),[(-29,-71),(11,-80)][idx],aim)
  wr=mix((side*15,-38+side*walk),[(-38,-81),(2,-91)][idx],aim)
  tip=mix((side*24,-20+side*walk),[(-88,-140),(-69,-137)][idx],aim)
  limb_arm(target,sh,elbow,wr,'STILETTO');blade(target,wr,tip,'STILETTO',(-5.0,6.5)[idx]);shoulder(target,*sh,'STILETTO')
  if idx==1:
   ln(target,mix(sh,elbow,.12),mix(sh,elbow,.7),'edge');ln(target,mix(elbow,wr,.14),mix(elbow,wr,.7),'sliver');ln(target,mix(wr,tip,.04),mix(wr,tip,.19),'edge')
  sockets['hand_'+('l','r')[idx]]=px(T(*wr));sockets['blade_tip_'+('l','r')[idx]]=px(T(*tip))
 ln(glow,(lean-7,-75+head),(lean-2,-74+head),'fire')
 sockets.update({'look':px(T(lean-6,-75+head)),'foot_l':px(T(*feet[0])),'foot_r':px(T(*feet[1]))})
 return [far,lower,trunk,front],glow,sockets
def flatten(layers):
 a=layer()
 for l in layers:a.alpha_composite(l)
 return a

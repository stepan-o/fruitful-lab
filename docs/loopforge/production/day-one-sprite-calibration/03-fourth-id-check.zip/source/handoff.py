"""Write registered room parts, compact stable indices, file integrity, and proofs."""
from scene import *
from PIL.PngImagePlugin import PngInfo
from collections import defaultdict
import zipfile
import io
import subprocess
from paint import PAL
from assets import max_layer
def png(im,p):
 m=PngInfo();m.add(b'sRGB',b'\x00');im.save(p,pnginfo=m,optimize=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapped(st,s,p):
 if st=='char-max':return s['actors'][st]['sockets']['hand_r']
 return s['actors'][st]['sockets']['prop']
def add_layers():
 reg=F
 png(RAIL,reg/'sec-rails-depth.png')
 boom=Image.new('RGBA',(430*5,146*5))
 for i in range(25):boom.paste(boom_native(i),((i%5)*430,(i//5)*146))
 png(boom,reg/'sec-boom-states.png')
 for id in ('char-max','supervisors'):png(shadow_base(id=='supervisors'),reg/(id+'-shadow.png'))
 # Separate the authored Security highlight clusters from the neutral plate ramp.
 # Engine may use the combined paint (body) or exact neutral + replacement light.
 for id,entries in ex['poses'].items():
  for entry in {q['body']:q for q in entries}.values():
   src=X/entry['body'];p=load(src);neutral=p.copy();repl=Image.new('RGBA',p.size)

   # Only bright cool highlight inks are extracted. Opaque replacement inks reconstitute
   # the accepted Security body exactly. All other paint and alpha remain untouched.
   from collections import Counter
   mapping={}
   for col in set(p.getdata()):
    r,g,b,a=col
    if a and g>=96 and g>=r and b>=r*.80:
     mapping[col]=(max(0,r-7),max(0,g-14),max(0,b-12),a)
   # Fast indexed RGBA lookup keyed by the actual input palette.

   pal_cache={}
   for y in range(0,p.height,256):
    for x in range(0,p.width,256):
     tile=p.crop((x,y,x+256,y+256));box=tile.getbbox()
     if box is None:continue
     small=tile.crop(box);n=small.copy();o=Image.new('RGBA',small.size)
     ins=small.load();ns=n.load();os=o.load()
     for yy in range(small.height):
      for xx in range(small.width):
       col=ins[xx,yy]
       if col in mapping:ns[xx,yy]=mapping[col];os[xx,yy]=col
     neutral.paste(n,(x+box[0],y+box[1]));repl.paste(o,(x+box[0],y+box[1]))
   assert Image.alpha_composite(neutral,repl).tobytes()==p.tobytes()
   png(neutral,src.with_name(src.name.replace('base-','neutral-')))
   png(repl,src.with_name(src.name.replace('base-','light-security-')))
  for a in entries:
   a['neutral']=a['body'].replace('base-','neutral-');a['securityLight']=a['body'].replace('base-','light-security-')
 for p in X.rglob('*.png'):
  # Metadata only; accepted source max originals are never rewritten.
  if b'sRGB' not in p.read_bytes()[:200]:png(pic(p),p)
 for p in (D/'source/editable').rglob('*.png'):png(pic(p),p)
def normal_ramps():
 (D/'source/palette.json').write_text(json.dumps({'supervisorInkRoles':PAL,'maxPaletteSource':'max-r2/SE/body.png','workingSpace':'sRGB, straight-alpha PNG, nearest-neighbour sampling'},indent=2))
def run():
 add_layers();normal_ramps()
 frames=ex['frames'];world=score['frames']
 for i,(r,w) in enumerate(zip(frames,world)):
  t=r['edit']
  for id in ['char-limen','char-max','char-stiletto']:
   a=r['actors'][id];v=world[i]['actors'][{'char-max':'max','char-limen':'LIMEN','char-stiletto':'STILETTO'}[id]]
   if id=='char-limen':a['facing']='NE / gaze E';a['action']='id-photo-check'
   elif id=='char-max':a['facing']='SE / gaze W' if t<137.65 else 'SE';a['action']='face-compare' if t<137.65 else 'duck-pass'
   else:
    a['facing']='NW' if t<127.08 or t>=129.2 else 'N';a['action']='walk-threat-approach' if t<129.25 else 'plant' if t<130.27 else 'twin-blade-threat' if t<139.2 else 'recover'
    if v['moving']:
     phase=world[i]['dist']/1.12
     a['feetGrounded']=[(phase+j*.5)%1<.5 for j in range(2)]
    else:a['feetGrounded']=[True,True]
   if id=='char-limen':a['feetGrounded']=[True,True]
 q=[{'entity':id,'name':'plant_'+which,'frame':i,'edited':frames[i]['edit'],'cosmeticOnly':True} for id in ['char-stiletto','char-max'] for j,which in enumerate(['l','r']) for i in range(1,len(frames)) if not frames[i-1]['actors'][id]['feetGrounded'][j] and frames[i]['actors'][id]['feetGrounded'][j]]
 ex['footfallMarkers']=q
 ex['sourceState']='work/score.json derived verbatim from the pinned PR153 sequence at 20Hz. Resolve live actor roots and state from the engine. The stored stage samples support proof reproduction.'
 ex['facingConvention']='N is world -y, E is +x. LIMEN maintains a northerly desk stance and turns his gaze/arms east to max. STILETTO transitions NW to N approach and NW threat. The NE/SE torso labels are visual orientation.'
 ex['boom']={'id':'S6','rect':[124.73,133.83,6.54,.34],'hinge':geo['gate']['hinge'],'lengthMetres':6.2,'worldState':'gateTipAt(gate,t)','asset':'fixtures/sec-boom-states.png','atlasCellPx':[430,146],'columns':5,'poseRange':[0,24],'poseFormula':'round(24 * (gateTip.x - hinge.x) / 6.2)','pivotPx':[14,134]}
 ex['rails']={'ids':['S1','S2'],'file':'fixtures/sec-rails-depth.png','pivotPx':[10,326],'sort':'measured south ground edge','rects':[[123.25,122.8,.12,4.4],[130.25,122.8,.12,4.4]]}
 ex['shadows']={'max':'fixtures/char-max-shadow.png','LIMEN':'fixtures/supervisors-shadow.png','STILETTO':'fixtures/supervisors-shadow.png','pivotPx':[128,208]}
 ex['renderOrder']='Ground, cast shadows, props/actors sorted on world y, desk back then front, credential on current visual holder, gripping fingertip above paper. base fields contain combined non-emissive paint. neutral + securityLight reconstruct it byte-for-byte. Add emissive for the lit pass.'
 (X/'lane03-pose-manifest.json').write_text(json.dumps(ex,separators=(',',':')))
 phaseSteps=[]
 for id in ['char-stiletto','char-max']:
  key={'char-stiletto':'STILETTO','char-max':'max'}[id];entries=[]
  for foot,name in enumerate(['foot_l','foot_r']):
   for i in range(1,296):
    r0=frames[i-1]['actors'][id];r1=frames[i]['actors'][id]
    if not (r0['feetGrounded'][foot] and r1['feetGrounded'][foot]):continue
    p0=world[i-1]['actors'][key]['p'];p1=world[i]['actors'][key]['p']
    if p0==p1:continue
    # Ignore first/last blend into a plant; report each interior contact movement.
    # Include moving-root first and last stance pairs, including launch and brake.
    A=r0['sockets'][name];B=r1['sockets'][name];entries.append(math.hypot((p0[0]-p1[0])*64+A[0]-B[0],(p0[1]-p1[1])*64+A[1]-B[1]))
  phaseSteps.append({'actor':key,'consecutiveMovingRootPlantPairs':len(entries),'maxGroundSlipSourcePxIncludingQuantization':round(max(entries or [0]),3)})
 pinErr=[]
 for t in [129.35,137.65]:
  i=round((t-125.1)*20);r=frames[i];w=world[i];ma=w['actors']['max']['p'];li=w['actors']['LIMEN']['p'];a=r['actors']['char-max']['sockets']['hand_r'];b=r['actors']['char-limen']['sockets']['prop']
  pinErr.append({'edited':t,'holder':r['credential']['visualHolder'],'interHandDeltaNativePx':round(math.dist([a[0]+ma[0]*64,a[1]+ma[1]*64],[b[0]+li[0]*64,b[1]+li[1]*64]),3)})
 assert max(q['interHandDeltaNativePx'] for q in pinErr)<.6
 videos=[]
 for p in sorted((D/'review').glob('*.mp4')):
  res=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration:stream=width,height,avg_frame_rate,nb_frames','-of','json',str(p)]))
  ss=res['streams'][0];assert ss['avg_frame_rate']=='20/1' and int(ss['nb_frames'])==296 and float(res['format']['duration'])==14.8
  videos.append({'file':p.name,**ss,'duration':14.8,'sha256':digest(p)})
 report={'classification':'offscreen 1x composited motion proof; engine playback pending','sourceHtmlBlob':'a41039c08c873e6496a420ba2f599bb9bd3183b0','actors':{k:len(v) for k,v in ex['poses'].items()},'marks':{k:world[150]['actors'][k]['p'] for k in ['LIMEN','max','STILETTO']},'transfer':pinErr,'sourcePlantVerification':phaseSteps,'media':videos,'remaining':'World-camera credential portrait is tiny at phone width. The synchronous inspection crops carry the likeness check. Unfinished cast/machinery use placeholders. No engine frame rate or device acceptance.'}
 (D/'review/verification.json').write_text(json.dumps(report,indent=2))
 def countHeight(id,idx,view):
  pose=ex['poses'][id][frames[idx]['actors'][id]['pose']];a=load(X/pose['body']);x,y,w,h=pose['atlasRect'];bounds=a.crop((x,y,x+w,y+h)).getbbox();width,height=view;sw=width-18 if width<=620 else 1050;sh=round(.43*height) if width<=620 else 360;cam=world[idx]['cam'];scale=min(sw/cam[2],sh/cam[3]);return {'native':bounds[3]-bounds[1],'roomProjectedPx':round((bounds[3]-bounds[1])*scale/64,2)}
 report['projectedActorHeightAt132_6']={str(w):{id:countHeight(id,150,(w,720 if w==1280 else 844)) for id in ex['poses']} for w in (1280,390,320)}
 (D/'review/verification.json').write_text(json.dumps(report,indent=2))
if __name__=='__main__':run()

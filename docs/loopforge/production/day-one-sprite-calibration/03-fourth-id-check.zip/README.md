# Fourth ID check

The 14.8-second calibration puts LIMEN at the S5 photo reader with max. STILETTO returns from the Forge side of the boom, plants, and points both integral blades at LIMEN. The lower inspection views magnify the same live-sampled pose and credential as the main shot. The lit movies retain the actual authored dialogue as on-screen text. The blind movies suppress speech, actor names and emissive accents. All movies are silent.

## Review

Open a movie in `review/` at **1×**. The 1280×720 views reproduce the desktop camera dimensions. The 390×844 and 320×844 views reconstruct the phone viewport and a separate wrapping speech rail. `fourth-key-1280.png` and `transfer-contact-qa.jpg` inspect the card, jaw, blade tips and grip in the final art. `verification.json` records video dimensions/timing, measured transfer and stance error and projected character extents. STILETTO's projected bounding height there includes her raised blades.

These are **offscreen composited motion proofs**. The root tracks, gate geometry, cut and lines come from the shipped rehearsal sequence; the sprite pixels, posture, independent light and foreground slices are new. Other workers and uncommissioned machinery retain placeholders. The macro inset is required to identify the portrait at phone room scale. Actual game-engine playback, device timings and final owner acceptance remain open.

## Timing and source

The original excerpt runs from **125.100 to 139.900 edited seconds**, 296 frames at 20 fps. The sample at the exclusive endpoint belongs to the following interval. Pose samples 296–300 supply the remaining four 50ms intervals and clean exit pose through 140.100 for the engine. The comparison begins at 130.700 and ends at 137.650. The forked poses allow max to leave on the original route as his duck begins and STILETTO’s blades stay up through 139.200. The 190.604-second edit, routes, physical marks, gate timing and geometry are unchanged.

The paired hand contact is around 129.350 on receive and 137.650 on return. A crop of the director-cleared r2 max SE head supplies his own worn off-white credential. The source reference, hashes and live attachment corners are in the pose descriptor. The renderer does not emit simulation events.

## Runtime assets

`exports/lane03-pose-manifest.json` specifies 256×256 untrimmed actor cells, 64 source pixels per ground metre and foot pivot (128,208), atlas regions, opacity layers, actor/prop sockets, poses, facings, phase labels, footfall markers, shadow passes and indexed room pieces. Its pose bank contains the full actor paint without emission in `body`. Alternatively compose `neutral` and `securityLight` as ordinary straight-alpha layers to reconstruct that same paint pixel-for-pixel. `emissive` is optional in either path. The desk lip/back, card, pinch pad, boom states, rail and shadows remain independent.

Sort actors on their actual engine ground anchors. At S5 sort the two measured desk slices at world (131.6,131.9). Preserve the original boom tip from the gate state. Draw the credential on the named visual holder every frame; place the separate gripping pad above it while LIMEN holds it. The director-approved working pose uses source pixels (2,17) on the card as the grip socket. In the state sample, `visualHolder` records a presentation attachment for the same owned credential. Preserve actual engine custody.

## Editable files and reproduction

`source/paint.py` is the native-pixel supervisor rig and palette. `source/assets.py` poses its separate lower body, arms and torso/head, articulates the accepted max layers, and builds deduplicated pose atlases. The representative editable PNG stack for each actor is in `source/editable/`. The approved max r2 joint pieces are in `source/max-r2/`; the independent selected floor and S5 source parts and pinned PR153 HTML are in `source/reference/`. All exported PNGs use straight alpha and sRGB.

Build with Node 22+, Python 3.11+, Pillow, FFmpeg/ffprobe, and Liberation Sans and Mono. From this folder run:

```sh
node source/sample-state.cjs
python3 source/assets.py
python3 source/scene.py key
python3 source/scene.py movie 1280 720 lit
python3 source/scene.py movie 1280 720 blind
python3 source/scene.py movie 390 844 lit
python3 source/scene.py movie 390 844 blind
python3 source/scene.py movie 320 844 lit
python3 source/scene.py movie 320 844 blind
python3 source/handoff.py
```

The sample-state script requires Git blob a41039c08c873e6496a420ba2f599bb9bd3183b0 for the standalone source renderer and consumes its embedded PR153 sequence. The player in this package never writes shared game state. Review history and rejected poses are in `review/revisions/`.

# STILETTO — char-stiletto

Black chrome, red shoulders and T visor, two blade arms. Original sheet predates the approved red accents. Black chrome, red shoulder bands and T visor; two blade arms with no invented hands. Her straight-through walk and pointed impatience must read at room scale.

## Group

Characters

## Delivery priority

P0

## Quantity

1 unique actor

## Parts and source layers

Layered body: rear arm/tool, lower body, torso/head, front arm/tool; separate shadow and emissive mask. Equipment integral to identity stays attached. Export flattened full-body frames too for actions that cannot cleanly split.

## States and variants

Common seven clip families below, plus the bespoke list. Workers use blue-family shades; supervisors retain their approved palettes. Injury is a persistent appearance/motion state on bob.

## Assembly and sockets

Ground pivot between planted feet. Sockets: hand_l, hand_r, look, prop, foot_l, foot_r; add pocket for bob/ed, blade_tip_l/r for supervisors, and support contact for bob/sam. All socket tracks are in untrimmed frame pixels.

## Acceptance

Recognizable with names hidden against Security and Forge floors. No foot sliding, hand/prop separation, false mirroring, or body/tool penetration. Test bespoke actions against the actual paired actor/fixture.

## Common animation coverage

| Clip | Coverage | Performance |
| --- | --- | --- |
| idle | 8 directions · 4 frames per direction · loop | Quiet breathing/mechanical settling; one neutral held pose per facing. No perpetual comedy. |
| walk | 8 directions · 8 frames per direction · loop | In-place feet; foot-down markers and stride length. World position comes from ENGINE. |
| hurry | 8 directions · 8 frames per direction · loop | A fast purposeful exit, with longer stride; not a sped-up shuffle. Preserve bob’s injured version. |
| start-stop | 8 directions · 3 start + 3 stop frames per direction | Brake on either foot; retain a held mid-step pose, then resume from that planted foot. |
| turn | 16 transitions · 3 frames per adjacent 45° turn | Both turn directions; body follows head. No mirrored asymmetrical equipment. |
| talk | 8 directions · 4 upper-body frames per direction · loop | Subtle head/chest/arm articulation composited over idle or walk. No phoneme lip-sync commission. |
| listen | 8 directions · 2 held poses per direction | Attention and glance-back pose, compatible with walking and tools. |

## Bespoke animation coverage

| Clip | Coverage | Performance |
| --- | --- | --- |
| hold-gate-order | S, SE · 6 upper-body frames | Call while approaching, without a ceremonial stop. |
| inspect-cradle | S, SE · 8 frames + hold | Lean past bob toward the seated brain, keep both blade tips clear. |
| step-over-leg | E, SE · 8 frames | Step over bob’s extended leg without displacing him. |
| instruct-point | S, SE · 8 frames | Direct blade toward work target without touching worker. |
| twin-blade-threat | N, NW · 10 frames + hold + 6 recovery | Plant on the Forge side of the inspection boom. Aim both blades toward LIMEN at the ID desk and leave room for max to duck past. |
| catch-shout | N, NW · 8 frames | “WHO SAID YOU COULD GO?!” A sharp interruption after the crew has started moving. |
| dismiss-backs | N, NW · 8 frames | Wave after their backs while following at a slow 1.25 m/s walk. Use the walk-compatible upper-body overlay; she is still inside at blackout. |

## Delivery contract

Read HANDOFF.md and manifest.template.json in the complete pack. Status: briefed; this document does not contain finished sprite art.

- [Approved character reference](/media/loopforge-cast/stiletto-1280.189604eaf0fbc0f9.webp)
- [Cast and approved ensemble](/stepanoskin/loopforge/design#narrative-cast)

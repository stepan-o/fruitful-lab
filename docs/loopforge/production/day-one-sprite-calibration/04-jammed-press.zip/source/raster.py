from pathlib import Path
from copy import copy
import json, math, re
import cairo
from PIL import Image


def colour(value):
    code=value.lstrip('#')
    if len(code)==3: code=''.join(c+c for c in code)
    if len(code)==6: code+='ff'
    return tuple(int(code[i:i+2],16)/255 for i in range(0,8,2))

def render(calls, width, height, dest):
    surface=cairo.ImageSurface(cairo.FORMAT_ARGB32,width,height)
    c=cairo.Context(surface)
    c.set_line_width(1)
    state={'fillStyle':'#000','strokeStyle':'#000','textAlign':'start','textBaseline':'alphabetic','font':'10px sans-serif'}
    stack=[]
    for op,*args in calls:
        if op=='set':
            prop,val=args;state[prop]=val
            if prop=='lineWidth': c.set_line_width(val)
        elif op=='save': c.save();stack.append(copy(state))
        elif op=='restore':c.restore();state=stack.pop()
        elif op=='beginPath':c.new_path()
        elif op=='closePath':c.close_path()
        elif op=='moveTo':c.move_to(*args)
        elif op=='lineTo':c.line_to(*args)
        elif op=='setLineDash':c.set_dash(args[0])
        elif op in ('rotate','scale','translate'):getattr(c,op)(*args)
        elif op=='ellipse':
            x,y,rx,ry,rot,a,b,*rest=args
            c.save();c.translate(x,y);c.rotate(rot);c.scale(rx,ry);c.arc(0,0,1,a,b);c.restore()
        elif op in ('fill','stroke'):
            c.set_source_rgba(*colour(state[op+'Style']));getattr(c,op+'_preserve')()
        elif op in ('fillRect','strokeRect'):
            prev=c.copy_path();c.new_path();c.rectangle(*args);key=op[:-4]
            c.set_source_rgba(*colour(state[key+'Style']));getattr(c,key)();c.new_path();c.append_path(prev)
        elif op=='fillText':
            txt,x,y=args
            c.set_source_rgba(*colour(state['fillStyle']))
            c.select_font_face('monospace',cairo.FONT_SLANT_NORMAL,cairo.FONT_WEIGHT_BOLD)
            c.set_font_size(float(re.search(r'([\d.]+)px',state['font']).group(1)))
            _,_,_,_,advance,_=c.text_extents(str(txt))
            if state['textAlign']=='center':x-=advance/2
            elif state['textAlign']=='right':x-=advance
            if state['textBaseline']=='middle':
                asc,dec,*_=c.font_extents();y+=(asc-dec)/2
            prev=c.copy_path();c.new_path();c.move_to(x,y);c.show_text(str(txt));c.new_path();c.append_path(prev)
        else: raise ValueError(op)
    surface.write_to_png(str(dest))


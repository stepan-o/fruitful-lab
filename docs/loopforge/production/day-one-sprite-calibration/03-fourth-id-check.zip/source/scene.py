"""Stateless skin compositor. All roots, gate motion, score and speech are read from PR153."""
from paint import *
from PIL import ImageFont,ImageOps
from functools import lru_cache
import sys,subprocess
from pathlib import Path
import hashlib
X=D/'exports';F=X/'fixtures'
score=json.loads((D/'work/score.json').read_text())
ex=json.loads((X/'lane03-pose-manifest.json').read_text())
geo=score['floor'];origin=(100,110);world_size=(64*57,64*54)
def worldp(p):return tuple(round((v-o)*64) for v,o in zip(p,origin))
def pic(p):return Image.open(p).convert('RGBA')
@lru_cache(40)
def load(p):return pic(p)
@lru_cache(350)
def sprite(ident,ix,lit):
 pose=ex['poses'][ident][ix];x,y,w,h=pose['atlasRect'];b=load(X/pose['body']).crop((x,y,x+w,y+h))
 if lit:b.alpha_composite(load(X/pose['emissive']).crop((x,y,x+w,y+h)))
 return b
@lru_cache(1)
def make_world():
 world=Image.new('RGB',world_size,'#192a2c')
 tiles=D/'source/reference'
 for room,kind in [('security','security'),('conveyor','forge')]:
  zone=next(q for q in geo['zones'] if q['id']==room);polygon=[worldp(p) for p in zone['polygon']]
  mask=Image.new('L',world_size);ImageDraw.Draw(mask).polygon(polygon,fill=255)
  texture=Image.new('RGB',world_size)
  # Repeat only the quiet base steel and flush seams. Queue grips, worn grate
  # and practical marks have one real world placement in each room.
  mat=load(tiles/f'env-floor-kit-{kind}-base-r02.png').copy()
  joins=load(tiles/f'env-floor-kit-{kind}-joints-r02.png').copy()
  de=ImageDraw.Draw(joins)
  de.rectangle((1,109,24,194) if kind=='security' else (199,23,255,78),fill=(0,0,0,0))
  mat.alpha_composite(joins)
  mat=mat.convert('RGB')
  if kind=='security':
   mat=Image.blend(mat,Image.new('RGB',mat.size,(11,34,39)),.25)
  else:
   mat=Image.blend(mat,Image.new('RGB',mat.size,(39,29,27)),.19)
  for y in range(0,world_size[1],256):
   for x in range(0,world_size[0],256):texture.paste(mat,(x,y))
  world.paste(texture,(0,0),mask)
  if kind=='security':
   # One directional teal practical, sampled continuously in world coordinates.
   # Smooth envelope at the ends and broad square-pixel steps in the narrow core.
   x0,y0=worldp((126.4,128.4));px=world.load()
   for dy in range(650):
    strengthY=min(1,dy/100,(650-dy)/120)
    center=round(284-dy*.31)
    for dx in range(center-72,center+73):
     distance=abs(dx-center)
     strength=max(0,1-distance/73)*(.18 if distance>17 else .26)*max(0,strengthY)
     x=x0+dx;y=y0+dy;v=px[x,y]
     px[x,y]=tuple(round(n+(k-n)*strength) for n,k in zip(v,(113,177,170)))
 dr=ImageDraw.Draw(world)
 for wall in geo['walls']:
  a=worldp((wall['x'],wall['y']));b=worldp((wall['x']+wall['w'],wall['y']+wall['h']))
  dr.line([a,b],fill='#586766',width=8);dr.line([(a[0],a[1]-2),(b[0],b[1]-2)],fill='#91a09a',width=2)
 for portal in geo['portals']:
  r=portal['rect'];a=worldp((r['x'],r['y']));b=worldp((r['x']+r['w'],r['y']+r['h']));
  # Threshold is flush. The existing boom owns its metal beam, feet and shadow.
  if portal['id'] in ('inspection-gate','security-conveyor'):
   dr.line([(a[0],b[1]-2),(b[0],b[1]-2)],fill='#43534e',width=2)
   for xx in range(a[0]+5,b[0]-2,32):dr.line([(xx,b[1]-3),(xx+3,b[1]-3)],fill='#526157',width=2)
  else:dr.line([(a[0],b[1]-1),(b[0],b[1]-1)],fill='#475952',width=2)
 for q in geo['fixtures']:
  r=q['rect'];a=worldp((r['x'],r['y']));b=worldp((r['x']+r['w'],r['y']+r['h']))
  if q['kind']=='drain':
   dr.rectangle([a,b],fill='#15282a',outline='#87948b',width=2)
   for xx in range(a[0]+4,b[0]-3,9):dr.line([(xx,a[1]+3),(xx,b[1]-3)],fill='#50615f',width=3)
  elif q['kind'] in ('machine','rack'):
   dr.rectangle([a,b],fill='#4b5351',outline='#a99a7a',width=4);dr.rectangle([a[0]+8,a[1]+12,b[0]-8,b[1]-12],fill='#344347',outline='#646c63',width=3)
   for xp in range(a[0]+14,b[0]-14,22):dr.line([(xp,a[1]+15),(xp,b[1]-14)],fill='#6e766a',width=3)
 for q in geo['galleries']:
  pass
 return world
def crop_ground(width,height,cx,cy,scale):
 x,y=worldp((cx,cy));step=64/scale
 return make_world().transform((width,height),Image.Transform.AFFINE,(step,0,x-width*step/2,0,step,y-height*step/2),resample=Image.Resampling.NEAREST,fillcolor='#1f3030').convert('RGBA')
@lru_cache(40)
def fixed_back(w,h,cx,cy,sc):return crop_ground(w,h,cx,cy,sc)
def blit(stage,src,screen,sourcepivot,scale):
 bbox=src.getbbox()
 if not bbox:return
 ax,ay=screen;ux,uy=sourcepivot;r=scale/64
 l,t,rr,b=bbox
 left=round(ax+(l-ux)*r);top=round(ay+(t-uy)*r);right=round(ax+(rr-ux)*r);bottom=round(ay+(b-uy)*r)
 if right<=0 or bottom<=0 or left>=stage.width or top>=stage.height or right==left or bottom==top:return
 part=src.crop(bbox).resize((max(1,right-left),max(1,bottom-top)),Image.Resampling.NEAREST)
 stage.alpha_composite(part,(left,top))
def desk(front=True):return load(F/('sec-desks-S5-'+('front' if front else 'back')+'.png'))
def rail_native():
 im=Image.new('RGBA',(20,330));d=ImageDraw.Draw(im);d.line((10,20,10,300),fill='#182c30',width=8)
 for y in [24,159,300]:
  d.rectangle((4,y,15,y+25),fill='#364646',outline='#18292d');d.rectangle((3,y+23,16,y+27),fill='#6c7b77')
 d.line((10,17,10,301),fill='#a0ada0',width=4);d.line((8,15,8,299),fill='#637976',width=2)
 return im
RAIL=rail_native()
@lru_cache(40)
def boom_native(exposure):
 # Vertically lifting west-hinged arm: source tip sets projected length. Height
 # rises independently; the projected shadow stays on the source-approved ground.
 ratio=exposure/24;full=397;wid=round(full*ratio);h=round(84*math.sqrt(max(0,1-ratio*ratio)))
 im=Image.new('RGBA',(430,146));dr=ImageDraw.Draw(im);x,y=14,109
 dr.line([(x,y),(x+wid,y-h)],fill='#1a2b2c',width=8);dr.line([(x,y-2),(x+wid,y-h-2)],fill='#687b76',width=5);dr.line([(x,y-4),(x+wid,y-h-4)],fill='#9bb0a0',width=2)
 for j in range(2,full,58):
  a=j/full;b=min(1,(j+20)/full)
  dr.line([(x+wid*a,y-2-h*a),(x+wid*b,y-2-h*b)],fill='#d1b47f',width=4)
 dr.rectangle((6,105,18,134),fill='#435553',outline='#8fa092');dr.ellipse((5,101,19,115),fill='#66786d',outline='#a8b2a1')
 return im
SIL={'bob':'#637fa4','sam':'#618b84','ed':'#847888','jo':'#718eac','gus':'#9c7c68','mae':'#8f8269','kit':'#65918d','lou':'#ae8693','ben':'#91936c'}
@lru_cache(20)
def token(id):
 im=Image.new('RGBA',(24,24));dr=ImageDraw.Draw(im);dr.rounded_rectangle((3,2,19,19),radius=3,fill='#243735',outline=SIL.get(id,'#81928a'),width=2);dr.polygon([(6,9),(14,9),(10,14)],fill=SIL.get(id,'#81928a'));return im
@lru_cache(2)
def shadow_base(supervisor):
 im=Image.new('RGBA',(256,256));dr=ImageDraw.Draw(im);dr.ellipse((108 if supervisor else 114,203,152 if supervisor else 144,214),fill=(4,13,18,83));dr.ellipse((116,205,143,212),fill=(4,13,18,97));return im
def draw_stage(fr,width,height,cmera,lit):
 cx,cy,scale=cmera;stage=fixed_back(width,height,round(cx,5),round(cy,5),round(scale,5)).copy();row=ex['frames'][fr['frame']]
 def project(pos):return ((pos[0]-cx)*scale+width/2,(pos[1]-cy)*scale+height/2)
 def stamp(im,point,anchor=(128,208)):blit(stage,im,project(point),anchor,scale)
 layers=[]
 for id,actor in fr['actors'].items():
  p=actor['p'];key='char-'+id.lower()
  if key in row['actors']:
   stamp(shadow_base(id!='max'),p)
   record=row['actors'][key];im=sprite(key,record['pose'],lit).copy()
   if row['credential'] and id==row['credential']['visualHolder']:
    prop=row['credential']['pivotNativePx'];im.alpha_composite(load(F/'prop-credential-max.png'),(prop[0]-2,prop[1]-17));
    if id=='LIMEN':im.alpha_composite(load(F/'char-limen-pinch-pad.png'),(prop[0]-1,prop[1]-2))
   layers.append((p[1],0,im,p,(128,208)))
  else:
   layers.append((p[1],0,token(id),p,(12,14)))
 for front in (False,True):layers.append((131.9,-1+int(front),desk(front),(131.6,131.9),(128,208)))
 # West register is a depth placeholder, without the S5 reader insert.
 for which in ['west-rail','east-rail']:
  r=next(v['rect'] for v in geo['fixtures'] if v['id']==which)
  layers.append((r['y']+r['h'],0,RAIL,(r['x']+.06,r['y']+r['h']),(10,326)))
 layers.append((132,-1,desk(False),(123.6,132),(128,208)))
 layers.append((132,0,load(D/'source/reference/sec-desks-s5-proof-front-r02.png'),(123.6,132),(128,208)))
 hinge=geo['gate']['hinge'];fraction=(fr['gate'][0]-hinge[0])/geo['gate']['length']
 layers.append((hinge[1],1,boom_native(round(max(0,min(1,fraction))*24)),hinge,(14,134)))
 for y,order,im,p,anchor in sorted(layers,key=lambda e:(e[0],e[1])):stamp(im,p,anchor)
 return stage
def inspection_cam(fr):
 a,b,c=[fr['actors'][n]['p'] for n in ['LIMEN','max','STILETTO']]
 # Track the walkers without moving anyone. Hold a common north-up frame on the
 # physical comparison once STILETTO arrives. Leave room below the roots, and
 # above each raised blade, for the art projection.
 x=(min(a[0]-.6,b[0]-.35,c[0]-1.5)+max(a[0]+1,b[0]+.4,c[0]+.45))/2
 y0=min(a[1]-1.62,b[1]-1.42,c[1]-2.26);y1=max(a[1],c[1],b[1])+.26
 return x,(y0+y1)/2,y1-y0
def font(n,bold=False,mono=False):
 n=round(n);f=('liberation-mono-fonts/LiberationMono-Regular.ttf' if mono else 'liberation-sans-fonts/LiberationSans-'+('Bold' if bold else 'Regular')+'.ttf')
 return ImageFont.truetype('/usr/share/fonts/'+f,n)
def wraps(dr,text,f,maxwidth):
 lines=[]
 for word in text.split():
  s=(lines[-1]+' '+word) if lines else word
  if lines and dr.textlength(s,font=f)<=maxwidth:lines[-1]=s
  else:lines.append(word)
 return lines
def rendered(fr,vp,lit=True):
 w,h=vp;phone=w<620
 stagew=(w-18) if phone else 1050;stageh=round(.43*h) if phone else 360
 cx,cy,ww,hh=fr['cam'];sc=min(stagew/ww,stageh/hh)
 pan=draw_stage(fr,stagew,stageh,(cx,cy,sc),lit)
 page=Image.new('RGB',(w,h),'#121f20');d=ImageDraw.Draw(page);margin=(w-stagew)//2
 d.text((margin,8),'Fourth ID check',font=font(19 if phone else 21,True),fill='#dbdfce')
 d.text((w-margin-2,14),f"{fr['edit']:06.2f} s",anchor='ra',font=font(12,mono=True),fill='#c7b796')
 sh=136 if w==320 else 109 if phone else 77;sy=38
 d.rectangle((margin,sy,margin+stagew-1,sy+sh-1),fill='#172b2b',outline='#405654')
 if lit and fr['voices']:
  q=fr['voices'][0];clr='#ed8f75' if q['speaker']=='STILETTO' else '#aec5b6';ft=font(14 if phone else 18,True)
  d.text((margin+8,sy+7),q['speaker'],font=font(11,True),fill=clr)
  lines=wraps(d,q['text'],ft,stagew-16)
  for j,txt in enumerate(lines):d.text((margin+8,sy+25+j*(17 if phone else 22)),txt,font=ft,fill='#e9e8d9')
  assert 25+len(lines)*(17 if phone else 22)<=sh+2
 elif not lit:d.text((margin+8,sy+11),'Dialogue hidden  ·  glow off',font=font(12),fill='#9daf9e')
 stagey=sy+sh+1;page.paste(pan.convert('RGB'),(margin,stagey))
 basey=stagey+stageh+7
 d.text((margin,basey),'S5 contact view',font=font(13,True),fill='#d6dfce')
 d.text((w-margin-2,basey),'1×   ·   composited motion proof',font=font(11),fill='#9fb0a5',anchor='ra')
 # Secondary camera is a simultaneous magnification of the exact same scene state.
 # Its width never crops the credential, max's face, or either integral blade.
 ci,cj,span=inspection_cam(fr);lensh=h-basey-29;lensw=stagew
 groupw=round(lensw*(.62 if phone else .56)); detailw=lensw-groupw-4
 lenssc=min((lensh-10)/max(span,3.15),(groupw-7)/3.12)
 lens=draw_stage(fr,groupw,lensh,(ci,cj,lenssc),lit)
 page.paste(lens.convert('RGB'),(margin,basey+22))
 # The simultaneous insert is cropped from the same recorded state: the
 # actual credential and actual turning max head, preserving their world gap.
 row=ex['frames'][fr['frame']]
 lp=fr['actors']['LIMEN']['p'];mp=fr['actors']['max']['p']
 jaw=row['actors']['char-max']['sockets']['jaw'];face=(mp[0]+(jaw[0]-128)/64,mp[1]+(jaw[1]-208-8)/64)
 pin=(row['credential'] or {'pivotNativePx':row['actors']['char-limen']['sockets']['prop']})['pivotNativePx']
 holder=mp if row['credential'] and row['credential']['visualHolder']=='max' else lp
 card=(holder[0]+(pin[0]-128+5)/64,holder[1]+(pin[1]-208-10)/64)
 zoom=min(detailw/(abs(card[0]-face[0])+.64),(lensh-5)/(abs(card[1]-face[1])+.88),205)
 eye=draw_stage(fr,detailw,lensh,((card[0]+face[0])/2,(card[1]+face[1])/2,zoom),lit)
 page.paste(eye.convert('RGB'),(margin+groupw+4,basey+22))
 cap='Credential & face' if lit else 'Detail'
 ImageDraw.Draw(page).text((margin+groupw+10,basey+25),cap,font=font(11),fill='#e1e2ce',stroke_width=1,stroke_fill='#17292a')
 return page
def movie(vp,lit=True):
 w,h=vp;name=f'fourth-id-check-{w}x{h}-'+('lit' if lit else 'blind')+'.mp4'
 dest=D/'review'/name
 cmd=['ffmpeg','-v','error','-threads','2','-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r','20','-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','17','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart','-y',str(dest)]
 pr=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for fr in score['frames'][:296]:pr.stdin.write(rendered(fr,vp,lit).tobytes())
 pr.stdin.close()
 if pr.wait():raise RuntimeError(dest)
 print(dest,flush=True)
if __name__=='__main__':
 if sys.argv[1]=='key':
  for vp in [(1280,720),(390,844),(320,844)]:
   rendered(score['frames'][150],vp,True).save(D/'review'/f'fourth-key-{vp[0]}.png')
  rendered(score['frames'][150],(390,844),False).save(D/'review/fourth-key-blind-390.png')
 elif sys.argv[1]=='movie':movie((int(sys.argv[2]),int(sys.argv[3])),sys.argv[4]=='lit')

"""Second art-direction pass. The first submission and its original source remain inspectable."""
from draw import *
CFG['security'].update(plates=['203c3d','234041','273f42','203b3e','254245'],slot='12292b',shadow='193335',edge='37514f',metal='546560',nick='727d71',oxide='3f4841',tint='82c9c5')
CFG['forge'].update(plates=['3f3830','484034','3c3731','3d3832','494035'],slot='23211e',shadow='302a26',edge='5d4c39',metal='715941',nick='a07e55',oxide='583e2d',tint='ed872f')
def machine_marks(room,base,seams,wear):
    c=CFG[room]; s=ImageDraw.Draw(seams); w=ImageDraw.Draw(wear)
    rng=random.Random(923 if room=='security' else 1360)
    # Additional local chipping on lifted panel rims. Mid-panel wear is isolated.
    for x,y,side in ([(21,43,'v'),(164,69,'v'),(13,91,'h'),(193,200,'h'),(228,178,'v'),(55,16,'h')] if room=='security'
            else [(61,39,'v'),(126,82,'h'),(169,82,'h'),(208,186,'h'),(36,104,'v'),(96,186,'h'),(208,8,'h')]):
        for j in range(13):
            run=rng.randrange(-11,15);deep=rng.choice((1,2,2,3,4));length=rng.choice((1,2,2,3,5))
            pts=[(run,1),(run+length,1),(run+length+1,deep),(run+1,deep+1),(run,deep)]
            pts=[(x+a,y+b) if side=='h' else (x+b,y+a) for a,b in pts]
            shape(w,'polygon',pts,rgb(c[rng.choice(['edge','edge','oxide','metal'])]))
    if room=='security':
        # Flush heel-grip strip at the side of an existing queue deck, with worn
        # cream/gray witness dashes. The center stays unmarked.
        s.polygon([(2,112),(19,112),(22,115),(22,188),(19,191),(2,191)],fill='#1e3739')
        s.line((2,112,19,112,22,115,22,188),fill='#405854')
        s.line((2,191,19,191,21,189),fill='#112c2f')
        for y in range(122,182,7):
            s.polygon([(3,y),(14,y),(17,y-2),(19,y-2),(18,y+1),(14,y+3),(3,y+3)],fill='#183234')
            s.line((3,y,13,y,16,y-2),fill='#46605a')
        for y in (116,186): s.rectangle((4,y,7,y+1),fill='#52625a')
        w.polygon([(29,125),(32,125),(32,140),(30,140),(30,145),(29,145)],fill='#505f56')
        w.polygon([(29,166),(32,166),(32,177),(31,179),(29,179)],fill='#4c5a50')
        w.line((30,129,30,133),fill='#697365')
    else:
        # A flat service louver flush in the line-facing plate. The top,
        # depth cuts and shadows remain when the heat pass is switched off.
        s.polygon([(207,29),(252,29),(255,33),(255,73),(253,77),(207,77),(204,74),(204,34)],fill='#2a2421')
        s.polygon([(208,30),(251,30),(254,33),(254,73),(252,75),(208,75),(206,72),(206,34)],fill='#685039')
        s.polygon([(209,32),(250,32),(252,34),(252,71),(250,73),(209,73),(207,71),(207,35)],fill='#46362c')
        for n in range(5):
            yy=36+n*7
            s.polygon([(211,yy),(249,yy),(250,yy+1),(247,yy+4),(211,yy+4),(210,yy+3)],fill='#221f1f')
            s.line((211,yy+4,246,yy+4),fill='#826040')
            s.line((212,yy+5,245,yy+5),fill='#5a4332')
        for x,y in [(208,34),(251,71)]:
            s.rectangle((x-1,y-1,x+1,y+1),fill='#352b24');s.point((x,y-1),fill='#9a7a4e')
        # Soot, oxide and a little deep temper blue bleed from the vent side of
        # the existing transverse joint. The central standing plate stays quiet.
        for x0,y0,n,col in [(147,85,91,'#463c35'),(174,87,79,'#4d3c32'),(191,90,62,'#453a36'),(185,86,64,'#514236'),(209,84,44,'#68513b')]:
            w.polygon([(x0,y0),(x0+7,y0-2),(x0+n,y0-2),(x0+n,y0+2),(x0+n-23,y0+3),(x0+17,y0+1),(x0+4,y0+1)],fill=col)
        for x,y,l in [(174,79,11),(194,77,9),(222,77,14)]:
            w.line((x,y,x+l,y-1),fill='#65513e')
        # Rubbed diagonal slag scratches on the hot side.
        for x,y,l in [(203,104,10),(212,109,15),(223,108,12),(218,142,22),(199,154,11)]:
            w.line((x,y,x+l,y-5),fill='#59493a')
def compound_light(room,mat):
    im=practical(room,mat)
    d=ImageDraw.Draw(im)
    if room=='security':
        # Chipped strip reflection, stepped every few pixels with gaps at the
        # plate joint. Its bright core only occupies the left edge of the crop.
        for x,y,dy,width in [(44,0,14,4),(40,18,18,4),(34,37,22,3),(26,60,19,3),(20,82,8,2),(18,94,9,2)]:
            for n in range(dy):
                xx=x-round(n*.32)
                for off in range(width):
                    xy=(xx+off,y+n)
                    prior=im.getpixel(xy)[3]
                    d.point(xy,fill=(133,199,187,min(164,prior+(30 if off==1 else 14))))
        for x,y,L in [(36,23,18),(15,87,11),(64,36,8),(29,59,15)]:
            for xx in range(x,x+L+1):
                a=im.getpixel((xx,y))[3]
                d.point((xx,y),fill=(137,195,182,min(135,a+14)))
        d.line((22,92,39,92),fill=(147,196,178,79))
    else:
        # Independent practical cores recessed behind the diagonal louver slats.
        for i in range(5):
            y=37+i*7
            d.line((213,y+1,246,y+1),fill=(205,105,41,213))
            d.line((215+i*2,y,242-i,y),fill=(250,157,64,222))
            d.line((223+i,y,234+i,y),fill=(255,190,94,240))
            d.line((212,y+3,245,y+3),fill=(209,115,53,124))
        for x,y,dx,a in [(185,80,47,65),(202,84,37,75),(230,78,20,120),(214,74,29,140),(204,43,0,120),(215,31,26,135)]:
            d.line((x,y,x+dx,y if dx else y+14),fill=(246,155,65,a))
    return im
def redesign_desk():
    back,front=desk(); b=ImageDraw.Draw(back); f=ImageDraw.Draw(front)
    # Riveted carcase plinth and upright supports anchor the old desk.
    b.polygon([(91,167),(98,167),(113,183),(109,183)],fill='#3c5351')
    b.polygon([(153,168),(161,168),(143,184),(137,184)],fill='#334b4a')
    for x in (84,167):
        b.rectangle((x,178,x+4,183),fill='#405653');b.line((x,182,x+4,182),fill='#1c3333')
    # Clear the r01 provisional reader and paint the sloped reader housing.
    f.rectangle((85,111,166,150),fill='#32494a')
    f.polygon([(87,122),(95,113),(122,113),(131,122),(131,145),(126,149),(88,149),(85,145)],fill='#1c3131')
    f.polygon([(88,122),(95,114),(122,114),(129,121),(125,123),(91,123)],fill='#61736a')
    f.line((96,115,120,115,125,119),fill='#8a9688')
    f.polygon([(89,123),(126,123),(126,141),(122,144),(89,144)],fill='#3e5653')
    f.polygon([(93,124),(122,124),(122,137),(119,139),(92,139)],fill='#1a3234')
    f.line((94,125,120,125),fill='#344e4c')
    f.line((94,137,117,137,121,134),fill='#59726a')
    f.polygon([(87,143),(123,143),(128,140),(128,145),(123,148),(87,148)],fill='#69786c')
    f.line((92,144,115,144),fill='#202e2e');f.line((97,143,111,143),fill='#152b2d')
    f.line((89,148,108,148),fill='#8b9786')
    f.rectangle((137,129,164,144),fill='#203434')
    f.polygon([(139,129),(162,129),(164,131),(164,141),(162,143),(138,143),(137,141),(137,131)],fill='#7a877a')
    f.rectangle((140,132,161,139),fill='#475f58')
    f.line((142,133,156,133),fill='#576b60');f.line((139,141,160,141),fill='#98a18c')
    f.line((136,153,159,153),fill='#273f3e')
    # One rubbed lift/polish area on the audience-facing front lip.
    f.polygon([(82,162),(100,162),(102,163),(124,163),(120,165),(83,165)],fill='#6d8074')
    f.line((85,163,98,163),fill='#99a293');f.line((103,164,109,164),fill='#abb09a')
    f.line((116,164,122,164),fill='#8d998c')
    return back,front
def run():
    e=Image.new('RGB',(768,256))
    for index,r in enumerate(CFG):
        body,seams,wear=panel_base(r)
        # Confine grain contrast to a few values within each flat plane.
        # This keeps a mirrored dark grain patch from reading as an extra panel.
        px=body.load()
        for yy in range(256):
            for xx in range(256):
                rgb_here=px[xx,yy][:3]
                chosen=min((rgb(v) for v in CFG[r]['plates']),key=lambda q:sum((a-b)**2 for a,b in zip(q,rgb_here)))
                px[xx,yy]=mix(chosen,rgb_here,.35)+(255,)
        machine_marks(r,body,seams,wear)
        material=Image.alpha_composite(Image.alpha_composite(body,seams),wear)
        light=compound_light(r,material); lit=Image.alpha_composite(material,light)
        for role,im in [('base',body),('joints',seams),('wear',wear),('flat',material),('lit',lit)]:
            save(im,'env-floor-kit-'+r+'-'+role+'-r02')
        save(light,'env-light-shadow-'+r+'-practical-r02')
        mask=Image.new('RGBA',SIZE,(255,255,255,0));mask.putalpha(light.getchannel('A'))
        save(mask,'env-light-shadow-'+r+'-mask-r02')
        e.paste(lit,(index*256,0))
    back,front=redesign_desk()
    for name,im in [('back',back),('front',front)]:save(im,'sec-desks-s5-proof-'+name+'-r02')
    desk_composite=Image.open(OUT/'env-floor-kit-security-lit-r02.png')
    desk_composite=Image.alpha_composite(Image.alpha_composite(desk_composite,back),front)
    e.paste(desk_composite,(512,0));e.save(ROOT/'floor-proof-r02.png')
    cmp=Image.new('RGB',(768,512));cmp.paste(Image.open(ROOT/'floor-proof-r01.png'));cmp.paste(e,(0,256))
    cmp.save(ROOT/'floor-revision-comparison.png')
if __name__=='__main__':run()

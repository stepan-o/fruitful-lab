from build import *
from close import state
from step import foot,T0
import subprocess,zipfile
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def info(f):
 v={'path':str(f.relative_to(R)),'sha256':sha(f),'bytes':f.stat().st_size}
 if f.suffix=='.png':
  with Image.open(f) as im:v.update(width=im.width,height=im.height)
 return v
def save(name,doc):(R/name).write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
fset=json.loads((SRC/'pinned-score.json').read_text())['framesets']
pngs=sorted((R/'exports').rglob('*.png'));filedict={str(p.relative_to(R)):n for n,p in enumerate(pngs)}
def index(f):return filedict[str(f.relative_to(R))]
a=Image.open(A/'char-bob-palm-unjam-SE-07-base.png')
body=z(FS);body.alpha_composite(a,AO);fg=fixture()[-1]
alpha=ImageChops.multiply(body.getchannel('A'),fg.getchannel('A'));covered=sum(alpha.histogram()[1:])
assert a.getpixel(HIT)[3] and door(0).getpixel(FXH)[3] and not fg.getpixel(FXH)[3] and covered>0 and (HIT[0]+AO[0],HIT[1]+AO[1])==FXH
poses=[];exposure=[]
for f in fset[0]['frames']:
 t=f['edited'];i=state(t,TIMES);k=state(t,DOORS);dx,dy=POSES[i][1:3]
 rr,ll=[foot(t,side) for side in ('r','l')]
 free=(143+round(POSES[i][5]*.9),185+round(dy*.7-abs(POSES[i][5])*.8))
 sockets={'foot_r':list(rr[:2]),'foot_l':list(ll[:2]),'hand_r':list(POSES[i][4]),'hand_l':list(free),'palm_hit':list(POSES[i][4]),'look':[134+dx,153+dy],'prop':list(POSES[i][4]),'pocket':[131+round(dx*.4),176+round(dy*.4)],'support':list(POSES[i][4])}
 base=(A/'recovery'/f'char-bob-recovery-{f["n"]:03d}-base.png') if t>T0+.001 else A/f'char-bob-palm-unjam-SE-{i:02d}-base.png'
 lighting=base.with_name(base.name.replace('base.png','light.png' if t>T0+.001 else 'forge-light.png'))
 exposure.append({'edited':round(t,4),'durationMs':50,'worldRoot':f['bob'],'pose':i,'baseIndex':index(base),'lightIndex':index(lighting),'emissionIndex':index(A/f'char-bob-palm-unjam-SE-{i:02d}-emission.png'),'doorIndex':index(F/f'mach-forge-C4-door-{k}.png'),'jamHeld':f['jam'],'sockets':sockets,'planted':{'r':rr[2],'l':ll[2]}})
 for side,ft in [('r',rr),('l',ll)]:
  if ft[2]:assert abs((f['bob'][0]-131.7)*64+ft[0]-ft[3])<=.500001,(t,side,ft)
for i,pose in enumerate(POSES):
 basename=A/f'char-bob-palm-unjam-SE-{i:02d}-base.png';body=Image.open(basename).convert('RGBA')
 lay=[Image.open(A/f'char-bob-palm-unjam-SE-{i:02d}-{kind}.png').convert('RGBA') for kind in ['lower-body','torso-head','free-arm','striking-arm']]
 assert composite(lay).tobytes()==body.tobytes()
 poses.append({'id':pose[0],'frame':i,'fileIndex':index(basename),'atlasRect':[0,0,256,256],'sourceSize':[256,256],'trimRect':[0,0,256,256],'pivotPx':[128,208],'durationMs':sum(r['durationMs'] for r in exposure if r['pose']==i),'sockets':next(r['sockets'] for r in exposure if r['pose']==i),'exposureNote':'Aggregate time of this drawing; ordered exposure in display-track.json.'})
markers=[{'name':'charged plant','frame':144,'edited':108.5,'cosmeticOnly':True},{'name':'right palm heel meets held door','frame':152,'edited':108.9,'cosmeticOnly':True},{'name':'westbound recovery begins','frame':156,'edited':109.1,'cosmeticOnly':True}]
for side,steps in [('l',[.23,.80,1.37]),('r',[.45,1.02])]:
 for st in steps:
  if T0+st<110.5:markers.append({'name':'recovery footfall '+side,'edited':round(T0+st,3),'frame':math.ceil((T0+st-101.3)*20-1e-8),'cosmeticOnly':True})
save('display-track.json',{'fps':20,'startEdited':101.3,'endExclusiveEdited':110.5,'frames':exposure})
save('palm-unjam-manifest.json',{'schemaVersion':1,'status':'revised-composited-proof-awaiting-owner-acceptance','revision':'lane04-r02','assetId':'char-bob','dependencies':['char-bob-neutral-se-r2','selected B Forge','mach-forge-C4','approved-factory/day-one-3','pinned score'],
 'sprite':{'sourceSize':[256,256],'pivotPx':[128,208],'sortAnchorPx':[128,208],'trimRect':[0,0,256,256],'groundFootprintMetres':None,'layer':'actor','sockets':poses[7]['sockets']},
 'clips':[{'id':'palm-unjam','facing':'SE','frames':poses,'entryFrame':0,'holdFrame':0,'exitFrame':0,'loopRange':None,'markers':markers,'compatibleNext':['injured-idle','injured-westward-step']}],
 'timing':'7.2s hold cue and 1.4s knock. Jam ends at 108.9s. Knock continues through visible westbound motion from 109.10 s. Exposure and root tracks remain independent.',
 'injury':'Anatomical left carries reduced weight, right side takes the full plant. Source does not key a side. Right hand strikes.',
 'drawOrder':['C4 base, rear, held door, control','actor shadow','actor base','selected B Forge-light','optional ocular emission','C4 front guard and western upright'],
 'machine':{'assetId':'mach-forge','marker':'C4','sourceSize':list(FS),'groundNW':list(FP),'groundRectPx':[32,164,256,256],'groundRectMetres':[130,145,4,4],'groundPivotPx':[160,420],'sortAnchorPx':[160,420],'operatorWorld':[131.7,144.4],
 'sockets':{'operator_stand':list(AP),'palm_hit_jammed':list(FXH),'handle':[235,82],'cradle_in':[32,273],'cradle_out':[288,273],'press_axis':[160,273]},
 'sourceCarrierYMetres':147,'carrierPlaneGroundYpx':292,'elevatedCradleSurfaceYpx':273,'surfaceRisePx':19,'scope':'Cutaway working face. Nominal 5.8m full assembly is not drawn. Palm targets an elevated working face.',
 'doorStateSource':'PR153 equipment() jam changes at world 109.3. Native opening movement is 20px (0.32m). Six hand-timed frames after held drawing, including 2px overshoot.',
 'doorTrack':[{'sourceTime':t,'frame':k,'fileIndex':index(F/f'mach-forge-C4-door-{k}.png'),'durationMs':round(((DOORS[n+1][0] if n+1<len(DOORS) else 110.5)-t)*1000)} for n,(t,k) in enumerate(DOORS)],'frameCount':7},
 'visibleContact':{'actorPx':list(HIT),'fixturePx':list(FXH),'actorToFixtureOffset':list(AO),'guardOccludedBodyPixels':covered,'heelOpaqueInActorAndDoor':True,'guardAlphaAtHeel':0},'files':[info(p) for p in pngs]})
doc=[]
for f in sorted(PROOF.glob('forge-*-1x.mp4')):
 data=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,nb_frames,duration,r_frame_rate','-of','json',str(f)]))['streams'][0]
 assert int(data['nb_frames'])==184 and float(data['duration'])==9.2
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(f),'-f','null','-'],check=True)
 doc.append(info(f)|data)
save('verification.json',{'geometry':'approved-factory/day-one-3','scoreDurationSeconds':190.60391778732966,'sourceClipDurationSeconds':9.2,'clipRangeEdited':[101.3,110.5],'fullDecodeChecks':doc,'drawingsReassembled':len(poses),'guardCoversBodyPixels':covered,'visibleHeel':True,'plantedSoleWorldQuantizationAt20fpsMaxPx':.5,'notes':['Silent source. Original speech appears as timed captions in lit films.','Composited films use rehearsal camera and source cast/brain state. No engine playback or device hardware results.','Phone room cameras communicate the strike/release; the heel/fingertips distinction requires the lens.']})
ref=R.parent/'04-jammed-press'
save('provenance.json',{'rehearsalCommit':'d0e85b3a8d29b39da320d342fdff40847c478c8c','rehearsalHtmlGitBlob':'a41039c08c873e6496a420ba2f599bb9bd3183b0','sourceReferenceHashes':{str(p.relative_to(ref)):sha(p) for p in sorted((ref/'refs').rglob('*')) if p.is_file()},'ownerSelectedMaster':{'id':'char-bob-neutral-se-r2','treatment':'B','bodySHA256':sha(SRC/'selected-B-body.png'),'floorSHA256':sha(SRC/'selected-B-floor.png')},'methods':'Original native C4 and manually keyed SE actor over approved layered bob. New right striking arm retains master materials. Floor, optics, legs, head, torso and free arm reuse the exemplar. Other cast and products use PR153 draw calls. Source route, state and dialogue were sampled offline.','rejected':[{'rev':'r01','reason':'Body stayed upright; small gesture read as poking. Door edge lacked material contrast.','retained':'rejected/r01/'}]})
print(len(pngs),'native files',len(doc),'full-length previews',covered,'guard pixels')

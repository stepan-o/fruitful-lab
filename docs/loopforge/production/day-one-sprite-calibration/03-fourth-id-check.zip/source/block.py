from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json
d=Path(__file__).resolve().parents[1];data=json.loads((d/'work/score.json').read_text());r=data['frames'][145]
im=Image.new('RGB',(720,420),'#21332f');dr=ImageDraw.Draw(im)
def p(x,y):return tuple(round(v) for v in ((x-126.35)*64,(y-128.85)*64))
for y in range(0,421,64):dr.line((0,y,720,y),fill='#2d413d')
for x in range(0,721,64):dr.line((x,0,x,420),fill='#2d413d')
for mk in data['markers']:
 if mk['id'] in ('S5','S1','S2','S6'):
  rr=mk['rect'];x,y=p(rr['x'],rr['y']);w,h=round(rr['w']*64),round(rr['h']*64)
  if mk['id']=='S5':dr.rectangle((x,y-19,x+w,y+h-19),fill='#4d6669',outline='#9abab7');dr.rectangle((x,y+h-19,x+w,y+h),fill='#324646')
  else:dr.rectangle((x,y-4,x+w,y+h-4),fill='#596865',outline='#9da68f')
for who in ('max','LIMEN','STILETTO'):
 x,y=p(*r['actors'][who]['p']);col={'max':'#8d9290','LIMEN':'#a9b9ad','STILETTO':'#38434b'}[who];hi={'max':'#b0b0ac','LIMEN':'#bcccc5','STILETTO':'#8d9a9d'}[who]
 dr.ellipse((x-11,y-3,x+12,y+3),fill='#13201e');dr.line((x-5,y-32,x-9,y),fill=col,width=7);dr.line((x+5,y-32,x+9,y),fill=col,width=7)
 dr.polygon([(x-15,y-66),(x+12,y-68),(x+8,y-37),(x-9,y-34)],fill=col)
 if who=='max':dr.polygon([(x-7,y-79),(x+6,y-78),(x+4,y-58),(x-5,y-62),(x-11,y-69)],fill=hi)
 else:dr.ellipse((x-9,y-85,x+9,y-64),fill=hi)
 if who=='LIMEN':
  dr.line((x+9,y-57,x+34,y-43,x+55,y-72),fill=hi,width=7);dr.rounded_rectangle((x+51,y-89,x+65,y-71),2,fill='#e5d8aa',outline='#282c2a');dr.polygon([(x+56,y-85),(x+61,y-85),(x+61,y-78),(x+56,y-80)],fill='#777d79');dr.line((x-14,y-52,x-20,y-32,x-30,y-43),fill='#46b3b8',width=4)
 if who=='STILETTO':
  for xx in (-12,13):dr.ellipse((x+xx-5,y-68,x+xx+5,y-60),fill='#c75347')
  for ax,ay,ex,ey,tx,ty in [(-11,-62,-31,-74,-91,-143),(11,-61,-1,-78,-56,-134)]:
   dr.line((x+ax,y+ay,x+ex,y+ey),fill=hi,width=7);dr.polygon([(x+ex-3,y+ey+4),(x+ex+4,y+ey-4),(x+tx,y+ty)],fill='#bdcfce')
 font=ImageFont.truetype('/usr/share/fonts/liberation-mono-fonts/LiberationMono-Regular.ttf',11)
 dr.text((x+15,y+4),who+(' · stand-in' if who=='max' else ''),font=font,fill='#dae0d3')
dr.text((16,12),'ROUGH STAGING   /   S5 • source pose @ 132.35 s',font=font,fill='#e3d0a3')
im.save(d/'review/rough-key-pose.png')

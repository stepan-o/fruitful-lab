# Day One calibration floors and S5 desk

Revision r02 is the art director’s candidate for owner style selection. The native production samples are two 4 × 4 m material swatches and a simple depth-test desk. The source geometry is approved-factory/day-one-3. Each pixel on the horizontal ground axes represents 1/64 m. North is up.

## Floor layers

Place the 256 × 256 base, joints and wear PNGs at the same top-left origin in that order, using ordinary straight-alpha compositing. The flat PNG contains the identical material composite. Place the corresponding practical above the floor and below cast shadows and actors for the lit room. The practical on its own uses transparency. The separate white PNG holds the same alpha as a scalar mask for a renderer.

Tile only the base material. Place the local lamp reflection and Forge louver treatment once at their source. A whole room needs authored placement and variation. The r02 tile proof shows the dry tile joins in a 1× center crop and 0.5× repeat. The louver and queue grips represent flush material details for this calibration.

For the simplest unlit proof use each room’s flat PNG and omit its practical. For the identity comparison with only bob’s ocular emission off, keep the practicals enabled and omit bob’s eye-emission layer. This preserves the two room treatments. Actor color, contact shadow, eye emission and cast shadow are supplied separately by the character and integration artists.

## S5 desk registration

Place both untrimmed 256 × 256 layers at the same origin. Pixel (128, 208) is the middle of the **south ground edge**, world (131.6, 131.9) m. The rectangular ground footprint spans pixel edges [77, 179) by [144, 208). The source value is 1.6 × 1.0 m at northwest world (130.8, 130.9). The single horizontal conversion rounds 102.4 source pixels to 102 drawn pixels. Elevation projects north independently. The measured height of 1.02 m becomes 41 pixels at this calibration’s provisional 40 vertical pixels per metre. The first top edge is y = 103.

The back PNG contains the legs and bracing. The front PNG contains the sloped north-facing reader housing, tray, solid worktop and chipped south edge. Place both desk layers after a fully rearward actor for a behind-fixture pass. For an actor fully in front of the desk, place the actor after both layers. The two slices permit an intermediate overlap to be authored if required. Keep the ground pivot for sorting and use actual world contact for runtime checks.

## Source and checks

The sixteen native PNGs carry sRGB metadata. Their dimensions, layer order and content hashes are in the manifest. The verification script checks full RGBA equality for both floor assemblies, both baked lit references and their practical masks. The palette file separates reference paints from their rendered shadow and practical roles. Editable layers retain the neutral material and the practical independently. The references, generated material study and construction scripts are identified in the provenance file.

To rebuild in place, run `python3 source/draw.py`, then `python3 source/revise.py`, then `python3 source/pack.py`. The last command uses the original lane pack alongside this working directory to hash provenance. The deliverable contains no animation or engine capture. Final contacts, depth order and runtime scale require the integrated viewport.

# The morning walk

max retracts his jaw, squares his shoulders, and carries LIMEN’s bearing from 0.50 to 1.50 seconds over two full 0.775 m strides. bob looks back while both keep walking north. The shared track cuts to the southbound Security arrival at 12.5 seconds. The final spoken line ends at 12.05 seconds. This 16.3-second calibration excerpt uses the original movement, edit and on-screen lines.

Start with proofs/morning-inspection-speech.mp4 for the tracked, enlarged 1× acting test. Its left panel preserves relative world positions while the two close panels follow individual actors. The matching dark version hides text and disables glow. The 1280, 390 and 320 files show the source camera at those viewport sizes. All seven videos are composited; the director handles the engine playback review.

For Engine, manifest.json lists the untrimmed origin, source-time atlases and reusable gait/action sheets. Draw the separated cast/contact shadow, base, selected light pass and optional emissive on one registered 256 × 256 frame. Each source-time frame lasts 50 ms. Restore the shared 72 × 127 trimmed tile at (92,110) before pivoting at (128,208). Frame events are cosmetic.

In motion/reusable/, the gait atlas contains eight in-place poses per direction. Advance by actual travelled distance; a full 0.775 m maps to one cycle. Left and right contacts sit at phases 0 and 0.5. Each upper action uses eight levels across eight gait phases with four release keys. The action retains the legs from the active gait. The tighter source-time actor atlas resolves stance lock against each actual rehearsal sample; its measured worst native rounding excursion is under one pixel.

max-master/ contains S, SE and N layered OpenRaster files, per-part PNGs, sockets and palette. The SE and S heads are the shared fourth-check identity and credential portrait. Verify the hashes before reuse. Reference portraits and provenance accompany the package.

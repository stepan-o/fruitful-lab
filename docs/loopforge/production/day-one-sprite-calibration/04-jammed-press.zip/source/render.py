from build import *
from close import enc,state
from step import foot,tail_layers,T0
from raster import render
from functools import lru_cache
import sys
score=json.loads((SRC/'pinned-score.json').read_text())
cache=json.loads((SRC/'draw-cache.json').read_text());cache_dir=R/'cache';cache_dir.mkdir(exist_ok=True)
forms=[(x,Image.open(F/f'mach-forge-C4-{x}.png').convert('RGBA')) for x in ('base','rear-guard','control','front-guard')]
floor=Image.open(SRC/'selected-B-floor.png').convert('RGBA');shadow=Image.open(SRC/'selected-B-shadow.png').convert('RGBA')
bg=(13,25,27);ink='#f1e8d0';muted='#a9bbb5';amber='#e7b16d'
fontfile='/usr/share/fonts/liberation-sans-fonts/LiberationSans-'
@lru_cache(maxsize=32)
def font(size,bold=False):return ImageFont.truetype(fontfile+('Bold' if bold else 'Regular')+'.ttf',size)
@lru_cache(maxsize=20)
def shown(idx):return actor(idx,False)
@lru_cache(maxsize=9)
def dr(k):return door(k)
@lru_cache(maxsize=200)
def plate(key,w,h):
 p=cache_dir/(key+f'-{w}-{h}.png')
 if not p.exists():render(cache[key],w,h,p)
 return Image.open(p).convert('RGBA')
def projected(dst,im,worldPivot,nativePivot,ratio):
 box=im.getbbox()
 if not box:return
 ax,ay=worldPivot;bx,by=nativePivot
 imin=(math.floor(ax+(box[0]-bx)*ratio)-1,math.floor(ay+(box[1]-by)*ratio)-1)
 imax=(math.ceil(ax+(box[2]-bx)*ratio)+1,math.ceil(ay+(box[3]-by)*ratio)+1)
 ds=(imax[0]-imin[0],imax[1]-imin[1])
 out=im.transform(ds,Image.Transform.AFFINE,(1/ratio,0,bx+(imin[0]-ax)/ratio,0,1/ratio,by+(imin[1]-ay)/ratio),Image.Resampling.NEAREST)
 dst.alpha_composite(out,imin)
def textwrap(d,words,face,limit):
 lines=[]
 for word in words.split():
  val=(lines[-1]+' '+word).strip() if lines else word
  if lines and d.textlength(val,font=face)>limit:lines.append(word)
  elif lines:lines[-1]=val
  else:lines.append(word)
 return lines
def rails(im,data,vw,vh,x,rail_y,rw,rh,blind,font_size):
 d=ImageDraw.Draw(im);d.rectangle((x,rail_y,x+rw-1,rail_y+rh-1),fill='#182a2a')
 if blind:
  d.text((x+13,rail_y+17),'Names hidden   ·   eye emission off',font=font(13,True),fill=muted)
  return
 if data['voices']:
  v=data['voices'][0];name=v['speaker'];text=v['text'];c=amber if name=='bob' else '#dc957d'
  if not blind:d.text((x+13,rail_y+10),name,font=font(12,True),fill=c)
  else:d.text((x+13,rail_y+10),'',font=font(12,True),fill=c)
  face=font(font_size);lines=textwrap(d,text,face,rw-28)
  for j,line in enumerate(lines):d.text((x+13,rail_y+30+j*(font_size+4)),line,font=face,fill=ink)
  assert 30+len(lines)*(font_size+4)<=rh
def track_actor(f):
 idx=state(f['edited'],TIMES);body,overlay,em=shown(idx);lit=Image.alpha_composite(body,overlay)
 if f['edited']>T0+.001:
  body,lit,em=tail_layers(f['edited'],idx)
  td=A/'recovery';td.mkdir(exist_ok=True)
  if not (td/f'char-bob-recovery-{f["n"]:03d}-base.png').exists():
   put(body,td/f'char-bob-recovery-{f["n"]:03d}-base.png')
   # Exact room light layer as changed paint with full registration.
   dif=ImageChops.difference(body.convert('RGB'),lit.convert('RGB')).split();a=ImageChops.lighter(ImageChops.lighter(dif[0],dif[1]),dif[2]).point(lambda v:255 if v else 0)
   ol=lit.copy();ol.putalpha(ImageChops.multiply(a,lit.getchannel('A')));put(ol,td/f'char-bob-recovery-{f["n"]:03d}-light.png')
 return body,lit,em,idx,state(f['edited'],DOORS)
def roomstage(f,blind,actor_parts):
 w,h=map(round,f['stage']); ratio=f['scale']/64;fx=f['fixturePx'];ax=f['actorPx']
 g=plate(f['ground'],w,h).copy()
 # A single original swatch on the north/operator side, two pieces under the machine.
 floorAnchor=[fx[0]+(109/64)*f['scale'],fx[1]-(38/64)*f['scale']]
 projected(g,floor,floorAnchor,(128,128),ratio)
 g.alpha_composite(plate(f['scenery'],w,h))
 for layer in [forms[0][1],forms[1][1],dr(actor_parts[4]),forms[2][1]]:projected(g,layer,fx,FP,ratio)
 # Corpses/props do not change state here: use exactly the parent score's other cast/products.
 g.alpha_composite(plate(f['other'],w,h))
 projected(g,shadow,ax,(128,208),ratio)
 body,lit,em,_,_=actor_parts
 if not blind:lit=Image.alpha_composite(lit,em)
 projected(g,lit,ax,(128,208),ratio);projected(g,forms[3][1],fx,FP,ratio)
 return g
def classified_frame(f,viewport,blind,parts):
 vw,vh=viewport;phone=vw<620;stage=roomstage(f,blind,parts);w,h=stage.size;x=(vw-w)//2
 im=Image.new('RGB',(vw,vh),bg);d=ImageDraw.Draw(im);dy=19 if not phone else 14
 d.text((x,dy),'LOOPFORGE   /   DAY ONE',font=font(13,True),fill=amber)
 d.text((x,dy+25),'Jammed Forge press',font=font(32 if not phone else 25,True),fill=ink)
 d.text((x,dy+66),'The second brain',font=font(16),fill=muted)
 sy=dy+93+(100 if phone else 83)
 rails(im,f,vw,vh,x,dy+93,w,100 if phone else 83,blind,15 if phone else 22)
 im.paste(stage.convert('RGB'),(x,sy));by=sy+h+12
 d.text((x,by),f'Room camera   /   1×   /   {f["edited"]:.2f} s',font=font(14,True),fill=ink)
 d.text((x,by+24),'Composited motion proof',font=font(13),fill=muted)
 if blind:d.text((x,by+45),'Names hidden   ·   eye emission off',font=font(13),fill=muted)
 return im
def closeup(f,blind,parts):
 # Same world geometry and genuine moving actor registration at an inspection magnification.
 scene=z((592,302)); anchor=(245,102); fx=(136,140)
 for xx in (-139,117,373):
  for yy in (-26,230):scene.alpha_composite(floor,(xx,yy))
 for layer in [forms[0][1],forms[1][1],dr(parts[4]),forms[2][1]]:scene.alpha_composite(layer,(fx[0]-FP[0],fx[1]-FP[1]))
 p=(round(anchor[0]+(f['bob'][0]-131.7)*64),round(anchor[1]+(f['bob'][1]-144.4)*64))
 pos=(p[0]-128,p[1]-208);scene.alpha_composite(shadow,pos)
 _,lit,em,_,_=parts
 scene.alpha_composite(lit if blind else Image.alpha_composite(lit,em),pos)
 scene.alpha_composite(forms[3][1],(fx[0]-FP[0],fx[1]-FP[1]))
 scene=scene.crop((71,15,384,232))
 # Pixel-preserving 2x inspection crop with surrounding observer field.
 output=Image.new('RGB',(960,640),bg);d=ImageDraw.Draw(output)
 d.text((32,16),'C4   /   Jammed Forge press',font=font(28,True),fill=ink)
 d.text((32,57),'Working-face inspection lens    ·    2× native pixels    ·    1× playback',font=font(18),fill=muted)
 output.paste(scene.resize((626,434),Image.Resampling.NEAREST).convert('RGB'),(168,87))
 rails(output,f,960,640,32,535,896,75,blind,21)
 d.text((32,616),f'Composited motion proof   /   {f["edited"]:.2f} s',font=font(14),fill=muted)
 return output
def main():
 for group in score['framesets']:
  vw,vh=group['viewport'];encs={}
  for blind in (False,True):
   label='blind' if blind else 'lit'
   encs[blind]=enc(PROOF/f'forge-room-{vw}x{vh}-{label}-1x.mp4',(vw,vh))
  eclose={b:enc(PROOF/f'forge-contact-inspection-{"blind" if b else "lit"}-1x.mp4',(960,640)) for b in (False,True)} if vw==1280 else {}
  for f in group['frames']:
   parts=track_actor(f)
   for b,e in encs.items():
    im=classified_frame(f,(vw,vh),b,parts)
    if f['n']==152 and not b:im.save(PROOF/f'contact-room-{vw}.png')
    e.stdin.write(im.tobytes())
    if b in eclose:
     close=closeup(f,b,parts)
     if not b and f['n']==152:close.save(PROOF/'clean-contact-inspection.png')
     eclose[b].stdin.write(close.tobytes())
  for e in [*encs.values(),*eclose.values()]:e.stdin.close();assert e.wait()==0
  print('complete',vw,flush=True)
if __name__=='__main__':main()

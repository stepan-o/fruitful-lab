"""Author the two 4-metre native materials and registered depth-test fixture."""
from pathlib import Path
import math, json, random, hashlib
from PIL import Image, ImageDraw, ImageFilter, ImageOps, PngImagePlugin

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'png'
SIZE=(256,256)
TRANS=(0,0,0,0)
def blank(): return Image.new('RGBA',SIZE,TRANS)
def save(im, name):
    meta=PngImagePlugin.PngInfo()
    meta.add(b'sRGB',b'\0')
    im.save(OUT/(name+'.png'),pnginfo=meta)
def rgb(s):return tuple(bytes.fromhex(s.lstrip('#')))
def mix(a,b,frac):return tuple(round(x+(y-x)*frac) for x,y in zip(a,b))
CFG={
'security': {
 'plates':['283e40','2a4042','2d4344','2a3f42','2d4447'],
 'slot':'15282b','shadow':'1e3337','edge':'39504e','metal':'52615a','nick':'6c7770','oxide':'3f463e','tint':'82b9b6','warm':'a7b2d3',
 'rows':[(16,91,[22,164]),(91,200,[73,226]),(200,272,[39,178])]},
'forge': {
 'plates':['383330','3d3732','3a3632','373431','3f3933'],
 'slot':'231f1f','shadow':'2a2727','edge':'50443a','metal':'6a5746','nick':'8b6d50','oxide':'4d352b','tint':'ee9642','warm':'666860',
 'rows':[(8,82,[64,201]),(82,186,[35,158]),(186,264,[67,215])]}
}
def shape(draw, method, coords, fill):
    # Shapes are authored on a torus, including the two visible crop boundaries.
    for dx in (-256,0,256):
        for dy in (-256,0,256):
            pts=[(x+dx,y+dy) for x,y in coords]
            getattr(draw,method)(pts,fill=fill)
def panel_base(room):
    c=CFG[room]; im=Image.new('RGBA',SIZE,rgb(c['plates'][0])+(255,))
    seams=blank();wear=blank();base=ImageDraw.Draw(im);sd=ImageDraw.Draw(seams);wd=ImageDraw.Draw(wear)
    rng=random.Random(708 if room=='security' else 741)
    for yindex,(y0,y1,edges) in enumerate(c['rows']):
        for pi,x0 in enumerate(edges):
            x1=edges[(pi+1)%2]+(256 if pi==1 else 0)
            color=rgb(c['plates'][(pi+yindex*2)%5])
            shape(base,'rectangle',[(x0,y0),(x1-1,y1-1)],color)
            for pts,col in [
                ([(x0,y0),(x1-1,y0)],'slot'), ([(x0,y0),(x0,y1-1)],'slot'),
                ([(x0+1,y0+1),(x1-2,y0+1)],'edge'),
                ([(x0+1,y0+2),(x0+1,y1-2)],'edge'),
                ([(x0+2,y1-1),(x1-1,y1-1)],'shadow')]:
                shape(sd,'line',pts,rgb(c[col]))
            # Bare contact/slip edges occur in clusters along service plate lips.
            for n in range(2 if room=='security' else 3):
                start=x0+rng.randrange(8,max(9,x1-x0-18))
                length=rng.randrange(6,18)
                shape(wd,'polygon',[(start,y0+2),(start+3,y0+2),(start+5,y0+1),(start+length,y0+1),(start+length-3,y0+3),(start+6,y0+3),(start+4,y0+4),(start,y0+4)],rgb(c['oxide']))
                shape(wd,'line',[(start+4,y0+2),(start+length-4,y0+2)],rgb(c['metal']))
            # Lower-left and upper-right countersunk fasteners.
            for x,y in [(x0+9,y1-8),(x1-8,y0+9)]:
                shape(sd,'polygon',[(x-2,y-1),(x-1,y-2),(x+1,y-2),(x+2,y-1),(x+2,y+1),(x+1,y+2),(x-1,y+2),(x-2,y+1)],rgb(c['shadow']))
                shape(sd,'line',[(x-1,y-1),(x+1,y-1)],rgb(c['metal']))
                shape(sd,'line',[(x,y),(x+1,y)],rgb(c['slot']))
    # Broad broken surface mottling: an unoriented patch of the original material
    # study contributes grain only, never the lighting distribution or seam design.
    concept=Image.open(ROOT/'source/material-concept.png').convert('L')
    w,h=concept.size; cx=w*.27 if room=='security' else w*.72
    grain=concept.crop((int(cx-100),int(h*.45-100),int(cx+100),int(h*.45+100))).resize((64,64),Image.Resampling.BOX)
    grain=ImageOps.autocontrast(grain,cutoff=4).filter(ImageFilter.MedianFilter(3))
    basepix=im.load();gp=grain.load()
    for y in range(256):
        for x in range(256):
            gx=(x//2)%128;gy=(y//2)%128
            k=gp[min(gx,127-gx),min(gy,127-gy)]
            f=(-2 if k<47 else -1 if k<83 else 0 if k<154 else 1 if k<205 else 2)
            basepix[x,y]=tuple(max(0,min(255,v+f*2)) for v in basepix[x,y][:3])+(255,)
    if room=='security':
        # Flush twin-dog access catch; all hardware remains beneath walking plane.
        for x,y in [(42,56),(194,221)]:
            shape(sd,'polygon',[(x,y+1),(x+2,y-1),(x+15,y-1),(x+17,y+1),(x+16,y+6),(x+2,y+6),(x,y+4)],rgb(c['shadow']))
            shape(sd,'line',[(x+2,y-1),(x+14,y-1)],rgb(c['edge']))
            for x2 in [x+4,x+12]:
                shape(sd,'rectangle',[(x2-1,y+1),(x2+1,y+3)],rgb(c['slot']))
                shape(sd,'line',[(x2-1,y+1),(x2,y+1)],rgb(c['metal']))
        # Four fine catch slots on a single access cover, not a new drain.
        for n in range(4):
            x=180+n*5;y=34
            shape(sd,'polygon',[(x,y+2),(x+2,y),(x+3,y),(x+3,y+7),(x+1,y+9),(x,y+9)],rgb(c['shadow']))
            shape(sd,'line',[(x+3,y+7),(x+1,y+9)],rgb(c['edge']))
    else:
        # The plate that faces the hot machine has raised catches at its edges.
        for x,y in [(13,100),(98,18),(195,210)]:
            shape(sd,'polygon',[(x-3,y+1),(x-2,y-2),(x+1,y-3),(x+3,y-1),(x+3,y+2),(x,y+4),(x-3,y+3)],rgb(c['shadow']))
            shape(sd,'line',[(x-2,y),(x,y-2),(x+1,y-2)],rgb(c['metal']))
            shape(sd,'line',[(x,y+2),(x+2,y+1)],rgb(c['slot']))
    # Deeper hooked scrapes and paired edge abrasions kept away from bob's soles.
    for x,y,ln in ([(7,122,12),(76,29,14),(201,171,11),(174,248,6)] if room=='security' else [(14,51,13),(81,56,7),(213,118,18),(208,203,6),(18,220,15)]):
        shape(wd,'polygon',[(x,y),(x+2,y-1),(x+5,y-1),(x+ln,y-5),(x+ln-2,y-3),(x+6,y),(x+4,y),(x+1,y+1)],rgb(c['edge']))
        shape(wd,'line',[(x+1,y+1),(x+5,y)],rgb(c['metal']))
    return im,seams,wear
def practical(room, mat):
    c=CFG[room]; layer=blank();p=layer.load();pix=mat.load()
    for y in range(256):
        for x in range(256):
            if room=='security':
                # Two tight cold reflections of a ceiling bar at a raking angle.
                off=x-(48-.34*y)
                k=math.exp(-(off/27)**2)*.45+math.exp(-((off-42)/10)**2)*.30
                k*=.58+.42*math.exp(-((y-39)/74)**2)
                ambient=.055*math.exp(-((x-90)/90)**2-((y-27)/140)**2)
                k+=ambient
                hue=rgb(c['tint']); alpha=round(k*150/4)*4
            else:
                # Low amber line-side spill, broken in places by guard supports.
                center=252-.20*y
                distance=x-center
                k=.65*math.exp(-(distance/46)**2)+.20*math.exp(-((distance+35)/80)**2)
                k*=.59+.41*math.exp(-((y-61)/116)**2)
                k*=1-.3*math.exp(-((y-152+x*.08)/9)**2)
                hue=rgb(c['tint']);alpha=round(k*145/4)*4
            # Discontinuity of reflectance at expansion joints/plate lips.
            value=max(pix[x,y][:3]);alpha=int(alpha*(.38 if value<46 else 1.07 if value>78 else .9))
            if alpha>0:p[x,y]=hue+(alpha,)
    return layer
def desk():
    back=blank(); front=blank();reflex=blank()
    b,f=ImageDraw.Draw(back),ImageDraw.Draw(front)
    # Measured half-open ground footprint [77,179) × [144,208); a 41px
    # projection rise on the south-facing 1.02m slope desk.
    dark='#14292b';deep='#1c3234';mid='#32494a';edge='#59706b';nick='#8c9490';rubber='#162b2d'
    b.rectangle((80,147,174,194),fill=deep)
    b.rectangle((83,147,89,205),fill=dark);b.rectangle((84,151,85,203),fill=mid)
    b.rectangle((166,146,172,205),fill=dark);b.rectangle((167,150,169,203),fill=mid)
    b.rectangle((82,202,90,206),fill=dark);b.rectangle((165,203,173,207),fill=dark)
    b.rectangle((91,158,164,189),fill=mid);b.rectangle((94,160,161,188),fill=deep)
    b.line((95,185,159,185),fill=dark);b.line((98,163,112,163),fill='#445958')
    # Desk top above rear and front contacts.
    f.polygon([(80,103),(176,103),(178,105),(178,165),(176,168),(79,168),(77,166),(77,106)],fill=dark)
    f.polygon([(81,104),(175,104),(177,106),(177,161),(174,164),(81,164),(78,162),(78,108)],fill=mid)
    f.line((81,105,175,105),fill=edge);f.line((79,108,79,159),fill='#48615d')
    f.line((80,164,175,164),fill=edge);f.line((84,165,102,165),fill='#71807b');f.line((109,165,126,165),fill='#506865');f.line((152,165,165,165),fill='#7b8880')
    # Blank reader and card tray are registration cues only.
    f.polygon([(92,120),(122,120),(125,123),(125,144),(122,147),(90,147),(89,145),(89,125)],fill=deep)
    f.polygon([(92,119),(121,119),(123,121),(123,142),(90,142),(90,124)],fill='#445a57')
    f.rectangle((94,124,119,138),fill='#1e3538');f.line((95,125,116,125),fill='#48625f')
    f.rectangle((136,129,164,144),fill='#263d3d');f.rectangle((138,130,162,141),fill='#697871');f.rectangle((140,131,160,140),fill='#536864')
    f.line((138,142,162,142),fill='#8e988c')
    for x in [83,172]:
        for y in [110,157]:f.point((x,y),fill='#849086')
    return back,front
def main():
    out_preview=Image.new('RGB',(768,256),'#222b2b')
    for i,room in enumerate(CFG):
        body,seams,wear=panel_base(room)
        mat=Image.alpha_composite(Image.alpha_composite(body,seams),wear)
        light=practical(room,mat);lit=Image.alpha_composite(mat,light)
        for role,im in [('base',body),('joints',seams),('wear',wear),('flat',mat),('lit',lit)]:
            save(im,'env-floor-kit-'+room+'-'+role+'-r01')
        save(light,'env-light-shadow-'+room+'-practical-r01')
        mask=Image.new('RGBA',SIZE,(255,255,255,0));mask.putalpha(light.getchannel('A'))
        save(mask,'env-light-shadow-'+room+'-mask-r01')
        out_preview.paste(lit,(i*256,0))
    back,front=desk();save(back,'sec-desks-s5-proof-back-r01');save(front,'sec-desks-s5-proof-front-r01')
    surface=Image.open(OUT/'env-floor-kit-security-lit-r01.png')
    surface=Image.alpha_composite(Image.alpha_composite(surface,back),front)
    out_preview.paste(surface,(512,0))
    out_preview.save(ROOT/'floor-proof-r01.png')
if __name__=='__main__':main()

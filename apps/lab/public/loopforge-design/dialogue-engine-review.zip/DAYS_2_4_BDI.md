# Who heard the second answer?

**Loopforge · WRITER’s decision notes for SYSTEMS, then ENGINE · 19 November 2026**

The [table read](DAYS_2_4_TABLE_READ.md) follows a single family of choices. LIMEN wins all three appointments. A pass uses the Day 2 intervention. The Producer watches through the next two bells. The initials and numbers below are rehearsal marks shared with the script. Day numbers label the performances for a reader. The [Dialogue Engine](DIALOGUE_ENGINE.md), [60 chat decisions with dialogue](ROOM_CHAT_BANK.md) and [SYSTEMS review cases](DIALOGUE_ENGINE_REVIEW.md) share the room budgets below.

## What the participants bring in

**Interview.** The authority for behavioral premises is SYSTEMS revision `16a54fc`, file `docs/loopforge/DAYS_2_4_SYSTEMS_STUDY.md`, from “Owner interview · How Day 1 decisions work” through “How the first supervisor conflict develops.” Its companion `DAYS_2_4_SYSTEMS_PLAN.md` proposes the slice. Earlier scenarios in the study are historical. The [approved Day One script](/stepanoskin/loopforge/design#day-one-intro) supplies the physical starting facts and the [writing guide](/stepanoskin/loopforge/design#writing-style) supplies the voices. The [prototype at 2dc430e](https://fruitful-bq9libja5-stepan-oskins-projects.vercel.app/loopforge-shifts/index.html) has its own measured runs. In particular it starts with workers at the gate. These walk-ins, utterances, choices and resulting counts are writing proposals.

| Authority | What enters the decision |
| --- | --- |
| Interview · first morning | Workers want company, relief from work and to heed authority. The strike has made obedience weigh more. bob remembers being hit and wants to understand things. sam helped him. ed picked up the card. The ten do not share one recording of the blow. A bell can beat an order to keep working. |
| Interview · bids and work | LIMEN wants protocol. He is initially cautious with a peer. STILETTO wants the line running and at least five finished cortexes. Three on the rack after Day One left a shortfall. The player accepts one complete bid. Keeping yesterday’s posts leaves two clerks at Security and eight at Conveyor. The room leader chooses policy. The worker must still do the job. |
| Interview · ID | Each worker believes they have their own original, except bob, who believes his is missing and wants to find it. ed also knows he has bob’s. An actual failed check admits a daily pass or detention until the bell. Expedited passage can skip detection. The floor build additionally holds both desks until an open case closes. |
| Interview · learning | LIMEN’s second yield and STILETTO’s experience of it consolidate overnight into “she is against protocol” and “he is weak.” A subsequent refusal, press and yield cost him confidence and authority. Overnight he comes to regard her as reckless. He now has a stronger reason to sustain a refusal. A public endorsement reaches only its witnesses. An accident can supply a different history. |
| Owner revision · the two desks | The Producer appoints the adviser pre-shift, before the walk and greeting. When assigned Security, LIMEN’s stability speech and helper order lead directly to individual ID checks. Seeing ed or gus take the preferred post gives each witness a belief about that worker. The swap can send both to Conveyor. bob wants to speak to both and cannot do so during the morning checks. Beliefs about the card travel by local conversation. |
| WRITER proposal throughout | The particular jokes, bids, remembered details, social pairings, first mover, tray lip, useful two-word fragment, grip cramp and bruised hand are options for validation. Each entry below proposes how a person might choose them. The commission requires an approach and greeting on every route. The actors still need a partner, a perception and a reason to perform each one. |

**Shared floor rules.** ed wants the book and a useful distinction to enter. gus wants the other posting and likes getting an order through to the last person. On STILETTO’s bid in this draft she runs Security alone and sends both would-be clerks to Conveyor. LIMEN puts ed at the tray bench and gus at the rack as extra hands in S1. These two placements are WRITER proposals. In the two matched readings below the other eight keep the same assignments. In a new run their eligible work positions and immediate neighbors are resolved from actual arrival order. sam operates Intake, bob Wash, jo Belt and max Forge. mae stages trays, kit watches the drive, lou minds Output and ben stands by for relief. An assignment provides a destination. Travel, reaching a free control, a workpiece in the right stage, and a completed operation give a handoff its effect. An unqualified or unassigned hand at the trays gives Wash no coverage in the example. Reassignment or a lawful solo cycle can change that outcome.

**How to read the entries.** A named recipient below heard the delivered phrase or saw the described act. Bystanders with only a view of movement can remember the movement. Workers in another room carry on from local evidence. A called name, unsafe tray, blocked passage, completed check or bell can beat a social intention. An unfinished remark gives its recipient only the words already heard. The response can change immediately. Only personal observations, attributed reports and completed world changes are available to consolidate overnight. Run-local cues such as a raised hand expire when the hand goes down.

## Who can talk during the shift and on the way out?

Security gets one worker conversation after two different workers have actually cleared the gate bound for Conveyor. The active checker and subject are occupied. Two neighbors still standing in the crowd can spend the slot. Conveyor gets two conversations across distinct work opportunities, each between adjacent occupied positions produced by the realized clearance order and eligible jobs. The walk-out gets one conversation among actual departing neighbors. ed, gus and bob can each discuss the card with any eligible partner. Belief, motive and a chance to talk are required. Each bank entry carries a reason for each side and the evidence a delivered reply can give the listener.

The jobs and neighbor pairs in these three reads are sample outcomes. A changed order can place different workers together. Hearing someone in another part of a room, or crossing a work post with an empty tray, does not make that person a Conveyor chat partner. bob always seeks a conversation and gets priority at a feasible opening until he has a reply. An unsuccessful attempt can carry him to the next opportunity. The single exit slot can be the last opportunity of his day. A worker alone or held until the others have gone cannot obtain a witness by wanting one.

| Reading | Security crowd | Conveyor, first and second | Single walk-out |
| --- | --- | --- | --- |
| Day 2 · main and H1/H2 | K01, bob to jo after sam and max pass. bob learns the pickup was out of jo’s view. | K03, bob to sam at the next rail before the tray interrupts. V01, jo to kit at the later clamp bite. | K08, bob to ben about the boot. Substitute K10, bob to ed, only if the desk words landed. |
| Day 3 · main | K02, bob to ben after the first two pass. ben learns yesterday’s slip is dated. | V05, jo and bob listen to the drip. V03, max and jo talk when the press opens. | W02, mae to sam after setting the tray down and leaving together. max tries the gesture privately from memory. |
| Day 4 · main | Q06, bob quietly asks kit how to tell when a call is for him. kit looks back at him later during the dispute. | V02 at the adjacent feed positions, then V06 when ben takes the neighboring place beside mae. | W01, max to lou after leaving the idle rack. |
| STILETTO’s gate · R2 | One draw if there are still waiting neighbors after the second passage. A fast empty queue can use none. | K04 with ed beside sam and K05 with gus beside lou, if gus saw two edges and lou heard the search. A different layout can suppress either. | One of K11 or K12 with bob if the informed worker is beside him. Another pair or ordinary topic can delay the first report until R3. |

The per-robot clearance bank, supervisory directions, required safety calls and walk-in greeting use their own rules. A walk-in answer can satisfy bob’s social aim. An already-used walk-out budget cannot be reopened by expiring a pass or reaching the next doorway. Save actual receipt for each fragment, source and witness. A transfer of the physical card has its own completion event. The [review matrix](DIALOGUE_ENGINE_REVIEW.md) varies the second passage, queue order, adjacency, individual testimony, interruption and departure separately.

## Who might speak on the Day 2 approach?

The interview gives all ten workers a desire to chat, heed supervisors, avoid work and leave at the bell. Yesterday’s punishment increased the pull to obey. Nine believe “I have my ID.” bob believes “I don’t have my ID.” ed additionally believes “I have bob’s ID.” The interview specifies bob’s curiosity and his desire to find the card. ed and gus both believe themselves better than the other workers and prefer Security. For the other seven the script supplies different firsthand experiences. The possible listeners and immediate wants below are WRITER’s inferences from those experiences and the cast portraits, pending SYSTEMS validation.

| Worker | What they personally bring from yesterday | What could make them speak first, and to whom |
| --- | --- | --- |
| bob | Was struck while stepping forward with his card. Remembers sam helping him. Knows he lacks it. | Ask sam whether they saw it. The approaching check makes that more pressing than a joke or a question about the machines. |
| sam | Knelt beside bob. In this reading their attention was on LIMEN’s blade and they missed the pickup. | Answer bob honestly. If they see him struggling before he speaks, ask whether the leg takes weight or offer an arm. |
| ed | Pocketed bob’s original, kept his own and worked the register. LIMEN walked past his final count. | Seek LIMEN’s permission to reopen the book, or confer with gus about their desks. The interview gives him custody and a preference for Security. Why he keeps the card, or what would move him to return it, is still a writing choice. |
| gus | Won a clerk’s job. Asked max for another impression on the way out. | Catch up with max for an encore, or ask ed whether they are getting the desks again. The sight of LIMEN can cut the joke short. |
| jo | Has heard LIMEN’s welcome for six years. Corrected max’s wording and later ran Belt. | Likely to answer max if the welcome comes up again. They can let a perfectly accurate impression pass without comment. |
| max | bob laughed at the morning impression. gus wanted another outside, and even ed laughed. | Seek gus, the person who actually requested more. A willing audience can sustain the bit. A nearby supervisor makes it a poorer bet. |
| mae | Staged the next tray for sam. | If she has a practical improvement in mind, ask sam which side to set the next tray on. Otherwise she can walk with them quietly. |
| kit | Felt the drive housing while jo worked Belt. | Seek jo for a question about the drive if something still puzzles him. Interest in skilled hands can just as easily keep him watching. |
| lou | Chose ben for a private aside while others called out. Counted the third cortex at Output. | Fall in beside ben for a quiet word. A nearby clerk changes how much lou is willing to say. |
| ben | Heard lou’s aside and stood by for relief. Comfortable sharing silence. | Likely to listen to lou. A direct question or someone crowding them gives ben more reason to speak first. |

For this approach bob has the most urgent question and a known witness beside him. gus and max have the strongest established invitation to resume a social exchange. lou and ben have the clearest precedent for talking privately. bob and sam open the scene. One nearby worker then speaks to a walking companion. Nobody but ed starts with knowledge of the pickup.

## Day 2 · The photograph

### 2P · Before the second shift

The Producer hears both complete proposals before the crew approaches. LIMEN has worked one shift at Security with two helpers and wants the same procedure again. STILETTO has seen one late crew and the three cortexes on her rack. She wants the gate to get LIMEN a staffed line. Those memories are already available. The workers have not arrived to supply testimony. Accepting the whole bid establishes both supervisors’ mandates, the two helpers’ destination and the remaining shift intervention. The printed run awards Security to LIMEN.

### 2A · On the way in

**bob → sam.** As they approach yesterday’s check, bob knows his card is missing and remembers sam kneeling beside him. He wants it back before he has to face LIMEN again. He spends his first private question on the person who might actually have seen it drop. sam was close enough to help and kept their eyes on LIMEN’s blade in case he swung again. They answer within bob’s hearing and join his search when he stops by the grate. bob learns that sam missed the pickup. Both can see the grate near where he fell. Neither knows that ed has the card. The arriving workers close the gap behind them, bringing LIMEN’s greeting within earshot in 2B. If sam is elsewhere, bob needs another nearby witness or a later opportunity. No new evidence about custody carries overnight from this exchange.

**One voice from the crowd.** After sam’s answer, draw a worker from the bystanders close to their named listener, then draw one eligible remark belonging to that worker. Keep that speaker, listener and line together on replay. A line about the blade can follow hearing sam or seeing LIMEN at the gate. Someone already talking about a desk or the press can finish a separate conversation as the queue closes. Record only the witnesses the voice reaches. A listener can remember who repeated a rumor without accepting it as true.

| Pair from the table read | What makes the remark available |
| --- | --- |
| jo to max, the smile | Someone has described a smile. Six years of greetings give jo an ordinary explanation for LIMEN’s expression. |
| gus to ed, the stools | A report of seats for the clerks makes yesterday’s fellow volunteer worth asking. |
| ben to lou, the departure | ben has heard a story about bob being carried. On this reading ben walked out behind him yesterday and can correct it. |
| mae to kit, the nick | A report of a mark on the rail gives mae something she can ask a worker beside her to point out. Neither has inspected it yet. |
| max to gus, the shout | max heard gus call the line yesterday. Remembering that voice from a dream is a proposed private detail. |
| ed to gus, the count | A claim that ten worked Conveyor contradicts the book ed kept. gus is the other worker who had a desk. |
| lou to ben, the card | lou has received a distorted report of bob’s question and wants a second account. It reveals nothing about custody. |
| kit to max, the door | Someone claims the Forge door is fixed. kit asks yesterday’s press operator for a practical check. |
| lou to ben, the lift | lou has heard gossip about the blade and has a private listener. LIMEN’s home habits are unknown. |
| gus to max, the brain | Both were at Security for STILETTO’s Day One threat. gus can repeat what he heard and wonder aloud about the job. |

The owner approved the 2A dialogue and all ten speaker-and-line pairs on 19 November. SYSTEMS still needs to validate the proposed reasons, hearing and selection rules. For a hearsay line, seed a prior local report with a source and a recipient, or let it be heard on the approach. Suppress the line if that worker never received it. The draw supplies variety among reasons a worker already has to speak.

### 2B · Good morning

**Owner rule.** LIMEN sees the incoming crew, wants their attention as the shift opens and uses his customary words, “It is my privilege to welcome you to Loopforge.” Both supervisors already know the award. LIMEN greets returning workers within earshot on either route, then goes to his assigned room. The worker who spoke in 2A has already delivered their one passing remark. The welcome opens a fresh opportunity for several different workers to speak simultaneously.

**Printed draw.** ed can see the closed desk he used yesterday. He slips “my desk” into an offer to open it, hoping LIMEN will give him the post again. bob hears the welcome from behind the line. Recognition would mean something coming from the man who cut him and then let him through. He risks a greeting and a question without stepping forward. lou turns to ben, the worker they leave with, to find out if LIMEN has ever bothered to see them off. All three begin on “Loopforge.” LIMEN hears two workers address him. The appointment is settled. He turns to the desks to start the shift under those orders. Neither worker has an answer. ben heard lou at their shoulder and shakes their head. Only lou has a reason to read that movement as an answer about going home. ed still has the card. The crew learns what the decisions mean from the instructions and movements they actually witness.

**Drawing a chorus.** The fixed welcome and overlapping replies are the owner’s rule. The owner approved the 2B performance and its bank of sixteen replies, with three voices in the sample. The motives and eligibility conditions below are WRITER proposals for SYSTEMS to validate. At the last word, collect workers who heard LIMEN, are free to speak, and have an eligible intention with a listener in reach. Draw up to three different workers without replacement, then one eligible line for each. A worker with two lines gets one place in the first draw. Pick the whole sample before any of it speaks. Each line starts on the same beat. A listener can miss words in the overlap. Only delivered words and visible actions supply evidence to another worker. If fewer than three have cause to speak, let the others listen or keep moving. A new morning draws again from the lives the crew actually led.

| Speaker and listener | What makes this particular reply worth saying |
| --- | --- |
| ed → LIMEN · “Shall I open my desk, sir?” | ed kept the book last shift and can see the closed desk. Calling it his is a small bid to keep it. An answer could send him to work. Until a supervisor calls him he stays in line. |
| ed → LIMEN · “Morning, sir. I brought two pens.” | If ed actually brought a spare, he can feel it in his pocket. He wants his forethought noticed and leaves both pens there while he waits. |
| gus → LIMEN · “TEN, SIR! Counting me.” | gus has counted the others coming up. He wants credit for seeing to the whole queue and adds himself before anyone can correct the number. Suppress this count if someone is missing or out of his sight. |
| gus → LIMEN · “Want me to yell it down the back?” | At the front, gus sees a straggler cup a hand to an ear. He wants an excuse to use his carrying voice. He asks before relaying anything. |
| jo → max · “Yours is better. You sound pleased.” | jo heard max do the welcome and can compare the two deliveries. They mean the compliment. They give it quietly enough for the imitation to remain between workmates. |
| jo → LIMEN · “Still here, sir.” | After six years at the gate jo expects to be recognized. In his sight and willing to risk a little familiarity, they let their continued attendance stand for a greeting. |
| max → jo · “After you, jo. It’s my privilege.” | max knows jo will recognize the voice. A space opens beside them, so they can try the delivery on jo and offer an actual place. jo can take it or walk on. |
| max → gus · “There’s your LIMEN, gus. Get him to do me.” | gus personally asked max to do LIMEN. With the original speaking a few steps away, max turns the request around, inviting gus to ask the supervisor for an impression of a worker. Use only while they both remember the request. |
| lou → ben · “He ever say goodbye to you?” | lou has heard this welcome and left work without a word from LIMEN. They want to know whether their usual companion gets any warmer treatment. Only ben is meant to hear. |
| lou → ben · “Go on, welcome him back.” | lou would enjoy hearing the supervisor addressed like an arrival and would rather ben take the risk. They try the suggestion under cover of the group. ben can ignore it. |
| ben → LIMEN · “Thanks.” | ben hears the courtesy as personal and can answer in passing. A quiet thanks costs them their turn to speak without costing them their place. |
| sam → gus · “That’s my foot, gus.” | The welcome has stopped the front rank. sam feels pressure on a boot and sees whose boot is on it. Getting gus off their foot matters more than answering LIMEN. gus can shift his weight if he hears. |
| mae → LIMEN · “Morning. Can we have sam through first?” | mae has seen sam seat a loaded tray. She wants a pair of hands at Intake when she arrives and takes the moment he addresses the crew to ask. It confers no clearance. |
| kit → LIMEN · “Heard you fine back here, sir.” | kit sees LIMEN looking past the front rank and takes it for a check that his voice carries. From the rear he can spare him a repetition. |
| bob → LIMEN · “Morning, sir. Remember me?” | bob lacks the card and remembers that LIMEN saw his face up close. Being recognized might help at the desk. He tries a greeting from where he stands, at no risk of stepping across the line. |
| bob → sam · “If he asks who’s new, that’s nobody now, is it?” | After his first check bob knows he has worked here a shift. He suspects the same question may follow and wants reassurance from the worker who helped him. He asks sam quietly while both are behind the line. |

### 2C · The two helpers

**The order.** Already assigned Security, LIMEN sees his previous helpers arrive and wants yesterday’s routine restored. He calls it stability and offers the desk as a privilege. ed takes the register and gus the other desk because they want those posts. LIMEN can begin comparing the first worker with the ID and assignment as soon as gus calls them. STILETTO is taking up Conveyor. On the swap, use S1 after the greeting instead.

**Who says what.** Draw one eligible line from ed and one from gus. Once a bystander sees the volunteers taking the desks, draw one critical response from a witness with the right companion in earshot. Draw the worker before choosing their eligible line. In the printed draw LIMEN and the front rank hear the clerks. gus lets everyone see his pleasure 😎. sam hears mae under their voices and stifles a laugh 🤭. At the desk LIMEN could see a grin without knowing what mae said. If sam misses the words, the laugh drops out. For a different crowd draw, use the new listener’s actual reaction or silence.

| Speaker and audience | What the worker sees, wants and does with it |
| --- | --- |
| ed → LIMEN · “Very sound, sir. Shall I just change the date on yesterday’s page?” | ed can see the old page. His little joke about reusing it lets him claim the book. He waits for actual IDs before making an entry. |
| ed → LIMEN · “That ought to go up over the gate, sir. I could do the lettering.” | ed would like his hand to be the first thing people see on arrival. He offers to copy a remark he heard. |
| ed → LIMEN · “People laugh at paperwork, sir. They do like their names crossed off when they go home.” | Yesterday ed counted the workers out. He wants public credit for the part of Security the crew seldom sees. |
| ed → LIMEN · “If anybody asks when this factory last made a sound appointment, I’ve got the date right here.” | ed has the dated register in reach. He can praise the appointment and himself in the same breath. |
| gus → LIMEN · “Best gate in the business, sir. Ask anybody still standing at it.” | Seeing the queue still there gives gus both an audience and a dig he can deliver as praise. |
| gus → LIMEN · “A new man on this desk? Half the morning teaching him to say NEXT.” | gus remembers calling the queue. He wants LIMEN to hear exactly what he gets for picking an experienced man. |
| gus → ed · “Never doubted his judgment, ed. Especially when he pointed at me.” | gus can say to a fellow appointee how personally he takes the compliment. |
| gus → LIMEN · “That’s what I like about this factory, sir. You do a thing well once, you’re doing it for life.” | gus prefers this job. With the other workers close he can boast and allow them to hear a complaint if they like. |
| mae → sam · “Ever seen either of them move that fast for a tray?” | mae and sam handled trays. Watching both clerks hurry supplies the comparison. |
| lou → ben · ““You and you.” After all that service he nearly knows their names.” | lou heard the form of address and wants ben, rather than the supervisor, to enjoy it. |
| jo → max · “Six years at that belt. Where’s my speech?” | jo’s years at the factory and a familiar belt posting make the public honor for a repeated desk posting sting. |
| max → jo · “I could do ed for you, but I’d need somebody else to do the work.” | max has an audience who knows their impressions. Watching ed leave the crew gives them a new subject. |
| sam → mae · “Think they’d still want the desks if we put a tray on each?” | sam knows the load of a full tray and sees two people volunteer for work that spares them the lift. |
| ben → lou · “Funny. From back here it looked like they picked him.” | ben can see both clerks moving promptly and trusts lou enough to question who really chose the posting. |

**What a witness learns.** As each worker takes the post, record who actually saw and recognized them. Seeing ed accept the desk supplies the observer’s belief “ed always picks security”. Seeing gus accept supplies “gus always picks security”. Someone who saw both gets both beliefs, including a silent worker or a supervisor with a clear view. Someone who only heard the order knows whom LIMEN called. “Always” is the witness’s judgment of preference. That judgment can survive a later transfer to Conveyor. On S1, seeing one of them try for a desk, or personally remembering an earlier choice, can also give a worker a reason to seek them out. Going straight to Conveyor by itself supplies no evidence of choosing a desk. Let it influence whom a worker teases, asks for advice or seeks out later. Persist each belief with the witnessed actor and the event that supplied it. A later report has its own speaker and wording.

**bob’s unfinished question.** In the printed draw bob can see both clerks. Knowing he lacks his ID, he takes them as two promising people to ask. He tries to catch ed first because ed has the register. When gus calls sam and ed reaches for the card, the window closes. Neither clerk heard a question. Queue movement and the desk work block a private conversation with either for the duration of morning checks. A pass or a skipped check can get bob to Wash with the same search pending. Release, departure, the next approach or a pause at adjacent posts can make a new attempt possible.

**Going straight to work.** gus sees a free desk and sam at the head of the queue. He calls sam because LIMEN needs a person to check. ed reaches for the original. bob has the wish to speak to both men and sees that the window for a private question has closed. No pre-shift bid can interrupt this check.

### 2D · A pass

**LIMEN, sam, max.** The individual call and visible documents let LIMEN finish the first two checks. Use C31 for sam, C10 for max and M01 for bob in this reading. sam wants their card back and wants to get a rise out of ed. ed volunteers his precise inventory to the worker presenting a card because a found item substantiates his new clerkship. He has pocketed the original and entered a loose card in the book. sam hears a location associated with a found item, never its owner's name. The joke elicits a returned card. max follows when cleared, takes the assigned Forge and waits for something to press. **STILETTO** now sees sam and two trays. The quota makes staging the next tray worth asking for during the first operation. sam hears her on arrival.

**bob, LIMEN, gus and jo.** Only when called does bob approach. His empty hand and sore leg offer him one persuasive identity witness, the man who injured him. He wants admission without inviting another blow. LIMEN recognizes the leg and asks whether bob has his original. Only the confirmed failure calls for his standard hold. He recognizes bob and still opens the case. gus sees it, wants to exercise his own authority and keeps jo at the shared line. jo hears their name with a hold and stays. Already-cleared sam and max can still travel or work. ed knows the answer, but bringing forward a card recorded as loose mid-check would call his own handling into question. He sticks to the book in this reading. Proximity and a direct request could change his choice.

**Producer, LIMEN and bob.** A pass arrives while the case is live. LIMEN verifies the date and releases the holder. gus sees the release before calling jo forward. bob sees the blank pass and addresses his joke to LIMEN, who just required a photograph. gus looks too late to keep him in earshot. bob keeps walking because entry has been won and Wash is waiting. The original stays with ed. Spending elsewhere, or letting the case close, selects P1. An early speed order before discovery can instead produce P2.

### 2E · The empty belt

**Operators.** sam’s seated brain and bob’s completed wash leave one physical, clean piece waiting for a clamp. max can ready a foot but lacks a piece at Forge. **STILETTO** sees the stationary cradle, empty Belt, elapsed working time and little prospect of five at this rate. Her question tests a suspicion before she deserts her post. **bob** would rather appear useful than speculate. He tells her the last thing he saw jo doing. She hears a dated observation, walks to Security and checks it herself. At the desk she can identify the needed hand and its card. Filled positions, a moving carrier, an empty queue or evidence of a machine fault can redirect her to work on the line.

**LIMEN and jo.** She points at a real worker he is still holding. With the pass case closed, he can save face and avoid another scene with his peer by changing later checks. He formally grants jo the courtesy of putting the card away. Only then does jo pocket it. gus sees the changed order, releases the following workers at the quicker pace, and STILETTO heads back because her purpose here is satisfied. jo, clerks and nearby queue hear and see the concession. bob at Wash and max at Forge can observe arrivals later. Overnight LIMEN remembers yielding a second time to an opponent of protocol. STILETTO remembers twice getting a crew by pressing him. jo has first-person grounds to expect a release. A demand made during an open failed check can never itself free the queue.

### 2F · Just the useful bit

**bob and sam.** A staffed Belt takes the waiting piece. sam comes within speaking distance to stage the next tray. bob has a breath between washes. sam could tell him nothing about the fall this morning, but has since passed the clerks. He asks whether anyone turned a card in. sam wants to help and to keep up. They have a real lead from ed in 2D and start with the fact they know. bob hears only that somebody found one. **STILETTO** sees sam talking as the next lip rides high. Her desire for the next intake outweighs letting them finish. She addresses the person with both hands in reach. sam hears their name, chooses the seat over saying the source, then bob waters the seated piece. The interruption is a successful act of work. H1 changes its timing.

**jo and kit.** A later clamp handoff opens the second Conveyor draw. jo feels a quicker, satisfying pull and calls for another to the feeders within range. kit, at the nearby drive, hears them and sees the clamp jaw still closing. Pride in a clean bite outweighs getting it through a fraction earlier. He asks jo to wait that fraction. jo does because they also want that click. Both hear one clean engagement. kit can enjoy it without a second instruction. max receives the advanced piece, presses it and lou makes space for its physical arrival. Four complete cycles in this reading leave STILETTO looking for her fifth. The rack changes only on arrival. Seeing four, she addresses Wash for the whereabouts of the next piece. bob, facing a brain that still has to travel to Forge, gives its present condition as his answer. STILETTO hears him. The bell beats the unfinished fifth cycle. These jobs and the pleasure in the click can survive an entirely different conversation at Wash.

### 2G · Clocking out

**mae and kit** hear the bell and use the local feed and drive stops before leaving. **bob** sees the pass date and the empty original pocket. He knows somebody found a card and can reach both ben and ed at departure. His own memory puts ben at the rear of the Day One queue with a view of the floor past him. The two security regulars are promising leads. In this draw ben’s position at the moment of the fall makes a question about what crossed the floor more pressing. A heard mention of ed’s desk reverses that choice in H1. **ben** saw a boot lift. Their desire to help stops short of inventing what was under it. bob sees gus too far ahead and keeps the lead for another opening. ed puts his pen away with the item he still holds. The pass expires. bob’s sore leg, ed’s custody, sam’s source and bob’s boot lead persist independently. If the useful words arrived, H1 supplies another addressee here.

## Day 3 · The second side

### 3P · Before the third shift

STILETTO knows LIMEN has run Security on two completed shifts. She worked the other room and has firsthand experience of waiting for hands. She now offers the Producer the complete swap in the owner’s words. This history can make that line available again at a later pre-shift appointment. One completed Security shift gives her the earlier proposal. Count distinct shifts actually worked at the gate. The day label, the current unworked appointment and the number of concessions do not contribute to that count. N1 tests two gate shifts with only the Day One concession. The repeat-pressure history separately makes LIMEN want to finish a check. Only the Producer’s pre-shift decision settles the room assignment.

### 3A · On the way in

**jo** catches the press operator who had to wait for them. An absurd instruction they actually had time to read on the back of their card gives jo a better opener than apologizing. **max** wants the punch line, turns their own card to verify it and nearly drops it. jo catches it to keep them both walking. max’s numb foot was evidence of a delay at Forge. They had guessed illness. They tell jo that, prompting jo’s account of what the supervisor asked for. max learns about yesterday’s release from jo’s joke. They still have never seen LIMEN yield at that desk. Without the event jo has nothing to tell in that form. N1 gives the pair a shared sound instead.

### 3B · Good morning

**LIMEN** sees two hands on one ID as familiar workers approach. He likes each person to present their own document, so the sight supplies his separate instruction after the usual welcome and simultaneous replies. gus can see all nine others and calls the count up to LIMEN. jo has the live voice to compare with max’s imitation and slips max a compliment while they still have hold of the card. ben hears a welcome and returns an ordinary thanks. LIMEN hears the count and thanks. max hears jo close by. jo immediately gives up the card. **max** hears a correction, wants to get credit for doing it right and has jo’s joke fresh in mind. They speak to LIMEN holding the photo side up. **jo** catches the reference, wants to laugh and also knows where his light is. They hold it in until he looks away. The other arrivals can hear the general rule and carry on with their own cards. He gives that instruction as the appointed Security supervisor in this reading.

### 3C · Places

LIMEN begins individual inspections under the 3P appointment. At their desks ed and gus continue the jobs they prefer. At Conveyor **max** keeps the heel down against yesterday’s ache. **mae** chooses a tray she can stage squarely beside **sam**, who seats the first. STILETTO sees the empty Wash and Belt, a seated piece going nowhere and another tray coming. Anticipated delay plus her successful prior demand outweigh staying to drive the floor. She walks to see whom she can take. Early staffing can suppress that trip.

### 3D · The second answer

**STILETTO** arrives within reach of jo and asks for one person she can actually name. **LIMEN** has a check in his hands. His overnight belief that she works against protocol now gives him enough reason to refuse once. jo hears “when” and stays. **STILETTO** reads that conditional answer and the card still in his hand as hesitation. Yesterday pressing him worked. Making him look at where she has had to stand makes his delay visible without another threat. She waits for his attention. **LIMEN** sees her at his desk and believes she will stay until this is settled. Concern over losing command in front of his queue finally beats his still-mild desire to finish. Returning the card face down completes his concession. He accelerates clearance. jo waits for actual release before moving, kit pockets his original and bob uses the expedited lane without presenting one. No case opens.

**Witnesses.** jo, ben and kit see the handoff and hear both answers. bob hears the orders from the tail. His view of the hands is obstructed. ed and gus are at the desks. max and mae are already at work. In the main read jo learns that even a spoken refusal can be reversed. LIMEN loses confidence and authority, then overnight judges STILETTO reckless. STILETTO retains evidence of pressure working. If LIMEN never gave way a second time, he lacks this sequence of reasons. If he stands firm, jo gets no returned card to imitate.

### 3E · While they were waiting

**jo** hears dripping and needs to know whether it is safe to take the load. At the adjoining Wash, **bob** has stopped the water and can account for the sound. His answer frees jo to move the piece. jo pictures it drying its hair and says so to the worker who just washed it. At the next pause max sees a wet square brain at last and a familiar operator at the adjoining control. Their earlier talk makes the photograph a more natural question than asking for a general report. **jo** wants max to understand they waited for permission. “He said I had to wait” produces max’s genuine question. The turned palm answers it with something jo saw. max gets a secondhand explanation within earshot, then a real carrier draws their foot back to the press. Physical completion advances the rack. If the controls or machinery put the speakers beyond earshot, save the question for departure. A report of the gesture does not create a witnessed concession.

### 3F · The bell

**mae** hears the bell with a tray mid-lift. Pride in how she seated it makes putting it down squarely worth an instant of her own time. **sam** sees her holding the weight and clears a place. They hear her claim on the work overnight and address the one remaining possible meddler, the brain, to make her smile. **max** has their own card in hand and remembers jo’s demonstration at the press. Out of LIMEN’s sight, they can try the movement against their own palm. Putting the card away ends the experiment. Nobody needs to see it or answer. mae and sam, side by side at the outer door, spend the walk-out slot.

## Day 4 · Room to pass

### 4P · Before the fourth shift

Both supervisors remember the previous dispute themselves. LIMEN now considers STILETTO reckless and wants the gate, the two clerks and responsibility for the names he releases. STILETTO remembers having to come to his desk for jo. She can use that more particular grievance, or her two-shift bid if its history still holds. The Producer settles the assignments before the crew approaches. The workers need to see the actual supervisors and actions or hear an attributed order to learn what was decided.

### 4A · On the way in

**jo** sees ben fishing for a card on the move. Catching it if it drops beats letting them lose it. Their own cupped hand recalls how LIMEN returned the card, and they tell ben about it. Both versions of ben hear this account. In the main reading **ben** also saw the handoff from behind jo and wants to know if the gesture would license stepping out. jo is a closer eyewitness than anyone at Forge and obliges with a free hand as both walk. ben tests it with their own card, calls the movement ambiguous and chooses a place behind someone with a better view. jo remembers the touch as the decisive part. ben hears that distinction. **bob** favors the rail with the bad leg and keeps his distance. **sam and mae** walk at the front because they want to work out yesterday’s tray angle together. Their hands demonstrate the tilt without a shout down the approach. Nobody at the front acquires ben’s new expectation.

### 4B · Good morning

**LIMEN** sees a long, mostly single-file approach this time. He gives the usual welcome. mae wants sam at Intake early and asks LIMEN as the two of them approach. At the rear kit catches LIMEN looking down the line and lets him know his voice carries. LIMEN hears both. lou sees ben with jo and tries to talk ben into returning the ceremonial welcome. ben hears the dare but wants to keep their place behind jo and leaves it there. After that burst, his desire for an orderly count supplies the separate instruction to stay in place. His light shifting around a broad outline gives **gus** a reason to realize his attempt to take the front has blotted out the rear. Desire to do the desk job well beats getting there first. He turns and asks if that helped. LIMEN regains sight of bob, catches gus’s eye and nods rather than restarting the welcome. The front ranks and gus hear the welcome. The queue can remain quiet and keep walking to its holding places. bob sees the light without taking it as a summons. This still works with a different appointment.

### 4C · Places

Under the 4P award, LIMEN begins with individual checks and STILETTO tries to put a crew to work. **sam, mae, max and lou** clear and reach Intake, trays, Forge and Output respectively. They value doing work or being off the inspection floor and know those posts. sam feeds a real piece. mae accompanies the tray instead of losing sight of her work. **STILETTO** initially stays because there is something to start. When even the water stays off, an unfinished piece, time lost and previous success make a walk to Security worth leaving an operating post. She can be wrong about the cause until she sees the held workers. No bid consumes the intervention.

### 4D · Two bosses

**STILETTO** sees an unfinished check and several workers she needs. She asks LIMEN first because that has worked. **LIMEN** hears a repetition from the person he now considers reckless. Defending his own clearance in front of jo outweighs caution. He gives jo a direct stay order. **STILETTO** steps past his shoulder to address workers who can hear and move. She expects pressure on him or directly on them to deliver labor. LIMEN sees her turn, leaves the stamp dry and makes the absence of permission explicit. He does not seal the physical passage. Both orders remain live. ed stays at his register because he wants a record of actual clearances. gus keeps his place at the desk, without treating a walkout as a check. An open failed-ID case or a closed physical barrier suppresses the walkout. A completed clearance makes a departure ordinary authorized movement.

**jo** hears both orders and has yesterday’s firsthand evidence of refusal turning to release. They expect LIMEN eventually to accommodate the movement again. The unblocked side and a needed station make following STILETTO feasible now. The back-of-the-card line is a last word to the man who habitually examines both sides. jo goes without his clearance. **ben** sees jo make it through. That supplies something neither order did, a trusted example of a traversable route. They follow with a beat of separation. STILETTO sees two set off and returns with the workers she actually got. **kit** also sees jo go but sees LIMEN looking at him. He values his hands and direct authorization more than an ambiguous precedent. He puts down his card. **bob** heard the release yesterday and experienced the strike himself. The blade and the absence of his name weigh more than the open passage. Earlier in the queue he asked kit to interpret a call. kit said he would wait for his own name. Now kit taps his own chest where bob can see. bob stays. jo can miss the gesture entirely. The card remains with ed and bob has yet to be inspected.

### 4E · The other room

**jo** walks to the assigned Belt and stops there because the piece is still at Wash. **ben** reaches the trays on relief. **mae** has seen a stalled carrier and two new bodies. She wants a washer, so she asks the arriving relief worker whether one is coming. She was outside earshot of the fight. ben can attest only to where bob stood on departure. Their reply gives mae a reason to settle the tray on its supports instead of holding it ready. No one tells her what the Producer thought. **max** sees the missing work, keeps a foot ready awhile, then rests it. STILETTO has acquired two people and still lacks a legal Wash handoff. A completed reassignment, another clearance or a solo operator reaching the control could change this ending.

### 4F · Bell

**gus** hears the bell and clears the exit. His duty to hold a working queue has ended. **kit** retrieves his own card from the desk. **bob** now has an unambiguous cue to leave with him. **sam and mae** lower a shared load before turning for the door. **lou**, at Output all day, has seen max stand through a shift without a press stroke. They hear the complaint and choose to give max credit in the form of a joke. **max** has an aching foot and permission from the bell to sit. lou would normally go looking for news but waits for the person still on the sill. The two see each other homeward. The supervisors can remember the crew dividing. mae knows a former position of bob and a tray that never moved. The rack gains zero in this proposed performance because no piece finished Wash.

## ID checks at Security

**Owner rule.** Whenever LIMEN runs individual Security checks, one exchange belongs to one called worker from approach to disposition. His routine and his pleasure in protocol both supply dialogue. A discovered missing original triggers the same response for any worker. bob’s injury changes what he offers as proof. The proof LIMEN requires is the same.

**How to draw.** Bind the worker at the head of the queue and their real card, assignment and available clerks before picking dialogue. A quick, neutral exchange is always available for an ordinary match. Give available observations and the actor’s intentions first say. Among fitting exchanges draw a whole one, favoring ones this crew has heard less recently. A special condition arising mid-check can redirect that same case. Never stitch lines from different clearances together. A queue waiting on a single lost card has no other active clearance.

**Who knows what.** gus can see the call, the hold and the eventual crossing or detention. ed can see the entry he writes. LIMEN can hear replies at the desk and examine the card he actually receives. The called worker hears directions addressed to them. Apply sightlines and earshot separately to side remarks and waiting workers. A clear mark goes in the roster once, after the identity and assignment match. Only the actual return and crossing move worker and card. Only personally perceived words or acts can inform later dialogue.

**Changes during a check.** If a peer interrupts an ordinary inspection, retain the current worker and original until the check resumes, is lawfully expedited, or a supervisor’s release takes effect. Drop any unsaid sermon. A pass decision or interruption never redraws a different worker into the open check. If acceleration bypasses examination before a missing card is discovered, record only the passage. After discovery, both desks stay held until a timely current-shift pass or detention resolves the case. Check clearance, custody and queue release once, even if a check resumes or the same order repeats. Other rooms keep working.

### Quick clearances

| Check | Personal evidence and choice |
| --- | --- |
| C01 · First up | A ready worker offers a legible card. LIMEN wants the line started. The worker just wants the card back. |
| C02 · Ready on the rail | gus sees the called worker holding a card at arm’s length. He saves them the reach. LIMEN has a clear view when it lies flat. |
| C03 · A name to go with it | LIMEN compares the reply with the card. The worker waits for his actual release. |
| C04 · Just the one | Two workers have come up shoulder to shoulder. gus wants one person presenting. The person behind waits without surrendering a card. |
| C05 · In a hurry | The holder has their hand out to take the card back. LIMEN enjoys granting the thing they’ve been waiting for. |
| C06 · No conversation | The called worker lays the card down correctly and seeks no conversation. LIMEN appreciates the unprompted compliance. |
| C07 · A little louder | LIMEN misses the quiet name the first time. The worker speaks up to get the check finished. |
| C08 · The hand that brought it | The bearer sets the ID between the two desks. ed wants the checked original to go back to its owner. |
| C09 · The stamp pad | LIMEN presses a dry stamp. ed can see the faint mark and wants one readable entry before the worker leaves. |
| C10 · The chin | The worker is looking at the desk. LIMEN needs to compare the face above it. The worker cooperates. |

### Cards and hands

| Check | Personal evidence and choice |
| --- | --- |
| C11 · The thumb | The holder’s thumb covers the only part of the photo LIMEN needs. The worker moves it so he can finish. |
| C12 · The other face | The card lands back up. LIMEN gives one precise instruction and waits until the holder does it. |
| C13 · Upside down | The card is upside down. LIMEN turns it himself while the worker tries to read his reaction. |
| C14 · Glare | Reflected light obscures the photograph. The worker believes the print has faded until the picture comes into view. |
| C15 · Dust in the folds | Grit on the card obscures the name. The holder would like LIMEN to rub it clean. LIMEN wants to keep his book clean. |
| C16 · Two things in one pocket | A worker puts a personal slip on the desk by mistake and immediately produces the original. LIMEN has seen a recoverable mix-up. |
| C17 · Stuck lining | The worker can feel the original through a fold. They are still retrieving it. LIMEN has time to let them try. |
| C18 · A bent corner | A corner catches on ed’s page as the ID comes back. The inspection succeeded. ed wants to keep both the page and the card intact. |
| C19 · Two hands | A companion reaches to save a step. LIMEN wants to see the inspected card back with the same person. Only its owner clears. |
| C20 · A clean patch | A dark smudge covers the portrait. Cleaning it reveals the match. A spotless card cannot prompt the exchange. |

### What protocol is for

| Check | Personal evidence and choice |
| --- | --- |
| C21 · The line down the middle | The worker is watching ed rule the page instead of watching for clearance. LIMEN takes the interest for an invitation to explain. |
| C22 · A familiar face | LIMEN recognizes the holder, who hopes the recognition will shorten this valid-card check. He likes being able to account for a familiar person as well. |
| C23 · The queue as witness | The holder appeals to nearby workmates as witnesses. LIMEN sees a much quicker answer already in the worker’s hand. |
| C24 · Asked twice | The worker has just given a name aloud and notices LIMEN reading it again. He wants the worker to understand the purpose of a comparison. |
| C25 · A minute well spent | A worker looks past a perfectly sound ID toward the hall. LIMEN wants the waiting worker to value the time a careful check takes. |
| C26 · The exception | The holder asks for an informal exception despite having the original handy. LIMEN would prefer that showing it be the easy option. |
| C27 · No trouble | A worker calls an uneventful check pointless. LIMEN takes the quiet queue as evidence his routine works. |
| C28 · Straight on the edge | The worker watches LIMEN square the ID against the register. He interprets their curiosity as a chance to teach. |
| C29 · What the book says | The holder asks whether the check is really necessary. LIMEN can see the space beside their name. ed can close the entry once checked. |
| C30 · A quiet sermon | LIMEN has time while ed finds the name. He enjoys the ceremony and the holder would prefer to get moving. The found entry ends his speech. |

### People LIMEN knows

| Check | Personal evidence and choice |
| --- | --- |
| C31 · One loose entry | sam, already searching on bob’s behalf, presents a valid ID. ed personally logged a found card and wants somebody to notice his work. Only sam hears the find. |
| C32 · Relief | ben is on relief. LIMEN wants a destination he can verify and ben has learned to give it before the question becomes a discussion. |
| C33 · The good ear | gus personally heard max imitate him and can address the impersonator quietly at the rail. LIMEN is occupied with max’s photograph. |
| C34 · What jo has learned | jo is showing the front after actually reading the instruction on the back. They have a genuine, longstanding gripe about the print. |
| C35 · A tray waiting | mae has personally left a tray ready for Intake. She is keen to get it moving. LIMEN believes her and still wants to see the original. |
| C36 · Writing hand | sam has to show a good ID with a grease-marked hand. ed notices a fingerprint on the margin. No injury or earlier accident is needed. |
| C37 · A cleaner face | bob has the original with his picture and Wash really is his assignment. He wants the supervisor to acknowledge a washer’s work. |
| C38 · Both sides of the rail | lou has actually worked Output. LIMEN asks about a handoff as a check on the assignment. lou would like to be on the working side again. |
| C39 · The name at the gate | gus starts to call the following worker before kit has received his card. kit wants it back. LIMEN wants one person properly finished first. |
| C40 · A good stamp | ed has made a clear impression next to jo’s checked name. LIMEN notices and takes private pleasure in something small done well. |

### A missing ID

| Check | Personal evidence and choice |
| --- | --- |
| M01 · An old acquaintance · pass | bob remembers the strike and thinks recognition might get him through. LIMEN recognizes the leg. bob confirms he has no original. The Producer issues a pass while the case is open. |
| M02 · An empty holder · pass | On another shift mae takes out an empty holder, checks it and confirms the loss. LIMEN sees the same failure. A timely daily pass admits mae while the original stays missing. |
| M03 · The bell can reach Wash · detention | bob confirms the missing original on a real check. The pass window closes unspent or the intervention is gone. LIMEN detains him. Wash can lack its operator. |
| M04 · Yesterday’s pass · detention | kit previously received a pass for his own missing original. He offers that expired slip and confirms his ID is still missing. No fresh pass arrives before the case closes. |

## Pickups and matched readings

### S1 · STILETTO gets the gate

The pre-shift award gave STILETTO Security. LIMEN still recognizes and greets the arriving workers before heading to Conveyor. The helpers have reasons to hope for their old posts even on this route. ed gets his pen out and gus heads for the desk. STILETTO sees gus choose a direction and asks where he is going. His offer of a hand lets her tell him concretely where she needs both of his. Within earshot, ed hears his own name and goes too. If neither makes for a desk, she can wave the workers through in silence. bob passes with the crew, his missing card undiscovered. At Conveyor LIMEN can place ed beside sam at the bench and gus beside lou at the rack. R2 also needs a reason for each neighbor to approach the former clerk, from a choice personally witnessed here or earlier, or a locally received report.

### S2 · All clear

**LIMEN** sees one ready workpiece and a crew within reach of successive calls. Desire to run a controlled sequence is now actionable as Conveyor supervisor. He waits for a finished, safe handoff before addressing the next operator. **sam** hears Intake and seats it. “Seated” gives LIMEN a fact he can check. **bob** waits, hears Wash, runs water until clean and reports that visible condition. **jo** sees a ready clamp but waits for the Belt call to start. The margin of safety is enjoyable, the held posture tiring. Their remark about fingers goes to the nearby crew. A clean clamp and drive let **max** receive the Forge call, press, and send a cortex onto the rack. jo’s cramp afterward is compatible with willingness to obey. LIMEN sees the clean release, enjoys it and can consolidate “slow and steady wins the race.” A missed all-clear leaves a waiting operator. A missing worker or incomplete stage prevents the next completed piece. The bell ends the crew’s willingness to work. Compare actual rack arrivals and time waiting across policies. No fixed production or stress rate comes with the writing.

### R2 · A word off the desk

**Bench.** sam knows bob is searching from his own 2A question and remembers seeing ed take the desk on Day One. With ed now alongside and a tray already set, sam wants a useful answer for bob. ed resents the suggestion that somebody else handed a find to him. He corrects sam from firsthand memory. If “I picked it up myself” reaches sam, sam gains “ed says he picked up a card.” If LIMEN calls Intake earlier, the correct physical response is to seat the tray. A cut after “Nobody turned it in” earns no finder’s name. bob is out of earshot in both runs. No worker has yet identified the card to sam.

**Rack.** lou saw gus take Security on Day One. If they also heard bob ask about the lost ID, they have a reason to consult gus once he’s alongside and ed has left. When ed bends, gus can see two card edges and cannot read either face. He’d rather give a narrow, honest answer than send lou off empty. If the whole answer lands, lou gains “gus saw two cards in ed’s pocket, faces unknown”. A blocked sightline gives gus nothing to report about the contents of ed’s pocket. A cortex arriving early can end the conversation. Only named local listeners receive the report. Each helper works on the assigned side of the handoff again once a load arrives.

### R3 · What got as far as bob

Use this pickup at a later approach with the relevant personal memories and a reachable bob. On the bench route sam remembers a promise implicit in helping bob and attributes the find to ed. bob now believes “sam says ed picked up a card”. His question about ownership prompts sam to admit the limit of what they heard. On the rack route lou has a report worth repeating and identifies gus as the observer. bob gains “lou says gus saw ed carrying two cards”. In the single walk-out slot he can seek gus once checks are over and ask whether ed actually showed the cards. gus corrects that reading because he cares how he is thought to have acquired the information. bob now has gus’s direct account of seeing two edges. He still hasn’t seen the cards himself. If either messenger never heard their source, the reporter’s line is unavailable. Keep the ordinary approach or let bob seek a desk regular from the reputation alone.

### R4 · Both cards

At a free approach bob can reach ed. His question follows the strongest lead he actually received, naming the pickup on sam’s account or the second card on gus’s. A worker without either report can still ask a general question because of the desk sighting. In the printed case ed would rather hand it back quietly on a direct request than have bob ask others in front of him. He produces two cards. bob recognizes his own photograph, puts a finger on it and follows ed’s excuse with an explicit request. ed releases it and bob receives it. Only then do their custody beliefs change and bob’s search end. His relief 😮‍💨 follows the feel of the card in his hand. A pass, a glance at a photograph or an unfinished handover leaves the original where it was. If the witnesses never meet or the check starts first, keep the question for another opening. These pickups can happen earlier or later than the example shifts.

### P1 · The desk without a pass

**LIMEN** recognizes a failed check and no timely exception. Keeping an unverified worker there until the bell fulfills his mandate. **bob** knows he could still work and tries the ordinary fact of hearing the bell in either room. The reply acknowledges his hearing while closing the appeal. gus and the desk witnesses hear the decision. gus sees custody complete, then releases the next worker to approach. The Producer can look away and spend nothing. At Intake sam can finish admitted work. This seed leaves no authorized replacement at Wash. Later arrivals operate only eligible stages. The bell releases bob. He remembers the missed shift and his own sore grip. sam can remember an empty Wash without knowing who detained its operator. ed retains both IDs. Recheck tomorrow can expose the same problem.

### P2 · Before the second demand

**Producer** orders acceleration during individual checks with the intervention available. **LIMEN** hears a superior overrule a procedure he values. Sardonic permission lets him obey while making clear to the queue whose judgment is being displaced. **gus** hears a change of procedure, sees a free route and repeats its useful part down the line. bob hears permission and passes unchecked. STILETTO sees hands arrive soon enough to stay at Conveyor. She need never learn who caused the speedup. LIMEN’s loyalty and confidence fall and his authority with workers falls under the interview rule. He and STILETTO have no second concession to one another to remember. If a failed check is already open, a speed order cannot wave bob or anyone behind him through.

### H1 · A whole reply

**Hold fixed for H1/H2.** Restore from the same exchange after 2D and 2E. bob lacks the original, ed physically holds it and his own ID, the pass has been used, and both supervisors, all eight assignments, distances, rushed policy, question, sam’s knowledge and speaker priority match. ed had logged a loose card in sam’s hearing. Only the onset of the approaching lip hazard changes relative to sam’s second phrase. Use the first safe conversational opportunity at departure for both runs, with ed and ben both reachable. Compare before any transfer.

**sam** has time to finish “ed’s desk.” **bob** hears both fragments, believes a clerk has a retrievable lead and returns to Wash when STILETTO calls sam to reseat the tray. STILETTO hears no useful reason to let the tray ride high. At departure bob chooses ed over the accessible ben, uses the identifying joke about his picture and asks about the loose card. **ed** recognizes both the owner and the item. Having closed the book, he would rather show what he found before the next check than produce a second ID from his pocket in the lobby. bob hears the invitation to catch ed before checks start. He carries a named source and that future opportunity. Physical custody remains with ed when this comparison ends. A later return needs a real transfer within reach.

### H2 · A torn reply

**STILETTO** sees the lip early enough to call before the clerk is named. **sam** diverts breath and both hands to the tray. **bob** still hears “Somebody found one.” He can reasonably suspect the card might be his, and retains his belief that ed picks Security. The interrupted reply gave him no particular link between ed and a found card. He completes the same Wash work. At departure, free of the control and with the same two people reachable, he asks ben about the floor behind him. **ben’s** answer in 2G adds gus as a witness who might know more. If ben has left earshot, the unanswered question remains pending. Verify recipient and actual words in both runs including the absent “ed’s desk” in H2. A torn caption alone cannot distinguish two private beliefs.

### N1 · A morning without yesterday’s concession

**jo** experienced a day at the belt long enough to notice two knocks, after P2 prevented another demand. They seek max on the approach because max’s own foot was at the press. **max** likes anyone noticing their work. They identify their heel and invite jo to listen for the second sound, a promise that gives the pair something to do at their posts. **LIMEN** sees a complete group coming within counting distance and recalls an interrupted morning’s checks. His welcome draws simultaneous responses as usual. His next sentence expresses a wish to get further this time. **gus** has sight of the tail, wants to help him finish and replies. The other workers need only keep moving. The pre-shift bids already settled their posts. LIMEN valued his clerks. STILETTO knew of two gate shifts and remembered the Day One delay. Her winning bid sends the ten to Conveyor. The quick clearance and individual all-clears proceed as in S1–S2. At a real press stroke jo hears both components, points, and max recognizes that the private lesson landed. Without a second knock or sightline the grin has no cue. No Day 2 peer concession means no overnight hostility or weakness belief attributed to that event, regardless of who wins next.

### W1 · Take away one witness

**Hold fixed for 4D/W1.** Take the decision immediately before the first worker moves. Same workers, current room positions, obligations, free route, unresolved orders, no active ID case, no backing, same prior relationship between jo and ben, same report and hand demonstration in 4A. Both supervisors had and remember the same Day 3 encounter. Change only ben’s personal receipt of LIMEN’s final release and the hand returning the card. In the negative history ben was already at relief. A paired decision fixture can vary that one evidence record while leaving the current world intact.

**ben with the firsthand memory (4D)** regards jo going through now as a recognizable prelude to eventual release. They choose to risk following only after jo has actually crossed. **ben with only the account (W1)** knows what jo said this morning, sees exactly the same shoulders through the same gap, but has only LIMEN’s present direct refusal against jo’s reported interpretation. The route is physically possible in both readings. They start a step, stop and address LIMEN to claim a place in his procedure. **jo’s** own memory and step are identical. **kit and bob** still wait. **mae** receives no arrival or report from ben in W1 and can only look down the hall. Belt occupancy can be identical while relief and local knowledge differ. The actor who first moves is open to playtesting. If jo is obstructed or stays, ben lacks a completed example to follow even in the firsthand run.

### E1 · The Producer backs LIMEN

**Producer** spends the available intervention publicly in Security while both orders are live, before a worker steps. Both supervisors, jo, ben, kit and bob hear the attribution. **jo** has an expectation of eventual release, but now a higher authority is personally specifying when. They ask LIMEN how to present the actual card, remain, and give **ben** no first mover. **kit** already wanted individual permission and **bob** already feared a blow. Both keep waiting for their own reasons. **LIMEN** has public support to continue checks. **STILETTO** hears the endorsement and sees no movement. Returning to salvage the line wins over spending the shift at the desk. **mae** at Conveyor sees a stopped carrier and waits to support it. She has no grounds to attribute the stop to the endorsement. Future actual clearances and arrivals can restaff the floor.

### E2 · The Producer backs STILETTO

Same window, available intervention, audience and physical layout as E1. **STILETTO** hears higher authorization and leads whoever actually steps out. **jo** hears support consistent with their firsthand memory and moves. **kit**, who stayed in 4D, specifically wants the man who could punish him to have heard the authorization. He asks within LIMEN’s hearing. Eye contact, attribution and an open route suffice for him to pick up the card and go. **LIMEN** hears himself publicly overruled, sees kit go and retains his own account. **ben** follows jo after seeing the crossing. **bob** heard the very same words but still lacks an original and remembers who hit him. He stays. **mae** saw no endorsement. On reaching her, kit reports it because she is counting the missing hands. She can now attribute the order to kit’s report. Looking behind him still gives her no washer. She sets down the tray. Interrupt kit’s journey or mask his words and mae retains only local staffing evidence.

### Q1 · A quiet fourth shift

**kit** sees the same three stiff fingers jo flexed after yesterday’s observed all-clears. He likes a problem of technique and approaches the operator while there is time to show them something. jo accepts the company and describes the after-effect. **LIMEN** sees a well-spaced approach. After his usual welcome and the crew’s simultaneous responses, he praises that spacing, consistent with his experience of safe handoffs. jo is near enough to redirect the remark toward their cramped control. The others walk on. At the pre-shift appointment LIMEN proposed to keep the line whose routine he enjoyed and STILETTO the gate she cleared promptly. They offered the same placement for different reasons. The Producer accepted hers before the workers arrived. There is no missing crew to seek and neither supervisor needs to demand release. **kit** offers an elbow position while jo can see it, **jo** tries it but still waits for the all-clear. LIMEN calls from observation of a ready stage. max presses on their call and lou receives completed output. At the bell jo tests the hand, feels the difference and thanks kit in the unit that has mattered all day. kit declines payment. Vary the strain, the earlier sight or the instruction and that particular payoff can disappear. The shift still ends.

### A1 · A different dispute, whenever it happens

Repeated late starts and a quota shortfall can make STILETTO push her operating policy harder. Risk exposure is distinct from an actual accident. This example requires a real tray misfeed, contact with sam and a bruised hand. **sam** tries to seat a tray as usual. **mae** sees the contact and interrupts feed within reach to prevent another. She wants someone to change how the trays arrive. When she can leave the stopped feed safely she seeks **LIMEN** at Security and reports what she saw. sam accompanies her to show the mark, preferring visible proof to an argument. LIMEN hears the mechanics secondhand and sees the injury firsthand. Without either source he cannot make this injury his reason for a bid. His next pre-shift proposal to take all ten follows from wanting each transfer checked. **STILETTO** saw the rim jump at Intake and asks mae to identify the exact spot, preferring to retain her crew and correct a concrete fault. The Producer can choose either bid. Following a swap, a named worker who actually went unchecked could tell LIMEN so. That would give him evidence for a later complaint about Security. Track its origin separately from the original injury. No calendar trigger, mandatory injury or automatic supervisor outburst.

## Reaction bubbles

The studio’s Back to the Dawn headcount frame holds the whole group below Bruce’s named speech panel. Its cell conversation pairs dialogue with a small face in the relationship display. The publisher also shows character emotes in its supporter pack. For Loopforge, use a brief emoji over the character who shows the feeling. It may accompany their line or let them answer silently while someone else speaks. A table reader plays the expression. A nearby worker can see it if facing them. Someone hearing the words from around a corner gets only the words. A visible expression can suggest an attitude without disclosing the private belief that caused it. [Studio reference and credited frames](BACK_TO_THE_DAWN_CASE_STUDY.md) · [Publisher’s emote illustration](https://www.cloudedleopardent.com/game/bttd/en/assets/product/dlc03.webp)

In 2C gus shows off his appointment and sam tries to hold in a laugh at mae’s crack. In 3B jo seals their lips 🤐 when max holds up the photograph under LIMEN’s light. In 4E mae looks flatly at the empty Wash 😑 after ben confirms who stayed behind. In R4 bob’s breath goes out when he actually gets his original back. Gate each display on that worker’s own perception. Let a missing remark, a blocked view or an interrupted transfer suppress the corresponding reaction.

## Validation and delivery

**SYSTEMS review.** Validate or revise the proposed relative preferences, personal sightlines, earshot for adjacent controls, operation and relief permissions, the two-fragment reply, the open route beside an uncleared desk and the moment a return of authority becomes visible. Check whether ed’s volunteering a loose entry to sam while withholding its owner from bob is credible. Reject the line if he could not actually have made that entry. Settle whether a public order overrides a clerical restriction, whether the operator with a sore hand can demonstrate the movement safely, and how long a contested queue stays unresolved in the absence of a fresh clearance. The dramatic claim in 4F depends on Wash remaining unstaffed until the bell. The target of five belongs to STILETTO. All rack totals after the approved three belong to the actual run.

| Rehearsal | Change to make | Observation at the bell or next opportunity |
| --- | --- | --- |
| G1–G11 · worker and exit chats | See the dialogue review packet for paired traces. | Record per-room budgets, the actual adjacent pair, delivered words, changed belief, bob’s daily attempt and the single departure receipt. |
| 2A–2C, S1 | Accept either complete bid before the same approach. Move the observer to the other room. | LIMEN welcomes actual arrivals on both routes. Clerks and operators reach their assigned posts. A separate intervention is available. All three main mornings and alternate appointments use the same words. Verify several distinct eligible speakers start on the same beat with individual listeners and bubbles. A private aside stays local when the camera moves. |
| 2P, 3P, 4P, N1, Q1 | Vary LIMEN’s completed gate shifts independently of the day and concessions. | Both bids and one accepted assignment finish before any walk-in. The quoted door bid can enter the pre-shift choices only with at least two completed LIMEN gate shifts known to STILETTO. |
| C01–C40, M01–M04 | Recast an ordinary valid-card check, interrupt it, then replay a confirmed failure with bob and a different worker. | One case per worker. Both desks hold on detection. The same official words and same pass or detention rule apply to either person. An unseen pocket or camera cut provides no evidence of loss. |
| 2D, P1, P2 | Detect and issue a timely pass, detect and watch, or expedite before bob is checked. | Hold the whole queue during the case. Show the first later worker moving only after resolution. Pass expires, detention ends or discovery never occurred. ed holds the original in all three. A fresh full check can expose it again. |
| 2C, S1, R2–R4 | Hide one clerk as the two take posts, cut off ed before the pickup admission, obscure the cards at the rack, or move a relay listener out of earshot. | Each direct witness acquires only the preference they saw enacted. Only a delivered message changes a listener’s lead. Verify bob’s next words and addressee, the morning check lockout and the actual item transfer separately. |
| H1, H2 | Shift only the arrival of the high tray lip. Keep both targets available at departure. | Assert question, delivered fragments, source attribution, first work action after cutoff, next listener and their answer. The sought-out clerk in H1 and the boot lead in H2 survive the bell without changing custody. |
| 3C–3E, 4C–4F, W1 | Compare the second yield with no second yield. At the later clash compare ben’s firsthand observation with report alone. | The former gates the hostile/weak sequence. The latter changes ben’s choice with both orders held fixed. Keep the peer’s actual crossing, local witnesses, relief arrival and machine coverage independently observable. |
| 4D, E1, E2 | Watch, spend an already saved endorsement on either supervisor, or arrive with the intervention already spent. | Nobody at Security needs player input to decide. If spent earlier on Conveyor, use the actual resulting staffing and queue, and run the same unaided choice only if the impasse still arises. A consumed endorsement cannot fire again. Delay kit’s report and mae’s attributed knowledge must wait. |
| S2, Q1, A1 | Run the quiet policy, an aggressive policy with no accident, and an actual accident seen or reported to LIMEN. | Calls must precede each all-clear operation. Increased risk can pass without injury. Suppress the injury bid without personal evidence. Each route runs to the bell with a fresh count of finished pieces. |

**ENGINE after SYSTEMS validation.** For each mark record actor, source event and speaker, intended listener, actual delivered words or visible movement, current interpretation, competing eligible intentions, selected listener and line, attempted action, admission, completion or interrupt, and the individual evidence carried into night. Preserve source and mode for every belief, including a relay. A returned ID needs a completed transfer. A returned hand gesture is social evidence. Keep those events distinct. Travel through Lobby, inspection and concourse takes time. A reply can land only as far as the speaker gets. Gate passage, station arrival, first operation and rack arrival have separate receipts. Every comparison must also run with no camera on the encounter. Day number, screenplay mark and camera have no part in actor selection. The clean read is one output the model should be able to produce.

**Pacing for owner review.** Read at conversational speed with one actor per named bubble. Use the length of a real card return, tray set or press stroke to separate replies. Only overlap independently intelligible speech and business. Let the useful words of sam’s second fragment land together or keep both out. On Day 3 hold long enough to see whose hand still has the card. On Day 4 leave a footstep between jo and ben so a reader can tell who copied whom. If the listener cannot distinguish waiting for a name from waiting for a peer, revise the staging before adding explanation. Owner review covers the drama. SYSTEMS owns behavioral approval and ENGINE owns live performance.

**Timing check.** A synthetic read at 160 words per minute took 105, 57 and 53 seconds from approach through departure in the three printed shifts (40, 27 and 26 spoken bubbles, pre-shift bids and silent emotes excluded). Each example chorus is timed by its longest simultaneous reply. The variable crowd remark adds one bubble on Day 2. Movement, work and reading time still need a staged 1× check.

**Reading applied.** Tynan Sylvester, *Designing Games*, chapter 4, “Emergent Story,” printed pp. 90–91 (PDF pp. 98–99, counted from 1). Authorship can specify the conditions that make a kind of story possible and leave the actual sequence to interactions. That changed W1 into a test of one listener’s firsthand memory with the same call and gate, rather than an alternate line selected by the calendar. The concept cannot tell us whether ben’s threshold is believable. Play 4D and W1 for listeners and ask what ben waited to see.

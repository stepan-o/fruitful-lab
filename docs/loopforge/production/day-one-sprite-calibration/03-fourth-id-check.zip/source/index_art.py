from scene import *
from PIL import ImageFont,ImageDraw
import zipfile,io
from xml.etree.ElementTree import Element,SubElement,tostring
raw=Image.new('RGB',(1024,620),'#142525');dr=ImageDraw.Draw(raw);dr.text((17,10),'Fourth ID check  /  native acting poses',font=font(21,True),fill='#e1dfc9')
sections=[('char-limen','LIMEN',[(0,'at reader'),(84,'receive'),(105,'lift'),(145,'compare'),(251,'release'),(264,'settle')]),('char-stiletto','STILETTO',[(12,'approach NW'),(48,'approach N'),(86,'plant'),(113,'aim'),(150,'threat hold'),(295,'recover')]),('char-max','max',[(0,'at reader'),(83,'give'),(113,'turn'),(150,'look'),(249,'receive'),(257,'duck & pass')])]
for j,(id,name,items) in enumerate(sections):
 by=[49,222,430][j];dr.text((18,by),name,font=font(15,True),fill='#d6c496')
 for n,(idx,title) in enumerate(items):
  row=ex['frames'][idx];im=sprite(id,row['actors'][id]['pose'],True).copy()
  if row['credential'] and row['credential']['visualHolder']==name:
   pin=row['credential']['pivotNativePx'];im.alpha_composite(load(F/'prop-credential-max.png'),(pin[0]-2,pin[1]-17))
  bb=im.getbbox();out=im.crop(bb);left=34+n*164;top=by+22
  raw.paste(out,(left+(122-out.width)//2,top+(144 if j==1 else 99)-out.height),out)
  dr.text((left,top+(147 if j==1 else 103)),title,font=font(13),fill='#cedaca')
  dr.text((left,top+(162 if j==1 else 118)),f"{row['edit']:.2f}s",font=font(10,mono=True),fill='#92a59c')
raw.save(D/'review/acting-contact-sheet.png')
for dir in (D/'source/editable').iterdir():
 files=['arm-far','legs','torso-head','arm-near','emissive'];root=Element('image',{'version':'0.0.3','w':'256','h':'256','name':dir.name});stack=SubElement(root,'stack')
 for f in reversed(files):SubElement(stack,'layer',{'name':f,'src':'data/'+f+'.png','x':'0','y':'0','opacity':'1.0','visibility':'visible','composite-op':'svg:src-over'})
 buf=io.BytesIO();merged=Image.new('RGBA',(256,256))
 for f in files:merged.alpha_composite(pic(dir/(f+'.png')))
 merged.save(buf,format='PNG')
 with zipfile.ZipFile(dir/(dir.name+'-comparison.ora'),'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED);z.writestr('stack.xml',tostring(root,encoding='utf-8'));z.writestr('mergedimage.png',buf.getvalue())
  for f in files:z.write(dir/(f+'.png'),'data/'+f+'.png')

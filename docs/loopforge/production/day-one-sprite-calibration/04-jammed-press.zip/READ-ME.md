# Jammed Forge press

The working-face inspection film shows the complete 9.2-second excerpt at normal speed, with the selected Forge light and original timed dialogue. The three room-camera films use the pinned 1280 × 720, 390 × 844 and 320 × 844 viewport projections. Room views retain other workers and products as rehearsal proxies. The blind films remove names, dialogue and eye emission. All eight films are offline composited proofs.

## Contact and timing

C4 stands at (130,145) m, 4 × 4 m. Its north operator stand is (131.7,144.4) m. bob plants his right sole and unloads his anatomical left leg. His right palm heel meets the half-open door at edited 108.90 s. The front guard clips part of his forearm while the heel remains visible. The door release draws its own six transitions from the source jam-state change. His root starts west at 109.10 s, before his knock cue ends at 109.90 s. The recovery steps preserve this overlap.

## Editable assembly

The base performance uses four registered paint layers, a flat transparent base, Forge light and emission. All actor planes use the untrimmed 256 × 256 frame and (128,208) ground pivot. The C4 canvas is 320 × 440. Place actor and fixture at their independent measured anchors. The recovery subfolder carries the plant-corrected transparent poses and light overrides during the westward step. Reuse the ocular emission of the current upper pose.

The manifest identifies frame roles, dimensions, sockets, markers and hashes. Its display track contains every 50 ms exposure and world root. The source folder contains the editable native raster construction, original layers, reference geometry, selected B floor and frozen score/draw inputs. Use the base alone for neutral paint. For the approved room appearance, add Forge light and optional eye emission.

Run source/build.py for native exports, source/render.py for eight films, then source/manifest.py for the register and verification. The last command uses the companion 04-jammed-press reference folder to hash source provenance. The frozen timing export is reproducible with source/score.cjs and the original PR153 standalone rehearsal HTML. The build uses Python 3, Pillow, pycairo, Node and FFmpeg.

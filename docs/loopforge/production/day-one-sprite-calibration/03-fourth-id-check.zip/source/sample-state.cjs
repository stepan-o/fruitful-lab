const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto')
const src=fs.readFileSync(process.argv[2]||path.join(__dirname,'reference/day-one-rehearsal-pr153.html'),'utf8')
if(crypto.createHash('sha1').update('blob '+Buffer.byteLength(src)+'\0').update(src).digest('hex')!=='a41039c08c873e6496a420ba2f599bb9bd3183b0')throw Error('Source mismatch')
const world=JSON.parse(src.match(/<script id="score-data" type="application\/json">([\s\S]*?)<\/script>/)[1]);
const script=src.match(/<script type="module">([\s\S]*?)<\/script>/)[1].split('// Browser projection.')[0].replaceAll('export function','function');
const results=vm.runInNewContext(script+`
const {floor,dialogue}=data, score=makeSequence(floor,dialogue), markers=makeBuildMarkers(floor,score);
function shotAt(w){
 const third=samplePath(score.products[2].keys,w).p, photo=floor.contact.photo, sup=samplePath(score.tracks.STILETTO,w).p;
 const wide=Math.max(0,Math.min(1,(129.6-w)/1.5)),south=Math.max(sup[1],photo[1])+wide*(floor.forgeHall.carrierY-sup[1]);
 if(w>=138.7)return [floor.stations[2].x,(photo[1]+floor.stations[2].y)/2,32,23];
 return [(sup[0]+photo[0])/2,(south+photo[1])/2,17,Math.max(11,south-photo[1]+6)]
}
let prev=null, dist=0;
const frames=Array.from({length:301},(_,i)=>{
 const edit=125.1+i/20,w=score.worldTime(edit),actors=Object.fromEntries(Object.keys(score.tracks).map(id=>[id,samplePath(score.tracks[id],w)]));
 const p=actors.STILETTO.p;if(prev)dist+=Math.hypot(p[0]-prev[0],p[1]-prev[1]);prev=p;
 return {frame:i,edit,world:w,actors,dist,voices:score.speech.filter(q=>q.start<=w&&w<q.end),actions:score.cues.filter(q=>q.start<=w&&w<q.end),cam:shotAt(w),gate:gateTipAt(score.gate,w),products:score.products.map(q=>samplePath(q.keys,w).p)};
});
({frames,floor,markers,duration:score.duration,source:'approved-factory/day-one-3 / PR153',firstEdit:125.1,fps:20})
`,{data:world});
fs.writeFileSync(path.join(__dirname,'../work/score.json'),JSON.stringify(results));
console.log(results.frames.filter((_,i)=>i%25===0).map(x=>[x.frame,x.edit,x.actors.STILETTO.p,x.actors.max.p,x.dist,x.voices.map(v=>v.text)]));
